import logging
import asyncio
from fastapi import FastAPI
from ray import serve
from starlette.responses import StreamingResponse
import torch
from queue import Empty
from transformers import AutoTokenizer, AutoModelForCausalLM, TextIteratorStreamer

# 1: Define a FastAPI app and wrap it in a deployment with a route handler.
app = FastAPI()
logger = logging.getLogger("ray.serve")

@serve.deployment(
    route_prefix="/",
    max_ongoing_requests=20,
    ray_actor_options={"num_gpus": 8},
)
@serve.ingress(app)
class SummaryDeployment:
    # FastAPI will automatically parse the HTTP request for us.
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        model_name = "Qwen/Qwen2.5-1.5B-Instruct"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name).to(
            self.device
        )
        self.loop = asyncio.get_running_loop()

    def generate_text(self, prompt: str, streamer: TextIteratorStreamer):
        max_length = 50
        min_length = 10
        no_repeat_ngram_size = 3
        length_penalty = 2.0
        num_beams = 1

        with torch.no_grad():
            answers_input_ids = self.tokenizer.batch_encode_plus(
                [prompt], return_tensors="pt", truncation=True, max_length=max_length, 
                pad_to_max_length=True
            )["input_ids"].to(self.device)
            self.model.generate(
                answers_input_ids,
                streamer=streamer,
                num_beams=num_beams,
                length_penalty=length_penalty,
                max_new_tokens=max_length,
                min_length=min_length,
                no_repeat_ngram_size=no_repeat_ngram_size,
            )

    async def consume_streamer(self, streamer: TextIteratorStreamer):
        while True:
            try:
                for token in streamer:
                    logger.info(f"Yielding decoded tokens: {token}")
                    yield token
                break
            except Empty:
                await asyncio.sleep(0.001)

    # Reference: https://github.com/amaiya/ktrain/blob/master/ktrain/text/summarization/core.py
    @app.get("/summarize")
    def summarize(self, prompt: str) -> str:
        streamer = TextIteratorStreamer(
            self.tokenizer, timeout=0, skip_prompt=True, skip_special_tokens=True
        )
        self.loop.run_in_executor(None, self.generate_text, prompt, streamer)
        return StreamingResponse(
            self.consume_streamer(streamer), media_type="text/plain"
        )

deployment = SummaryDeployment.bind()
