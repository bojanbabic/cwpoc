from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class UserEventsData(BaseModel):
    llm_data: Optional[Dict[str, Any]] = None
    source_manager_event_data: Optional[Dict[str, Any]] = None
    filtered_chat_history: Optional[List[dict]] = None
    mai_data: Optional[Dict[str, Any]] = None
    # note: this object cannot be of the type RoutedMode due to a circular dependency
    # this is because we require this eventsdata class in middlewares
    # and because middlewares is imported in a wide variety of packages, it prevents its dependencies from
    # depending on higher-level object types.
    # the user event recorder class still uses RoutedMode so that still serves as the entry point
    routed_mode_output: Optional[Dict[str, Any]] = None

    pre_search_service_data: Optional[Dict[str, Any]] = None
    model_config = {"use_enum_values": True}
