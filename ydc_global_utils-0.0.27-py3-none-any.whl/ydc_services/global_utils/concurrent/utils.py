import functools
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from contextvars import copy_context
from typing import Callable, List, ParamSpec, TypeVar

from ydc_services.global_utils.instrument.new_relic import (
    record_nr_and_log,
)

"""
Wrapper for aiohttp request handlers, will only
work on a handler that expects a request arg
"""

_T = TypeVar("_T")
_P = ParamSpec("_P")


class CustomThreadPoolExecutor(ThreadPoolExecutor):
    def __init__(
        self,
        name: str,
        max_workers=None,
        initializer=None,
        initargs=(),
        should_wait_on_exit=True,
        # Since there multiple layers of logging, we skip logging on exit
        # for some cases to avoid redundant logs
        should_skip_logging_on_exit: bool = False,
    ):
        thread_name_prefix = f"{name}/"
        super().__init__(max_workers, thread_name_prefix, initializer, initargs)
        self.name = name
        self.futures: List[Future] = []
        self.should_wait_on_exit = should_wait_on_exit
        self.should_skip_logging_on_exit = should_skip_logging_on_exit

    def submit(
        self, func: Callable[_P, _T], /, *args: _P.args, **kwargs: _P.kwargs
    ) -> Future[_T]:
        scope = f"custom_tpe/{self.name}/{func.__name__}"
        record_nr_and_log(f"{scope}/calls", 1)

        # Prepare the function with all required arguments using partial
        context = copy_context()
        partial_func = functools.partial(func, *args, **kwargs)
        future = super().submit(context.run, partial_func)
        start_time = time.time()

        def log_completion(future: Future):
            latency = time.time() - start_time
            try:
                future.result()
                record_nr_and_log(
                    f"{scope}/success/latency",
                    latency,
                    skip_logging=self.should_skip_logging_on_exit,
                )
            except Exception:
                record_nr_and_log(
                    f"{scope}/error/latency",
                    latency,
                    is_error=True,
                    skip_logging=self.should_skip_logging_on_exit,
                )

        future.add_done_callback(log_completion)

        self.futures.append(future)
        return future

    def as_futures_completed(self, timeout: float | None = None):
        """Overridden as_completed function that records timeout errors to newrelic"""
        try:
            for future in as_completed(self.futures, timeout):
                yield future
        except TimeoutError:
            record_nr_and_log(f"custom_tpe/{self.name}/timeout", 1, is_error=True)
            raise

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Overridden __exit__ function to wait on exit only if specified
        This is required for support the should_wait_on_exit parameter.
        This prevents us from exceeding the given timeout when using threadpoolexecutor in a context manager
        because the default shutdown behavior is set to wait=True.

        When disabled, we ensure that we always raise a TimeoutError within the given timeout.
        """
        self.shutdown(wait=self.should_wait_on_exit)
        return False
