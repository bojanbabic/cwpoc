from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Tuple, TypeAlias
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, RootModel, model_serializer
from typing_extensions import TypedDict

from ydc_services.global_utils.llm.citations.schemas import (
    CitableItem,
    CitationTemplateType,
    form_citation_num_string,
)
from ydc_services.global_utils.llm.tokenizers.openai_tokenizer import OpenAITokenizer
from ydc_services.global_utils.storage.model_utils import (
    GenericJsonApiMixin,
    PydanticMongoDocument,
)


class AssistantMetadata(BaseModel):
    assistant: str
    company: str
    maxSize: int


class FileMetadata(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    mime: list[str]
    file_type: str = Field(serialization_alias="type", validation_alias="type")
    supportedAssistants: Optional[list[AssistantMetadata]] = None

    @model_serializer(mode="wrap")
    def ser_model(self, handler) -> dict[str, Any]:
        result = handler(self)
        file_type = result.get("file_type") or result.get("type")
        if file_type != "image":
            result.pop("supportedAssistants")
        return result


class FileExtensionMetadata(RootModel):
    root: dict[str, FileMetadata]


class FileNames(BaseModel):
    user_filename: str
    filename: str


class FileInfo(FileNames):
    size: str | int
    cloud_integration: Optional[str] = None
    file_owner: Optional[str] = None


class AnalyzedFileInfo(FileInfo):
    file_analysis_result: str


class FileContext(FileNames):
    content: str
    modality: Literal["text", "image"]
    error: Optional[str] = None


class FileContextError(FileNames):
    error: str


FileContextOrError: TypeAlias = FileContext | FileContextError


class TruncatedFileCitableItem(BaseModel, CitableItem):
    user_filename: str
    filename: str
    content: str
    # NOTE: When this is None, it means that the file has not been truncated at all.
    #  When it is "", it means that the file has been fully truncated.
    truncated_content: Optional[str] = None
    # Number of tokens in the file
    num_tokens: int
    # Number of tokens used from the file
    num_used_tokens: int

    def get_citation_link_and_score(
        self,
        snippet_to_be_cited: Optional[str] = None,
        use_highlight_snippet: bool = False,
    ) -> Tuple[str, Optional[float]]:
        # use_highlight_snippet not supported for files
        return f"file://{self.user_filename}", None

    def form_llm_context_with_citation_number(
        self, starting_citation_num: int, template_type: CitationTemplateType
    ) -> str:
        # NOTE: Currently all file upload templates are under "simple"
        citation_num_str = form_citation_num_string(
            template_type, starting_citation_num
        )
        filename_and_content = ""
        if self.truncated_content:
            filename_and_content = f"{citation_num_str}: `{self.user_filename}`\n```\n{self.truncated_content}\n```"
        # check that we didn't truncate the entire file content per truncate_file_content_if_needed
        elif self.truncated_content != "" and self.content:
            filename_and_content = (
                f"{citation_num_str}: `{self.user_filename}`\n```\n{self.content}\n```"
            )
        return filename_and_content


class ProcessedPageMetadata(BaseModel):
    parent_doc_id: str
    page_range: str
    page_numbers: List[int | None]
    img_s3_paths: List[str | None]
    metadata_record_id: str = Field(default_factory=lambda: str(uuid4()))

    def to_dict(self) -> Dict[str, Any]:
        """Convert the processed page to a dictionary matching the index mapping"""
        return self.model_dump(exclude_none=True)


class ProcessedDocument(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    content: str
    user_id: str
    file_type: str
    user_filename: str
    content_modality: Literal["text", "image"]
    upload_date: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    last_file_analysis_date: str = Field(
        default_factory=lambda: datetime.utcnow().isoformat()
    )
    metadata: ProcessedPageMetadata
    embedding: Optional[List[float]] = None
    user_defined_tags: List[str] = Field(default_factory=list)
    ydc_defined_tags: List[str] = Field(default_factory=list)
    classification: Optional[str] = None
    tenant_id: Optional[str] = None
    team_id: Optional[str] = None
    file_uri: Optional[str] = None
    file_hash: Optional[str] = None
    chunk_id: str = Field(default_factory=lambda: str(uuid4()))

    def to_dict(self) -> Dict[str, Any]:
        """Convert the processed document to a dictionary matching the index mapping"""
        # Start with the base model dump
        doc_dict = self.model_dump(exclude_none=True)

        # Remove id as it's not in the index mapping
        doc_dict.pop("id", None)

        doc_dict["metadata"] = self.metadata.to_dict()

        # Ensure embedding is the correct dimension if present
        if doc_dict.get("embedding") and len(doc_dict["embedding"]) != 1536:
            raise ValueError("Embedding must be 1536 dimensions")

        return doc_dict


TUploadStatus = Literal["upload", "index", "done", "error"]
IN_PROGRESS_UPLOAD_STATUS = ["upload", "index"]
TSourceType = Literal["user_file", "url"]


class SourceMetadataRecord(GenericJsonApiMixin, PydanticMongoDocument):
    user_id: str
    tenant_id: Optional[str] = None
    index_name: Optional[str] = None
    project_id: Optional[str] = None
    source_type: Optional[TSourceType] = "user_file"

    file_name: Optional[str] = None
    processed_encrypted_filename: Optional[str] = None
    hashed_filename: Optional[str] = None
    processed_doc_id: Optional[str] = None
    s3_path: Optional[str] = None
    parent_file: Optional[str] = None

    file_size: Optional[float] = None
    text_token_count: Optional[int] = None
    image_token_count: Optional[int] = None
    tokenizer_id: Optional[str] = None

    token_counts_map: Optional[dict[str, int]] = None

    url: Optional[str] = None

    upload_session_id: Optional[str] = None
    upload_status: Optional[TUploadStatus] = "upload"
    error: Optional[str] = None

    def to_mongo(self, is_update_call=True):
        return super().to_mongo(
            is_update_call=is_update_call, exclude=["id"], exclude_unset=is_update_call
        )

    def get_info_from_processed_doc(self, doc: ProcessedDocument):
        self.processed_doc_id = doc.id
        if doc.content_modality == "text":
            tokenizer = OpenAITokenizer("gpt-4")
            self.text_token_count = tokenizer.count_tokens(doc.content)
            self.tokenizer_id = tokenizer.tokenizer_name
        elif doc.content_modality == "image":
            self.image_token_count = 6000
            self.tokenizer_id = "image_tokenizer"

    def to_json_api_data(
        self,
        type="project_sources",
        attributes=[
            "file_name",
            "file_size",
            "created_at",
            "updated_at",
            "upload_session_id",
            "upload_status",
            "source_type",
            "error",
        ],
    ):
        if self.source_type == "url":
            attributes = [
                "url",
                "created_at",
                "updated_at",
                "upload_session_id",
                "upload_status",
                "source_type",
                "error",
            ]

        return super().to_json_api_data(type=type, attributes=attributes)


class StorageAccountType(str, Enum):
    USER_UPLOADS = "user_uploads"
    AGENT_CDN = "agent_cdn"
    PUBLIC_CDN = "public_cdn"

    @property
    def is_agent_cdn(self) -> bool:
        # NOTE: storage account in `StorageAccountType` is a misnomer, it isn't directly
        # mapped to the container storage account, but it is a combination of storage
        # account and container id.
        return self in [StorageAccountType.AGENT_CDN, StorageAccountType.PUBLIC_CDN]


class CloudProvider(Enum):
    AWS = "aws"
    AZURE = "azure"


class PdfLLMConfig(TypedDict, total=False):
    name: str
    max_page: int
    dpi: int
    llm_timeout: int
    size_cutoff_percentage: int
    char_cutoff_percentage: int


class UploadOptions(BaseModel):
    metadata_record: Optional[SourceMetadataRecord] = None
    cloud_provider: CloudProvider = CloudProvider.AZURE
    cloud_integration: Optional[str] = None
    should_run_file_analysis: bool = True
    should_extract_and_encrypt_text: bool = True
    storage_account_type: StorageAccountType = StorageAccountType.USER_UPLOADS
    enable_file_tokenizer_type: Optional[Dict[str, Any]] = None
    pdf_fallback_llm: Optional[PdfLLMConfig] = None
    use_hashed_filename: bool = False


class FileUploadResult(BaseModel):
    user_filename: Optional[str] = None
    filename: Optional[str] = None
    original_filename: Optional[str] = None
    file_extension: Optional[str] = None
    file_content_type: Optional[str] = None
    file_size: Optional[int] = None
    hashed_filename: Optional[str] = None
    hashed_file_content: Optional[str] = None
    storage_account_type: Optional[StorageAccountType] = None
    cloud_integration: Optional[str] = None
    metadata_record: Optional[SourceMetadataRecord] = None
    error: Optional[str] = None
    is_internal_error: Optional[bool] = None

    def to_user_facing_dict(self) -> Dict:
        response = self.model_dump(
            include={
                "user_filename",
                "filename",
                "original_filename",
                "file_extension",
                "file_content_type",
                "file_size",
                "hashed_filename",
                "hashed_file_content",
                "storage_account_type",
                "cloud_integration",
            }
        )
        meta_record_id, token_counts = None, None
        if self.metadata_record:
            meta_record_id = self.metadata_record.id
            token_counts = self.metadata_record.token_counts_map

            response.update(
                {
                    "file_record_id": meta_record_id,
                    "size_context": token_counts,
                }
            )

        return response


class FileDownloadResult(BaseModel):
    file_content: Optional[str] = None
    encoding: Optional[str] = None
    error: Optional[str] = None
    is_internal_error: Optional[bool] = None


class FileRecordMetadata(BaseModel):
    filename: Optional[str] = None
    user_filename: Optional[str] = None
    storage_account_type: Optional[StorageAccountType] = None
    file_content_type: Optional[str] = None
    file_size: Optional[int] = None
    file_id: Optional[str] = None
