from ydc_services.global_utils.file_upload.schemas import (
    AssistantMetadata,
    FileExtensionMetadata,
    FileMetadata,
)


def get_file_extensions(supported_file_types: FileExtensionMetadata) -> tuple[str, ...]:
    valid_file_extensions = []

    # Get file extensions corresponding to the file type
    for ext, _ in supported_file_types.root.items():
        valid_file_extensions.append(ext)

    return tuple(valid_file_extensions)


def get_file_types(supported_file_types: FileExtensionMetadata) -> dict[str, str]:
    file_types = {}
    for filename_extension, file_metadata in supported_file_types.root.items():
        file_types[filename_extension] = file_metadata.file_type
    return file_types


def get_mime_types(supported_file_types: FileExtensionMetadata) -> dict[str, list[str]]:
    mime_types = {}
    for filename_extension, file_metadata in supported_file_types.root.items():
        mime_types[filename_extension] = file_metadata.mime
    return mime_types


def filter_file_types_if_zdr_enabled(
    supported_file_types: dict, is_zdr_compliance_required_request: bool
) -> dict:
    if is_zdr_compliance_required_request:
        for filename_extension, file_metadata in supported_file_types.items():
            if file_metadata["type"] == "image":
                assistant_metadata_list = supported_file_types[filename_extension][
                    "supportedAssistants"
                ]
                new_assistant_metadata_list = []
                for assistant_metadata in assistant_metadata_list:
                    if assistant_metadata["company"] == "Anthropic":
                        new_assistant_metadata_list.append(assistant_metadata)
                supported_file_types[filename_extension][
                    "supportedAssistants"
                ] = new_assistant_metadata_list
    return supported_file_types


ALLOWED_IMAGE_FILE_EXTENSIONS: tuple = (".png", ".jpg", ".jpeg", ".webp", ".gif")
DEFAULT_UPLOAD_AGENT = "claude_3_5_sonnet"
UNSUPPORTED_AGENTS = ["create", "research_10x"]

# Container for chat artifacts that can be shared between YDC users but remain private and inaccessible via direct URL
SHAREABLE_CHAT_OUTPUT_CONTAINER_ID = "user-content-shareable-chat-artifacts"
# Container for public chat artifacts that can be accessed directly via Azure storage URL - Mostly for media resources
PUBLIC_CHAT_OUTPUT_CONTAINER_ID = "user-content-public-chat-artifacts"


SUPPORTED_FILE_TYPES = FileExtensionMetadata(
    root={
        ".as": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".asc": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="text",
        ),
        ".asm": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".asmx": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".asp": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-asp"],
            file_type="code",
        ),
        ".aspx": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".bash": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-shellscript"],
            file_type="code",
        ),
        ".bat": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".blob": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".c": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".cc": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".cfg": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".coffee": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".command": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".conf": FileMetadata(
            mime=["text/*", "text/plain", "application/octet-stream"],
            file_type="code",
        ),
        ".config": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".cpp": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".cs": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".css": FileMetadata(
            mime=["text/*", "text/css", "application/octet-stream"],
            file_type="code",
        ),
        ".csv": FileMetadata(
            mime=[
                "text/*",
                "text/csv",
                "application/octet-stream",
                "application/haansoftcsv",
            ],
            file_type="data",
        ),
        ".cu": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".cxx": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".d": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".dart": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/vnd.dart"],
            file_type="code",
        ),
        ".dat": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".db": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".dbf": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".docx": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/wps-office.docx",
                "application/haansoftdocx",
            ],
            file_type="text",
        ),
        ".eml": FileMetadata(
            mime=["text/*", "message/rfc822", "application/octet-stream"],
            file_type="text",
        ),
        ".ent": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".entities": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".entity": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".epub": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/epub",
                "application/epub+zip",
            ],
            file_type="text",
        ),
        ".fnt": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".fon": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".gif": FileMetadata(
            mime=["text/*", "application/octet-stream", "image/gif"],
            supportedAssistants=[
                AssistantMetadata(assistant="default", company="You.com", maxSize=20),
                AssistantMetadata(assistant="agent", company="You.com", maxSize=20),
                AssistantMetadata(
                    assistant="smart_routing", company="You.com", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4o_mini", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4_5_preview", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="gpt_4o", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gpt_4_turbo", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="openai_o1", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gemini_2_flash", company="Google", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_flash", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_pro", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="claude_3_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_opus", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_haiku", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_5_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet_thinking",
                    company="Anthropic",
                    maxSize=5,
                ),
                AssistantMetadata(assistant="llama3_2_11b", company="Meta", maxSize=3),
                AssistantMetadata(assistant="llama3_2_90b", company="Meta", maxSize=3),
            ],
            file_type="image",
        ),
        ".go": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".groovy": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".h": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".hpp": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".htm": FileMetadata(
            mime=["text/*", "text/html", "application/octet-stream"],
            file_type="code",
        ),
        ".html": FileMetadata(
            mime=["text/*", "text/html", "application/octet-stream"],
            file_type="code",
        ),
        ".ini": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="text",
        ),
        ".ino": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".j": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".jav": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".java": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".jpeg": FileMetadata(
            mime=["text/*", "application/octet-stream", "image/jpeg"],
            supportedAssistants=[
                AssistantMetadata(assistant="default", company="You.com", maxSize=20),
                AssistantMetadata(assistant="agent", company="You.com", maxSize=20),
                AssistantMetadata(
                    assistant="smart_routing", company="You.com", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4o_mini", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4_5_preview", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="gpt_4o", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gpt_4_turbo", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="openai_o1", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gemini_2_flash", company="Google", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_flash", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_pro", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="claude_3_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_opus", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_haiku", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_5_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet_thinking",
                    company="Anthropic",
                    maxSize=5,
                ),
                AssistantMetadata(assistant="llama3_2_11b", company="Meta", maxSize=3),
                AssistantMetadata(assistant="llama3_2_90b", company="Meta", maxSize=3),
            ],
            file_type="image",
        ),
        ".jpg": FileMetadata(
            mime=["text/*", "application/octet-stream", "image/jpeg"],
            supportedAssistants=[
                AssistantMetadata(assistant="default", company="You.com", maxSize=20),
                AssistantMetadata(assistant="agent", company="You.com", maxSize=20),
                AssistantMetadata(
                    assistant="smart_routing", company="You.com", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4o_mini", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4_5_preview", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="gpt_4o", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gpt_4_turbo", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="openai_o1", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gemini_2_flash", company="Google", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_flash", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_pro", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="claude_3_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_opus", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_haiku", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_5_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet_thinking",
                    company="Anthropic",
                    maxSize=5,
                ),
                AssistantMetadata(assistant="llama3_2_11b", company="Meta", maxSize=3),
                AssistantMetadata(assistant="llama3_2_90b", company="Meta", maxSize=3),
            ],
            file_type="image",
        ),
        ".js": FileMetadata(
            mime=[
                "text/*",
                "text/javascript",
                "application/octet-stream",
                "application/javascript",
                "application/x-javascript",
            ],
            file_type="code",
        ),
        ".jse": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".jsl": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".json": FileMetadata(
            mime=["text/*", "application/json", "application/octet-stream"],
            file_type="data",
        ),
        ".jsx": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".kt": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".kts": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".latex": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="text",
        ),
        ".less": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".log": FileMetadata(
            mime=["text/*", "text/plain", "application/octet-stream"],
            file_type="text",
        ),
        ".lua": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".m": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".markdown": FileMetadata(
            mime=["text/*", "text/markdown", "application/octet-stream"],
            file_type="code",
        ),
        ".md": FileMetadata(
            mime=["text/*", "text/markdown", "application/octet-stream"],
            file_type="code",
        ),
        ".mdb": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".mm": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".mq4": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".mq5": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".mqt": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".msg": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="text",
        ),
        ".mxml": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".odt": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/vnd.oasis.opendocument.text",
            ],
            file_type="text",
        ),
        ".otf": FileMetadata(
            mime=["text/*", "application/octet-stream", "font/otf"],
            file_type="data",
        ),
        ".pdf": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/pdf",
                "application/haansoftpdf",
            ],
            file_type="text",
        ),
        ".perl": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".php": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-php"],
            file_type="code",
        ),
        ".pl": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".pm": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".png": FileMetadata(
            mime=["text/*", "application/octet-stream", "image/png"],
            supportedAssistants=[
                AssistantMetadata(assistant="default", company="You.com", maxSize=20),
                AssistantMetadata(assistant="agent", company="You.com", maxSize=20),
                AssistantMetadata(
                    assistant="smart_routing", company="You.com", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4o_mini", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4_5_preview", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="gpt_4o", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gpt_4_turbo", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="openai_o1", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gemini_2_flash", company="Google", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_flash", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_pro", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="claude_3_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_opus", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_haiku", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_5_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet_thinking",
                    company="Anthropic",
                    maxSize=5,
                ),
                AssistantMetadata(assistant="llama3_2_11b", company="Meta", maxSize=3),
                AssistantMetadata(assistant="llama3_2_90b", company="Meta", maxSize=3),
            ],
            file_type="image",
        ),
        ".properties": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".ps1": FileMetadata(
            mime=["text/*", "application/octet-stream"], file_type="text"
        ),
        ".py": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".pyi": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".r": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".rb": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-ruby"],
            file_type="code",
        ),
        ".rmd": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".rs": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".rtf": FileMetadata(
            mime=["text/*", "application/rtf", "application/octet-stream"],
            file_type="text",
        ),
        ".sav": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-spss-sav"],
            file_type="data",
        ),
        ".scala": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".sh": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/x-shellscript",
                "application/x-sh",
            ],
            file_type="code",
        ),
        ".sql": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/sql",
                "application/x-sql",
            ],
            file_type="code",
        ),
        ".swift": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".t": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".tab": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".tex": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/x-latex",
                "application/x-tex",
            ],
            file_type="text",
        ),
        ".text": FileMetadata(
            mime=["text/*", "text/plain", "application/octet-stream"],
            file_type="text",
        ),
        ".tf": FileMetadata(
            mime=["text/*", "application/octet-stream"], file_type="text"
        ),
        ".toml": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/toml"],
            file_type="data",
        ),
        ".ts": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".tsv": FileMetadata(
            mime=["text/*", "text/tab-separated-values", "application/octet-stream"],
            file_type="data",
        ),
        ".tsx": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-tiled-tsx"],
            file_type="code",
        ),
        ".ttf": FileMetadata(
            mime=["text/*", "application/octet-stream", "font/ttf"],
            file_type="data",
        ),
        ".txt": FileMetadata(
            mime=[
                "text/*",
                "text/plain",
                "application/octet-stream",
                "application/text",
            ],
            file_type="text",
        ),
        ".uc": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".vb": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".virtualenv": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="code",
        ),
        ".webp": FileMetadata(
            mime=["text/*", "application/octet-stream", "image/webp"],
            supportedAssistants=[
                AssistantMetadata(assistant="default", company="You.com", maxSize=20),
                AssistantMetadata(assistant="agent", company="You.com", maxSize=20),
                AssistantMetadata(
                    assistant="smart_routing", company="You.com", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4o_mini", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gpt_4_5_preview", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="gpt_4o", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gpt_4_turbo", company="OpenAI", maxSize=20
                ),
                AssistantMetadata(assistant="openai_o1", company="OpenAI", maxSize=20),
                AssistantMetadata(
                    assistant="gemini_2_flash", company="Google", maxSize=20
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_flash", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="gemini_1_5_pro", company="Google", maxSize=49
                ),
                AssistantMetadata(
                    assistant="claude_3_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_opus", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_haiku", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_5_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet", company="Anthropic", maxSize=5
                ),
                AssistantMetadata(
                    assistant="claude_3_7_sonnet_thinking",
                    company="Anthropic",
                    maxSize=5,
                ),
                AssistantMetadata(assistant="llama3_2_11b", company="Meta", maxSize=3),
                AssistantMetadata(assistant="llama3_2_90b", company="Meta", maxSize=3),
            ],
            file_type="image",
        ),
        ".woff": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/font-woff"],
            file_type="data",
        ),
        ".woff2": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="data",
        ),
        ".wps": FileMetadata(
            mime=["text/*", "application/octet-stream"],
            file_type="text",
        ),
        ".xhtml": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/xhtml+xml"],
            file_type="code",
        ),
        ".xml": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/xml",
                "application/rss+xml",
                "application/rls-services+xml",
            ],
            file_type="data",
        ),
        ".xlf": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/xml",
                "application/x-xliff+xml",
            ],
            file_type="data",
        ),
        ".xliff": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/xml",
                "application/x-xliff+xml",
            ],
            file_type="data",
        ),
        ".xlsx": FileMetadata(
            mime=[
                "text/*",
                "application/x-xls",
                "application/msexcel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/wps-office-xlsx",
                "application/haansoftxlsx",
                "application/octet-stream",
            ],
            file_type="data",
        ),
        ".yaml": FileMetadata(
            mime=[
                "text/*",
                "application/octet-stream",
                "application/x-yaml",
                "application/yaml",
            ],
            file_type="data",
        ),
        ".yml": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-yaml"],
            file_type="data",
        ),
        ".zsh": FileMetadata(
            mime=["text/*", "application/octet-stream", "application/x-shellscript"],
            file_type="code",
        ),
    }
)

ALLOWED_FILE_EXTENSIONS = get_file_extensions(
    FileExtensionMetadata.model_validate(SUPPORTED_FILE_TYPES)
)

ALLOWED_FILE_TYPES = get_file_types(
    FileExtensionMetadata.model_validate(SUPPORTED_FILE_TYPES)
)

ALLOWED_MIME_TYPES = get_mime_types(
    FileExtensionMetadata.model_validate(SUPPORTED_FILE_TYPES)
)

ALL_ALLOWED_MIME_TYPES = list(
    set(
        [
            mime_type
            for mime_type_list in ALLOWED_MIME_TYPES.values()
            for mime_type in mime_type_list
        ]
    )
)
