import locale
import logging
import os
import re
import sys
from copy import deepcopy

import mmh3

from ydc_services.global_utils.aiohttp.middlewares_and_headers import (
    DEFAULT_TRACE_ID,
    request_context_var,
)

logger = logging.getLogger(__package__)


class ContextHasher(object):
    def __init__(self, context):
        self.context = context.copy()

    def generate(self, **kwargs):
        context = kwargs.get("context", None)

        if not context:
            context = self.context

        return self._generate(context, **kwargs)

    def _generate(self, context, **kwargs):
        for key, value in context.items():
            context[key] = self.compute_value(key, value, **kwargs)

        return context

    def compute_value(self, key, value, **kwargs):
        force_hashing = kwargs.get("force_hashing", False)

        if "query" in key or "queries" in key or "prompt" in key:
            return self.hash(key, value, force_hashing=True)
        elif "file" in key or kwargs.get("extract_extension"):
            return self.hash(key, value, extract_extension=True, force_hashing=True)
        elif "link" in key or "url" in key:
            return self.hash(key, value, force_hashing=True)
        elif force_hashing:
            return self.hash(key, value, **kwargs)
        elif isinstance(value, dict):
            return self._generate(value, *kwargs)
        else:
            return value

    def hash(self, key, value, **kwargs):
        if isinstance(value, list) or isinstance(value, set):
            return self._hash_list(key, value, **kwargs)
        elif isinstance(value, dict):
            return self._hash_dict(key, value, **kwargs)
        else:
            return self._hash_scalar(key, value, **kwargs)

    def _hash_list(self, key, value, **kwargs):
        return list(map(lambda v: self._hash_scalar(key, v, **kwargs), value))

    def _hash_dict(self, key, value, **kwargs):
        return {k: self.compute_value(k, v, **kwargs) for k, v in value.items()}

    def _hash_scalar(self, key, value, **kwargs):
        extract_extension = kwargs.get("extract_extension", False)
        v = str(value)

        if extract_extension:
            filename_without_ext, file_ext = os.path.splitext(v)
            result = {
                f"{key}_len": len(filename_without_ext),
                f"{key}_hash": mmh3.hash128(filename_without_ext, 0, signed=False),
                f"{key}_ext": file_ext,
            }
        else:
            result = {
                f"{key}_len": len(v),
                f"{key}_hash": mmh3.hash128(v, 0, signed=False),
            }

        return result


class HashedLogRecord(logging.LogRecord):
    def __init__(
        self,
        name,
        level,
        pathname,
        lineno,
        msg,
        args,
        exc_info,
        func=None,
        sinfo=None,
        **kwargs,
    ):
        self.kwargs = kwargs
        super().__init__(
            name,
            level,
            pathname,
            lineno,
            msg,
            args,
            exc_info,
            func=None,
            sinfo=None,
            **kwargs,
        )
        request_context_var.get().get("trace_id", None)

        if request_context_var.get().get("trace_id", None):
            self.traceId = request_context_var.get().get("trace_id", None)
        else:
            self.traceId = DEFAULT_TRACE_ID

        tenant_id = None
        if request_context_var.get().get("tenant_id", None):
            tenant_id = request_context_var.get().get("tenant_id", None)

        if tenant_id:
            self.skip_hashing = False
        else:
            self.skip_hashing = True

    def getMessage(self):
        """Adds Fuzzy Hashing in logging.LogRecord.getMessage functionality

        logging.LogRecord.getMessage is the string interpolator for log messages
        that are passeed to logging.info family functions.

        The string intepolation happens using the % Operator.

        We are modifying the default behavior to incorporate fuzzy hashing to
        personal user data for ESL customers to comply with the Terms of Service
        we promise them.

        More details about it can be found here:
        https://www.notion.so/youdotcom/TPRD-ESL-Customer-s-Log-Hashing-2ec7b06819974ed687c01729e9a528db

        Args:
            self (LogRecord): The LogRecord Object used within python built-in
                                logging package

        Returns:
            str: Intepolated string with all the relavant information, including
                the additional context
        """

        # Use deepcopy to avoid mutating the original object. If we do mutate
        # the original object, the logs could be hashed multiple times if there
        # are multiple logger calls for the same object.
        # For example, {'log_vars': {'url': 'https:...'}} -> {‘log_vars’: {‘url’: {‘url_len’: {‘url_len_len’: {‘url_len_len_len’: 1, ‘url_len_len_hash’: 11}, ‘url_len_hash’: {‘url_len_hash_len’: 39, ‘url_len_hash_hash’: 190}}, ‘url_hash’: {‘url_hash_len’: {‘url_hash_len_len’: 2, ‘url_hash_len_hash’: 31676}, ‘url_hash_hash’: {‘url_hash_hash_len’: 39, ‘url_hash_hash_hash’: 155508814860}}}}}
        if isinstance(self.args, dict):
            context = {**deepcopy(self.kwargs), **(deepcopy(self.args) or {})}
        else:
            context = deepcopy(self.kwargs)

        if getattr(self, "skip_hashing", False):
            hashed_context = context
        else:
            hashed_context = self.hash_context(context)

        mapping_keys = set()
        if isinstance(self.msg, str):
            mapping_keys = self.extract_mapping_keys()

        used_context = {
            key: value for key, value in hashed_context.items() if key in mapping_keys
        }
        additional_context = {
            key: value
            for key, value in hashed_context.items()
            if key not in mapping_keys
        }

        msg = str(self.msg)
        if self.args and isinstance(self.args, tuple):
            # if args is a list, we are not going to use
            # used_context because we cannot mix list and dict
            # for %-opertor based string interpolation
            try:
                msg = msg % self.args
            except Exception as e:
                logger.error("Failed to interpolate message", exc_info=e)
                if len(self.args) > 0:
                    additional_context = {**additional_context, "args": self.args}
        elif isinstance(used_context, dict) and len(used_context) > 0:
            try:
                msg = msg % used_context
            except Exception as e:
                logger.error("Failed to interpolate message", exc_info=e)
                additional_context = {**additional_context, **used_context}

        if len(additional_context) > 0:
            msg += " ctx: " + str(additional_context)
        return msg

    def hash_context(self, context):
        return ContextHasher(context).generate()

    def extract_mapping_keys(self):
        regex_matches = re.findall(locale._percent_re, self.msg)  # type: ignore
        return set(
            filter(lambda x: x != "", map(lambda result: result[0], regex_matches))
        )


class HashedLogger(logging.Logger):
    def makeRecord(
        self,
        name,
        level,
        fn,
        lno,
        msg,
        args,
        exc_info,
        func=None,
        extra=None,
        sinfo=None,
        **kwargs,
    ):
        """
        A factory method which can be overridden in subclasses to create
        specialized LogRecords.
        """
        rv = logging._logRecordFactory(  # type: ignore
            name, level, fn, lno, msg, args, exc_info, func, sinfo, **kwargs
        )
        # for some mysterious reason, func is not set in the record
        # on initialization, setting it explicitly
        rv.funcName = func
        if extra is not None:
            for key in extra:
                if (key in ["message", "asctime"]) or (key in rv.__dict__):
                    raise KeyError("Attempt to overwrite %r in LogRecord" % key)

                # Allow overwriting to support `class record`
                if key in ["__filename", "__name", "__funcName", "__lineno"]:
                    rv.__dict__[key[2:]] = extra[key]
                else:
                    rv.__dict__[key] = extra[key]
        return rv

    def _log(self, level, msg, args, **kwargs):
        """
        Low-level logging routine which creates a LogRecord and then calls
        all the handlers of this logger to handle the record.
        """
        exc_info = kwargs.pop("exc_info", None)
        extra = kwargs.pop("extra", None)
        stack_info = kwargs.pop("stack_info", False)
        stacklevel = kwargs.pop("stacklevel", 1)

        reserved_keys = [
            "name",
            "level",
            "pathname",
            "fn",
            "lno",
            "lineno",
            "msg",
            "args",
            "exc_info",
            "func",
            "extra",
            "sinfo",
        ]

        for key in reserved_keys:
            if key in kwargs:
                kwargs.pop(key)
                logger.info(
                    "Deprecation Notice: '%(key)' is a reserved logging argument and will be ignored",
                    {"key": key},
                )

        sinfo = None
        if logging._srcfile:
            # IronPython doesn't track Python frames, so findCaller raises an
            # exception on some versions of IronPython. We trap it here so that
            # IronPython can use logging.
            try:
                fn, lno, func, sinfo = self.findCaller(stack_info, stacklevel)
            except ValueError:  # pragma: no cover
                fn, lno, func = "(unknown file)", 0, "(unknown function)"
        else:  # pragma: no cover
            fn, lno, func = "(unknown file)", 0, "(unknown function)"
        if exc_info:
            if isinstance(exc_info, BaseException):
                exc_info = (type(exc_info), exc_info, exc_info.__traceback__)
            elif not isinstance(exc_info, tuple):
                exc_info = sys.exc_info()
        record = self.makeRecord(
            self.name, level, fn, lno, msg, args, exc_info, func, extra, sinfo, **kwargs
        )
        self.handle(record)


class HashedLoggerAdapter(logging.LoggerAdapter):
    """HashedLoggerAdapter is used to monkey patch `logging.LoggerAdapter`

    **Purpose of `logging.LoggerAdapter`**

    It's an adapter to create a logger that adds additional context to
    `logging.Logger`.

    We could have used `logging.LoggerAdapter` to add additional context do
    hashing, but we decided against it because we heavily use `logging` package
    directly in our codebase.

    **Why do we need to monkey patch?**

    Refer `configure_hashed_logging()` for details.
    """

    def _log(
        self, level, msg, args, exc_info=None, extra=None, stack_info=False, **kwargs
    ):
        """
        Low-level log implementation, proxied to allow nested logger adapters.
        """
        return self.logger._log(
            level,
            msg,
            args,
            exc_info=exc_info,
            extra=extra,
            stack_info=stack_info,
            **kwargs,
        )


def configure_hashed_logging():
    """Enable Hashed Logger by Monkey Patching the `logging` package in-place

    **Why do we monkey patch?**

    There are two reasons for monkey patching:

    1. For the Syntactic Sugar

    We monkey patch because we are change the method signature of our
    `logging.info` and other functions to accept additional context in
    `**kwargs`, and it enable the following syntactic sugar:

    ```
    logger.info("Got Payload", payload={"hello", "world})
    ```

    The following changes introduce this syntactic sugar:

    ```
    logging.Logger._log = HashedLogger._log
    logging.Logger.makeRecord = HashedLogger.makeRecord
    logging.LoggerAdapter._log = HashedLoggerAdapter._log
    ```

    2. Due to the way `logging` package is designed

    we are monkey patching `logging.Logger._log` because we cannot subclass
    `logging.Logger` or change `logging.Logger`. This is because of how the
    logging library is designed.

    when you `import logging``, it creates `logging.root` which is an
    instance of `logging.Logger`, and is the root logger that is used
    everywhere.

    After this point (i.e. after `import logging`), changing the `Logger` or
    subclassing the `Logger` has no effect of `logging.root`.
    """

    # `logging.Logger._log` is the function that is called when you
    # use `logging.info`, `logging.debug` etc. So, eventhough it's private,
    # it's interface is public because it's signature is very close to the
    # public interface i.e. `logging.Logger.debug`, `logging.Logger.info`,
    # `logging.Logger.warning`, `logging.Logger.error`,
    # `logging.Logger.critical`

    # So, it should be ok to change `logging.Logger._log` to
    # `HashedLogger._log` and assume that it's likely that the method
    # signature will not change in future releases. Also, we have extensive
    # test cases to catch that if it does change.
    logging.Logger._log = HashedLogger._log  # type: ignore

    # `logging.Logger.makeRecord` is modified to capture kwargs from
    # `logging.Logger._log` and pass it to while initializing
    # `HashedLogRecord`

    # this can't be done by subclassing `logging.Logger` because that will
    # have no effect on the root logger.
    logging.Logger.makeRecord = HashedLogger.makeRecord  # type: ignore

    # `logging.LoggerAdapter._log` is changed to retain compatibility because
    # it internally calls `logging.Logger._log` LogAdapter is used to add
    # additional context to the logger by creating a new logger.
    logging.LoggerAdapter._log = HashedLoggerAdapter._log  # type: ignore

    # `logging._logRecordFactory` is just like `logging.root`, this was
    # instantiated when you `import logging`, and must be changed in-place, as
    # subclassing and changing `LogRecord` class will have no effect.

    # `HashedLogRecord`` is the class that is responsible for hashing the
    # desired context, and also printing the additional context alongside
    # the log message.
    logging._logRecordFactory = HashedLogRecord  # type: ignore
