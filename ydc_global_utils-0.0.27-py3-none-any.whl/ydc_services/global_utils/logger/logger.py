import logging
import os
from contextvars import ContextVar
from logging import Formatter, Handler, StreamHandler
from typing import Literal

import toml
from colorlog import ColoredFormatter
from pythonjsonlogger import jsonlogger

from ydc_services.global_utils.env import Env
from ydc_services.global_utils.logger.hashed_logger import configure_hashed_logging
from ydc_services.global_utils.logger.sumo_handler import SumoHandler

logger = logging.getLogger(__package__)


class HandlerFilter(logging.Filter):
    def __init__(self, handler_name: Literal["sumo", "console"]):
        super().__init__()
        self.handler_name = handler_name

    def filter(self, record):
        # If VERBOSE_LOGGING is on, allow all messages even if filter is set
        if os.environ.get("VERBOSE_LOGGING", "off") == "on":
            return True

        # Check if the record has "handler_name" attribute, set by "extra" field
        handler_name = getattr(record, "handler_name", None)
        if handler_name:
            return handler_name == self.handler_name

        # If handler_name is not set, allow all messages
        return True


class Logger:
    CONSOLE_FMT = "%(asctime)s: %(traceId)s: %(levelname)s: %(name)s: %(filename)s[%(lineno)d]: %(funcName)s(): %(message)s"
    SUMO_FMT = "%(asctime)s %(levelname)s %(env)s %(traceId)s %(service)s %(host)s %(pathname)s %(module)s %(filename)s %(funcName)s %(lineno)d %(message)s"
    MSG_ALREADY_CONFIGURED = "Logger already configured"
    __configured = False
    __handler = None

    @property
    def configured(self) -> bool:
        return self.__class__.__configured

    @configured.setter
    def configured(self, value: bool) -> None:
        self.__class__.__configured = value

    def __init__(
        self,
        service_name: str,
        host_name: str,
        request_context_var: ContextVar | None = None,
        custom_configs: dict[str, int] | None = None,
    ) -> None:
        self.service_name = service_name
        self.host_name = host_name
        self.request_context_var = request_context_var
        self.custom_configs = custom_configs

    def configure(self, env: Env, check_incognito=True) -> None:
        configure_hashed_logging()
        if os.environ.get("ALLOW_LOGS", "enabled") == "disabled" or (
            check_incognito and env.is_incognito()
        ):
            self.disable_logs()
        elif self.configured:
            logger.info(self.MSG_ALREADY_CONFIGURED)
        elif env.is_prod() or env.is_staging():
            self.configure_console(self.CONSOLE_FMT)
            self.configure_sumo()
        else:
            self.configure_console(
                "%(log_color)s" + self.CONSOLE_FMT, formatter=ColoredFormatter
            )

        # custom configs can override myproject.toml settings
        if self.custom_configs:
            for logger_name, level in self.custom_configs.items():
                logging.getLogger(logger_name).setLevel(level)

    def disable_logs(self) -> None:
        logger.info("Disabling logger for incognito")
        logging.disable(logging.CRITICAL)

    def configure_sumo(self) -> None:
        sumo_handler = self.make_sumo_handler()
        self.add_sumo_to_root(sumo_handler)
        self.add_sumo_to_servers(sumo_handler)
        self.configured = True
        self.__handler = sumo_handler
        logger.info("Sumo logger configured")

    def make_sumo_handler(self) -> Handler:
        handler = SumoHandler(self.service_name, self.host_name)
        formatter = self.make_sumo_formatter()
        handler.setFormatter(formatter)
        handler.addFilter(HandlerFilter(handler_name="sumo"))
        handler.setLevel(logging.INFO)
        return handler

    def make_sumo_formatter(self) -> Formatter:
        formatter = jsonlogger.JsonFormatter(fmt=self.SUMO_FMT, json_indent=1)
        return formatter

    def add_sumo_to_root(self, sumo_handler: Handler) -> None:
        root_logger = logging.getLogger()
        root_logger.addHandler(sumo_handler)
        root_logger.setLevel(logging.INFO)

    def add_sumo_to_servers(self, sumo_handler: Handler) -> None:
        for name in logging.root.manager.loggerDict:
            if "aiohttp" in name or "gunicorn" in name:
                logging.getLogger(name).addHandler(sumo_handler)

    def configure_console(
        self, console_fmt: str = CONSOLE_FMT, formatter: type[Formatter] = Formatter
    ) -> None:
        handler = StreamHandler()
        handler.setFormatter(formatter(fmt=console_fmt))
        handler.addFilter(HandlerFilter(handler_name="console"))

        self.configure_logging_from_pyproject_toml()

        # configure logging would have set the global log level
        # we are going to use that and apply it to our handler
        global_log_level = logging.root.getEffectiveLevel()
        logger.info(
            "Setting Root Logger Level: %(log_level)s",
            {"log_level": logging.getLevelName(global_log_level)},
        )

        # handler.setLevel(global_log_level)
        logging.basicConfig(level=global_log_level, force=True, handlers=[handler])
        self.configured = True
        self.__handler = handler
        logger.info("Console logger configured")

    def configure_logging_from_pyproject_toml(self):
        try:
            config = toml.load("logging.toml")
        except FileNotFoundError:
            logger.warning("logging.toml not found, using empty config")
            config = {}
        self._configure_recursive_logging(config.get("logging", {}))

    def _configure_recursive_logging(self, config: dict, prefix: str = ""):
        for config_name, config_value in config.items():
            if isinstance(config_value, dict):
                if prefix == "":
                    self._configure_recursive_logging(config_value, f"{config_name}")
                else:
                    self._configure_recursive_logging(
                        config_value, f"{prefix}.{config_name}"
                    )
            elif isinstance(config_value, str):
                if config_name == "level":
                    if prefix == "":
                        logging.basicConfig(level=config_value, force=True)
                    else:
                        logging.getLogger(prefix).setLevel(config_value)

    def reset(self) -> None:
        root_logger = logging.getLogger()
        if self.__handler is not None:
            root_logger.removeHandler(self.__handler)
        self.__handler = None
        self.configured = False
        logging.disable(logging.NOTSET)


def local_logger():
    # Utility function to quickly configure logger for local scripts
    env = Env()
    logger = Logger(service_name="local", host_name=env.get_hostname())
    logger.configure(env, check_incognito=False)
