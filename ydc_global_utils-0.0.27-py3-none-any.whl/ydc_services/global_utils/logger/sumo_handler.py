import logging
import os
from pprint import pformat

from requests_futures.sessions import FuturesSession

from ydc_services.global_utils.env import Env

sumo_session = FuturesSession()


class SumoHandler(logging.Handler):
    domain = "https://endpoint4.collection.sumologic.com/receiver/v1/http/"
    api_key = os.getenv("SUMO_BACKEND_API_KEY", "")
    url = domain + api_key

    def __init__(self, service_name: str, host_name: str):
        logging.Handler.__init__(self)
        self.env_name = Env().get_env()
        self.service_name = service_name
        self.host_name = host_name

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.add_custom_fields(record)
            payload = self.format(record)
            sumo_session.post(self.url, data=payload.encode("utf-8"))
        except Exception as exc:
            record.exc_info = exc
            self.handleError(record)

    def add_custom_fields(self, record: logging.LogRecord) -> None:
        record.env = self.env_name
        record.service = self.service_name
        record.host = self.host_name

    def handleError(self, record: logging.LogRecord) -> None:
        print(
            f"Error logging. Exc: {record.exc_info}. Record: {pformat(record.__dict__,indent=1)}"
        )
