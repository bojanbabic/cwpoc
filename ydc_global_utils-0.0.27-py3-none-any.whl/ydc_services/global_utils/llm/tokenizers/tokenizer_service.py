import logging
from collections import defaultdict
from typing import Any, Dict, Optional

from ydc_services.global_utils.concurrent.utils import CustomThreadPoolExecutor
from ydc_services.global_utils.instrument.new_relic import record, record_newrelic
from ydc_services.global_utils.llm.clients.claude3_chat import Claude3Chat
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm.clients.openai_o1_chat import OpenAIO1Chat
from ydc_services.global_utils.llm.constants import AI_MODELS
from ydc_services.global_utils.llm.tokenizers.anthropic_tokenizer import (
    get_anthropic_tokenizer_class,
)
from ydc_services.global_utils.llm.tokenizers.base import Tokenizer
from ydc_services.global_utils.llm.tokenizers.gemini_tokenizer import GeminiTokenizer
from ydc_services.global_utils.llm.tokenizers.heuristic_tokenizer import (
    HeuristicTokenizer,
)
from ydc_services.global_utils.llm.tokenizers.openai_tokenizer import OpenAITokenizer


class TokenizerService:
    def __init__(
        self,
        model_ids: Optional[list[str]] = None,
        fallback_tokenizer: Optional[Tokenizer] = None,
    ):
        if model_ids:
            self.model_ids = model_ids
        else:
            self.model_ids = [model.id for model in AI_MODELS]

        self.unique_tokenizer: dict[str, type[Tokenizer]] = {}
        self.tokenizer_to_models_map = defaultdict(list)

        for model_id in self.model_ids:
            (
                tokenizer,
                tokenizer_model,
            ) = self._get_representative_tokenizer_without_init(model_id=model_id)

            if tokenizer_model in self.unique_tokenizer:
                self.tokenizer_to_models_map[tokenizer_model].append(model_id)
                continue
            self.unique_tokenizer[tokenizer_model] = tokenizer

        self.tokenizers = [
            tokenizer(tokenizer_model)
            for tokenizer_model, tokenizer in self.unique_tokenizer.items()
        ]

        self.fallback_tokenizer = (
            fallback_tokenizer
            if fallback_tokenizer
            else HeuristicTokenizer(model_name="heuristic_sample")
        )

    @classmethod
    def _model_name_matches_tokenizer_family(cls, model_name: str, family: list[str]):
        return any(sub_string in model_name for sub_string in family)

    def _get_representative_tokenizer_without_init(self, model_id: str):
        # We return the tokenizer class and the model name of an representative model in the tokenizer family
        # This is to avoid initializing the multiple different tokenizer classes for each model
        # Tokenizer family = models that use the same tokenizer
        if self._model_name_matches_tokenizer_family(model_id, ["o1", "gpt_4o"]):
            model_name = list(OpenAIO1Chat.MODEL_NAME_TO_METADATA.keys())[0]
            return OpenAITokenizer, model_name

        elif self._model_name_matches_tokenizer_family(
            model_id, ["openai", "o1", "gpt"]
        ):
            model_name = list(OpenAIChat.MODEL_NAME_TO_METADATA.keys())[0]
            return OpenAITokenizer, model_name

        elif self._model_name_matches_tokenizer_family(model_id, ["claude"]):
            anthropic_tokenizer_class = get_anthropic_tokenizer_class()
            if anthropic_tokenizer_class == OpenAITokenizer:
                model_name = list(OpenAIChat.MODEL_NAME_TO_METADATA.keys())[0]
            else:
                model_name = list(Claude3Chat.MODEL_NAME_TO_METADATA.keys())[0]
                return anthropic_tokenizer_class, model_name

        elif self._model_name_matches_tokenizer_family(model_id, ["gemini"]):
            return GeminiTokenizer, "gemini"

        elif self._model_name_matches_tokenizer_family(
            model_id, ["llama", "command", "mistral"]
        ):
            return HeuristicTokenizer, "heuristic_sample"

        model_name = list(OpenAIChat.MODEL_NAME_TO_METADATA.keys())[0]
        return OpenAITokenizer, model_name

    @record("get_token_counts")
    def get_token_counts(
        self,
        text: str,
        enable_file_tokenizer_type: Optional[Dict[str, Any]] = None,
    ) -> dict[str, int]:
        token_counts = {}

        if not enable_file_tokenizer_type:
            enable_file_tokenizer_type = {"tokenizer_type": "heuristic"}

        tokenizer_type = enable_file_tokenizer_type.get("tokenizer_type", "heuristic")

        if tokenizer_type in ["sample", "full_text"]:
            with CustomThreadPoolExecutor(
                "file_tokenizers", should_wait_on_exit=False
            ) as executor:
                future_tokenizer_map = {}

                for tokenizer in self.tokenizers:
                    if tokenizer_type == "sample":
                        partition_size = enable_file_tokenizer_type.get("sample_size")
                    else:
                        partition_size = len(text)

                    if isinstance(partition_size, int) and len(text) >= partition_size:
                        partitioned_text = text[:partition_size]
                    else:
                        partitioned_text = text
                        partition_size = len(text)

                    def count_tokens_wrapper():
                        try:
                            return int(
                                (len(text) / partition_size)
                                * tokenizer.count_tokens(text=partitioned_text)
                            )
                        except Exception:
                            return self.fallback_tokenizer.count_tokens(text=text)

                    future = executor.submit(count_tokens_wrapper)
                    future_tokenizer_map[future] = tokenizer.model_name

                try:
                    for future in executor.as_futures_completed(timeout=10):
                        token_count = future.result()
                        tokenizer_model = future_tokenizer_map[future]
                        for model_id in self.tokenizer_to_models_map[tokenizer_model]:
                            token_counts[model_id] = token_count
                except Exception as e:
                    record_newrelic("tokenizer_service/error", 1)
                    logging.error(
                        "Error getting token counts",
                        exc_info=e,
                    )
                    fallback_token_count = self.fallback_tokenizer.count_tokens(text)
                    for model_id in self.model_ids:
                        if model_id not in token_counts:
                            token_counts[model_id] = fallback_token_count

        else:
            fallback_token_count = self.fallback_tokenizer.count_tokens(text)
            for model_id in self.model_ids:
                token_counts[model_id] = fallback_token_count

        # return token counts sorted by model name
        return dict(sorted(token_counts.items()))
