from typing import List

from ydc_services.global_utils.llm.tokenizers.base import Tokenizer


class HeuristicTokenizer(Tokenizer):
    CHAR_ENCODING_BYTES_PER_TOKEN = 3.6

    def __init__(self, model_name: str):
        self.model_name = model_name

    def count_tokens(self, text: str) -> int:
        return int(len(text.encode("utf-8")) / self.CHAR_ENCODING_BYTES_PER_TOKEN)

    def get_first_n_tokens_substring(self, text: str, n: int) -> str:
        return text[: int(n * self.CHAR_ENCODING_BYTES_PER_TOKEN)]

    def tokenize_str_in_subwords(self, text: str, errors: str = "strict") -> List[str]:
        # Split by spaces then add the spaces back
        subwords = text.split(" ")
        return [
            subword if i == len(subwords) - 1 else subword + " "
            for i, subword in enumerate(subwords)
        ]
