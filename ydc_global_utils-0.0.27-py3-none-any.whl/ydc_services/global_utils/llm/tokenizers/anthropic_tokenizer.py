import logging
import os
import time
from typing import List, Optional

import anthropic
import httpx

from ydc_services.global_utils.instrument.new_relic import record_newrelic
from ydc_services.global_utils.launchdarkly.utils import (
    get_launchdarkly_variation_from_request_context,
    initialize_launchdarkly_sdk,
)
from ydc_services.global_utils.llm.tokenizers.base import Tokenizer
from ydc_services.global_utils.llm.tokenizers.openai_tokenizer import OpenAITokenizer

# LD client needs to be initialized before importing this module.
LD_CLIENT = initialize_launchdarkly_sdk()

DEFAULT_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
DEFAULT_ESTIMATED_TOKENS = 3

logger = logging.getLogger(__package__)


def get_init_client():
    return anthropic.Anthropic(
        api_key=DEFAULT_API_KEY,
        http_client=httpx.Client(
            timeout=45,
            limits=httpx.Limits(max_connections=500, max_keepalive_connections=100),
        ),
        max_retries=0,
    )


def get_anthropic_tokenizer_class():
    enable_anthropic = get_launchdarkly_variation_from_request_context(
        flag_name="enableAnthropicTokenizer", default_value=False
    )
    if enable_anthropic:
        return AnthropicTokenizer
    else:
        return OpenAITokenizer


def init_anthropic_tokenizer(model_name):
    tokenizer_class = get_anthropic_tokenizer_class()
    return tokenizer_class(model_name=model_name)


class AnthropicTokenizer(Tokenizer):
    SHARED_CLIENT = get_init_client()

    def __init__(
        self,
        model_name: str,
        client_type: Optional[str] = None,
    ):
        self.model_name = model_name

        if not client_type:
            client_type = get_launchdarkly_variation_from_request_context(
                flag_name="enableSharedAnthropicTokenizer", default_value="not_shared"
            )

        # NOTE: We should look into reusing the same client across all tokenizers to reduce latency
        if client_type == "not_shared":
            self.client = get_init_client()
        else:
            self.client = self.SHARED_CLIENT

    def count_tokens(self, text: str) -> int:
        """
        Count the number of tokens in the text using the Anthropic tokenizer.
        """
        if text.isspace():
            # Avoid calling the API if the text is empty
            # Anthropic will return 400 {'type': 'invalid_request_error', 'message': 'messages: text content blocks must contain non-whitespace text'} for empty text
            return 0

        start = time.time()
        try:
            response = self.client.beta.messages.count_tokens(
                model=self.model_name,
                messages=[{"role": "user", "content": text}],
            )
            record_newrelic("count_anthropic_tokens_success", 1)
            return response.input_tokens
        except Exception as e:
            record_newrelic("count_anthropic_tokens_failure", 1)
            logger.error("Failed to count anthropic tokens", exc_info=e)
            return int(
                len(text) / DEFAULT_ESTIMATED_TOKENS
            )  # Conservative estimate in event of counting failure
        finally:
            record_newrelic("count_anthropic_tokens_latency", time.time() - start)

    def get_first_n_tokens_substring(self, text: str, n: int) -> str:
        """
        Find maximum characters within n tokens, calling count_tokens only twice.
        """
        try:
            original_token_count = self.count_tokens(text)

            if original_token_count <= n:
                record_newrelic("get_first_n_anthropic_tokens_success", 1)
                return text

            chars_per_token = len(text) / original_token_count
            estimated_chars = int(n * chars_per_token)

            truncated_text = text[:estimated_chars]

            current_token_count = self.count_tokens(truncated_text)

            if current_token_count > n:
                # If we have too many tokens, reduce the truncated text
                ratio = n / current_token_count
                estimated_chars = int(len(truncated_text) * ratio)
                truncated_text = text[:estimated_chars]
                record_newrelic("reduce_truncated_anthropic_tokens", 1)
            elif current_token_count < n:
                # If we have room for more tokens, increase the truncated text
                remaining_tokens = n - current_token_count
                additional_chars = int(remaining_tokens * chars_per_token)
                estimated_chars = min(len(text), len(truncated_text) + additional_chars)
                truncated_text = text[:estimated_chars]
                record_newrelic("increase_truncated_anthropic_tokens", 1)

            record_newrelic("get_first_n_anthropic_tokens_success", 1)
            return truncated_text
        except Exception as e:
            record_newrelic("get_first_n_anthropic_tokens_failure", 1)
            logger.error("Failed to get first n anthropic tokens", exc_info=e)
            return text[: n * DEFAULT_ESTIMATED_TOKENS]  # Conservative estimate

    def tokenize_str_in_subwords(self, text: str, errors: str = "strict") -> List[str]:
        # NOTE: Heuristic to split the text into subwords so we use the HeuristicTokenizer
        subwords = text.split(" ")
        return [
            subword if i == len(subwords) - 1 else subword + " "
            for i, subword in enumerate(subwords)
        ]


if __name__ == "__main__":
    tokenizer = AnthropicTokenizer("claude-3-5-sonnet-20240620")
    print(tokenizer.count_tokens("\n  "))
