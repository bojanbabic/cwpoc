from abc import ABC, abstractmethod
from typing import List


class Tokenizer(ABC):
    def __init__(self, model_name: str):
        self.model_name = model_name

    @abstractmethod
    def count_tokens(self, text: str) -> int:
        pass

    @abstractmethod
    def get_first_n_tokens_substring(self, text: str, n: int) -> str:
        pass

    @abstractmethod
    def tokenize_str_in_subwords(self, text: str, errors: str = "strict") -> List[str]:
        pass
