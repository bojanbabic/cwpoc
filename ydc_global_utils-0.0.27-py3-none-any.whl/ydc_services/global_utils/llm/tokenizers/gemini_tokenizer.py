import os
from typing import List

# This is needed to avoid protobuf crash. Need to set it before importing vertexai.preview.tokenization,
# since it imports protobuf under the hood.
# https://github.com/protocolbuffers/protobuf/issues/10051#issuecomment-1138417409
# https://github.com/deepset-ai/haystack/discussions/5234#discussioncomment-6383958
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"


from vertexai.preview import tokenization

from ydc_services.global_utils.llm.tokenizers.base import Tokenizer

# Downloading the model proto is expensive, so we cache it.
ENCODING_MAP = {"google/gemma": tokenization.get_tokenizer_for_model("gemini-1.5-pro")}


def _get_gemini_tokenizer_encoding(model_name: str):
    # NOTE: Currently google/gemma is used for all Gemini models.
    return ENCODING_MAP["google/gemma"]


class GeminiTokenizer(Tokenizer):
    def __init__(self, model_name: str):
        self.model_name = model_name

    def count_tokens(self, text: str) -> int:
        token_encoder = _get_gemini_tokenizer_encoding(self.model_name)
        return token_encoder.count_tokens(text).total_tokens

    def get_first_n_tokens_substring(self, text: str, n: int) -> str:
        """
        To avoid tokenizing long context, assume that the first n tokens substring will be inside
        the first n * max_chars_per_token_estimate chars of the text.
        """
        max_chars_per_token_estimate = 10
        truncated_text = text[: n * max_chars_per_token_estimate]
        return "".join(self.tokenize_str_in_subwords(truncated_text)[:n])

    def tokenize_str_in_subwords(self, text: str, errors: str = "strict") -> List[str]:
        token_encoder = _get_gemini_tokenizer_encoding(self.model_name)
        return [
            tok.decode("utf-8", errors=errors)
            for tok in token_encoder.compute_tokens(text).tokens_info[0].tokens
        ]
