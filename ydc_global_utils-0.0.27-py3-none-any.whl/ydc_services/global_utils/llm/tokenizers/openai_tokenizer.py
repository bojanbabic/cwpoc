from typing import List

import tiktoken

from ydc_services.global_utils.llm.tokenizers.base import Tokenizer

# A Tiktoken Encoding object is constructed by downloading the vocabulary from the remote server and caching it locally.
# It could be expensive to instantiate a new object initially. We create a global object and reuse it for now.
# https://github.com/openai/tiktoken/blob/1b9faf2779855124f05174adf1383e53689ed94b/tiktoken_ext/openai_public.py
TIKTOKEN_ENCODING_MAP = {
    "o200k_base": tiktoken.get_encoding("o200k_base"),
    "cl100k_base": tiktoken.get_encoding("cl100k_base"),
    "p50k_base": tiktoken.get_encoding("p50k_base"),
    "gpt2": tiktoken.get_encoding("gpt2"),
}


def _get_tokenizer_name(model_name, default_tokenizer_name: str = "cl100k_base"):
    try:
        tokenizer_name = tiktoken.encoding_name_for_model(model_name)
    except KeyError:
        tokenizer_name = None

    if tokenizer_name in TIKTOKEN_ENCODING_MAP:
        return tokenizer_name
    return default_tokenizer_name


def _get_tiktoken_encoding(model_name: str) -> tiktoken.Encoding:
    # IMPORTANT NOTE: Never initialize a new Tiktoken Encoding object inside a tokenizer class.
    # OpenAI's encoding objects will add ~6-25MB to the memory footprint for each class instantiation.
    # Only retrieve the encoding object when needed.
    tokenizer_name = _get_tokenizer_name(model_name)
    return TIKTOKEN_ENCODING_MAP[tokenizer_name]


class OpenAITokenizer(Tokenizer):
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.tokenizer_name = _get_tokenizer_name(model_name=model_name)

    def count_tokens(self, text: str) -> int:
        """
        Count the number of tokens in the text using the OpenAI tokenizer.
        """
        if self._should_use_safe_tiktoken_encode(text):
            return self._get_corrected_token_count_from_safe_tiktoken_encode(text)

        return len(
            _get_tiktoken_encoding(self.model_name).encode(text, disallowed_special=())
        )

    def get_first_n_tokens_substring(self, text: str, n: int) -> str:
        """
        To avoid the edge case, assume that the first n tokens substring will be inside
        the first n * max_chars_per_token_estimate chars of the text.
        """
        max_chars_per_token_estimate = 8
        truncated_text = text[: n * max_chars_per_token_estimate]
        return "".join(self.tokenize_str_in_subwords(truncated_text)[:n])

    def tokenize_str_in_subwords(self, text: str, errors: str = "replace") -> List[str]:
        tokens = self._encode_with_tiktoken(text)
        token_encoder = _get_tiktoken_encoding(self.model_name)
        return [
            token_encoder.decode_single_token_bytes(tok).decode("utf-8", errors=errors)
            for tok in tokens
        ]

    @classmethod
    def _chunk_string(cls, s: str, chunk_size: int) -> List[str]:
        """
        Chunks a string into substrings of length chunk_size.
        """
        return [s[i : i + chunk_size] for i in range(0, len(s), chunk_size)]

    def _get_corrected_token_count_from_safe_tiktoken_encode(
        self, text: str, chunk_size: int = 200
    ) -> int:
        """
        The amount of overestimated number of tokens is ~ 2/3 * len(text) / chunk_size.
        Correct the overestimated number of tokens from the safe tiktoken encode.
        """
        tokens = self._safe_tiktoken_encode(text, chunk_size)
        return len(tokens) - round(2 / 3 * len(text) / chunk_size)

    def _encode_with_tiktoken(self, text: str, chunk_size: int = 200) -> List[int]:
        if self._should_use_safe_tiktoken_encode(text):
            return self._safe_tiktoken_encode(text, chunk_size)
        return _get_tiktoken_encoding(self.model_name).encode(
            text, disallowed_special=()
        )

    def _safe_tiktoken_encode(self, text: str, chunk_size: int = 200) -> List[int]:
        """
        Split the string into chunks of size chunk_size before encoding the tokens.
        This is to prevent the tokenizer from stalling the request if the string doesn't have many whitespace/line break characters.
        Without the characters, the tokenizer won't be able to split the text and parallelize the encoding.

        The smaller the chunk size, the faster it is on the edge cases, but will result in less accurate set of tokens.
        The amount of overestimated number of tokens is ~ 2/3 * len(text) / chunk_size.
        Source: https://github.com/openai/tiktoken/issues/195
        """
        tokens = []
        token_encoder = _get_tiktoken_encoding(self.model_name)
        for chunk in self._chunk_string(text, chunk_size):
            tokens.extend(token_encoder.encode(chunk, disallowed_special=()))
        return tokens

    @classmethod
    def _should_use_safe_tiktoken_encode(cls, text: str):
        """If the gap between each whitespaces or line breaks is too big, then it's better to use the safe tiktoken encode."""
        return any([len(chunk) > 500 for chunk in text.split()])
