from abc import ABC, abstractmethod


class LlmContext(ABC):
    @abstractmethod
    def form_llm_context(self, template: str = "", **kwargs) -> str:
        ...
