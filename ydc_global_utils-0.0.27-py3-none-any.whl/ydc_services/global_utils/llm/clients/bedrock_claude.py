from typing import (
    Iterable,
    List,
    Optional,
    Type,
)

import anthropic
from anthropic.types import (
    Message,
    MessageParam,
    MessageStreamEvent,
)

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import ModelMetadata
from ydc_services.global_utils.llm.clients.claude3_chat import Claude3Chat
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.clients.shared_bedrock import (
    BedrockEast1,
    BedrockWest2,
)


class BedrockClaude3Chat(Claude3Chat):
    MODEL_NAME_TO_METADATA = {
        "anthropic.claude-3-haiku-20240307-v1:0": ModelMetadata(
            model_name="anthropic.claude-3-haiku-20240307-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.00000025,
            output_token_price=0.00000125,
        ),
        "anthropic.claude-3-5-haiku-20241022-v1:0": ModelMetadata(
            model_name="anthropic.claude-3-5-haiku-20241022-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.0000008,
            output_token_price=0.000004,
        ),
        "anthropic.claude-3-sonnet-20240229-v1:0": ModelMetadata(
            model_name="anthropic.claude-3-sonnet-20240229-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "anthropic.claude-3-5-sonnet-20240620-v1:0": ModelMetadata(
            model_name="anthropic.claud-3-5-sonnet-20240620-v1:0",
            max_context_tokens=200000,
            max_output_tokens=8192,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "anthropic.claude-3-5-sonnet-20241022-v2:0": ModelMetadata(
            model_name="anthropic.claude-3-5-sonnet-20241022-v2:0",
            max_context_tokens=200000,
            max_output_tokens=8192,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "anthropic.claude-3-opus-20240229-v1:0": ModelMetadata(
            model_name="anthropic.claude-3-opus-20240229-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.000015,
            output_token_price=0.000075,
        ),
        # Models that can be accessed across different US regions
        # See: https://github.com/aws-samples/amazon-bedrock-workshop/blob/main/06_OpenSource_examples/cross-region-inference/Getting_started_with_Cross-region_Inference.ipynb
        "us.anthropic.claude-3-haiku-20240307-v1:0": ModelMetadata(
            model_name="us.anthropic.claude-3-haiku-20240307-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.00000025,
            output_token_price=0.00000125,
        ),
        "us.anthropic.claude-3-5-haiku-20241022-v1:0": ModelMetadata(
            model_name="us.anthropic.claude-3-5-haiku-20241022-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.0000008,
            output_token_price=0.000004,
        ),
        "us.anthropic.claude-3-5-sonnet-20241022-v2:0": ModelMetadata(
            model_name="us.anthropic.claude-3-5-sonnet-20241022-v2:0",
            max_context_tokens=200000,
            max_output_tokens=8192,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "us.anthropic.claude-3-7-sonnet-20250219-v1:0": ModelMetadata(
            model_name="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "us.anthropic.claude-3-7-sonnet-20250219-v1:0": ModelMetadata(
            model_name="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
            max_context_tokens=200000,
            max_output_tokens=128000,
            input_token_price=0.000003,
            output_token_price=0.000015,
            thinking_start_token="<think>",
            thinking_end_token="</think>",
        ),
    }

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[List[MessageParam]] = None,  # type: ignore[override]
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Message | Iterable[MessageStreamEvent]:
        system = None

        # "claude-3-5-sonnet" is only available in Bedrock East 1 region right now. The rest are in Bedrock West 2.
        bedrock_region: Type[BedrockEast1] | Type[BedrockWest2] = (
            BedrockEast1
            if self.model_name == "anthropic.claude-3-5-sonnet-20240620-v1:0"
            else BedrockWest2
        )
        if prompt is not None:
            messages = self.prompt_to_messages(prompt, uploaded_image_files_context)

        if messages is not None:
            system, messages = self._separate_system_from_conv_messages(messages)

        kwargs = {}
        if system is not None:
            kwargs["system"] = system
        if self.thinking_config:
            kwargs["thinking"] = self.thinking_config

        if self.client_type == "not_shared":
            client = anthropic.AnthropicBedrock(
                aws_access_key=bedrock_region.DEFAULT_BEDROCK_ACCESS_KEY,
                aws_secret_key=bedrock_region.DEFAULT_BEDROCK_SECRET_KEY,
                aws_region=bedrock_region.REGION_NAME,
                timeout=self.request_timeout,
                # Disable retries
                # https://github.com/anthropics/anthropic-sdk-python/blob/1f110a29db91f1857743ac5841977d709fae2712/README.md?plain=1#L267
                max_retries=self.max_retries,
            )
        else:
            client = bedrock_region.SHARED_ANTHROPIC_CLIENT

        return client.messages.create(  # type: ignore[call-overload]
            messages=messages,
            model=self.model_name,
            stream=self.stream,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            **kwargs,
        )

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Bedrock Claude pattern: "Input is too long for requested model"
        if (
            isinstance(error, anthropic.BadRequestError)
            and "Input is too long for requested model" in error_message
        ):
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). Unable to determine exact excess token count."
            raise TokenLimitExceededException(message, None, class_name, model_name)

        return False


if __name__ == "__main__":
    client = BedrockClaude3Chat(
        model_name="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        max_output_tokens=40960,
        temperature=1.0,
        request_timeout=30,
        stream=True,
        thinking_config={"type": "enabled", "budget_tokens": 32000},
    )
    response = client.get_token_generator(
        messages=[{"role": "user", "content": "Why is the sky blue?"}]
    )
    for token in response:
        print(token)
