import sys
from typing import (
    Dict,
    Iterable,
    List,
    Optional,
)

from openai.types.completion import Completion

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    Messages,
    ModelMetadata,
    PromptOrMessages,
)
from ydc_services.global_utils.llm.clients.openai_client_mixin import OpenAIClientMixin
from ydc_services.global_utils.llm.tokenizers.openai_tokenizer import OpenAITokenizer


class OpenAICompletion(LLM[Completion, Completion], OpenAIClientMixin):
    MODEL_NAME_TO_METADATA = {
        "gpt-3.5-turbo-instruct": ModelMetadata(
            model_name="gpt-3.5-turbo-instruct",
            max_context_tokens=4096,
            max_output_tokens=4095,
            input_token_price=0.0000015,
            output_token_price=0.000002,
        ),
        "davinci-002": ModelMetadata(
            model_name="davinci-002",
            max_context_tokens=16384,
            max_output_tokens=4095,
            input_token_price=0.0000015,
            output_token_price=0.000002,
        ),
        "babbage-002": ModelMetadata(
            model_name="babbage-002",
            max_context_tokens=16384,
            max_output_tokens=4095,
            input_token_price=0.0000015,
            output_token_price=0.000002,
        ),
    }

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool = False,
        max_context_tokens: int = sys.maxsize,
        stop: Optional[str | List[str]] = None,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        logprobs: Optional[int] = None,
        client_type: str = "not_shared",
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            OpenAITokenizer(model_name),
        )
        self.request_timeout = request_timeout
        self.stop = stop
        self.top_p = top_p
        self.frequency_penalty = frequency_penalty
        self.presence_penalty = presence_penalty
        self.logprobs = logprobs
        self.client_type = client_type

    @classmethod
    def get_text_from_response(cls, response: Completion) -> str:
        return response.choices[0].text

    @classmethod
    def get_token_to_logprob_sequence(
        cls, response: Completion
    ) -> List[Dict[str, float]]:
        assert response.choices[0].logprobs, "No logprobs in response. "
        "Make sure to set logprobs=True."
        assert response.choices[
            0
        ].logprobs.top_logprobs, "No top_logprobs in response. "
        "Make sure to set top_logprobs>0."
        return response.choices[0].logprobs.top_logprobs

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        raise NotImplementedError

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Completion | Iterable[Completion]:
        if not prompt:
            raise ValueError("Prompt is required for OpenAICompletion")

        client = self._get_client(
            self.client_type,
            self.model_name,
        )

        return client.completions.create(
            prompt=prompt,
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
            top_p=self.top_p,
            frequency_penalty=self.frequency_penalty,
            presence_penalty=self.presence_penalty,
            logprobs=self.logprobs,
        )

    def _yield_token_from_generator(
        self, generator: Iterable[Completion]
    ) -> Iterable[str]:
        for response in generator:
            yield response.choices[0].text
            if response.choices[0].finish_reason is not None:
                break

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response: Completion | Iterable[Completion],
    ):
        if not self.stream:
            assert isinstance(response, Completion)
            if response.usage:
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    num_input_tokens=response.usage.prompt_tokens,
                )
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=response.usage.completion_tokens,
                )
            else:
                CostTracker.increment_input_count(self.model_name, prompt_or_messages)
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=self.tokenizer.count_tokens(
                        self.get_text_from_response(response)
                    ),
                )
        else:
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                get_token_count=self.tokenizer.count_tokens,
            )
            response = CostTracker.wrap_with_increment_event(
                response,  # type: ignore[arg-type]
                self.model_name,
            )

        return response
