import base64
import logging
import os
import sys
from typing import Iterable, List, Optional

import anthropic
import google.auth
import google.auth.transport.requests
from anthropic import NOT_GIVEN, AnthropicVertex, NotGiven
from anthropic.types import MessageParam
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import ModelMetadata
from ydc_services.global_utils.llm.clients.claude3_chat import Claude3Chat

logger = logging.getLogger(__package__)


class VertexClaude(Claude3Chat):
    CREDENTIALS_PATH = "/tmp/CARvRa3Mmx3g"  # Deliberately nondescript path
    PROJECT = "gemini-413421"
    LOCATION = "us-east5"

    MODEL_NAME_TO_METADATA = {
        "claude-3-5-sonnet@20240620": ModelMetadata(
            model_name="claude-3-5-sonnet@20240620",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
    }

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        temperature: float,
        request_timeout: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        stop: List[str] | NotGiven = NOT_GIVEN,
        client_type: str = "not_shared",  # not used
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            temperature,
            request_timeout,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
            client_type=client_type,
        )
        self._ensure_credentials()
        self.client = self._setup_client()

    def _ensure_credentials(self) -> None:
        """Ensure credentials file exists and is properly set up."""
        # Check if credentials already exist and are valid
        if (
            os.environ.get("GOOGLE_APPLICATION_CREDENTIALS") == self.CREDENTIALS_PATH
            and os.path.exists(self.CREDENTIALS_PATH)
            and os.path.getsize(self.CREDENTIALS_PATH) > 0
        ):
            return

        # Get API key from environment
        api_key = os.getenv("GOOGLE_GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_GEMINI_API_KEY environment variable not set")

        # Create credentials file with restricted permissions
        try:
            with os.fdopen(
                os.open(
                    self.CREDENTIALS_PATH,
                    os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                    mode=0o600,  # File is private
                ),
                "wb",
            ) as fd:
                fd.write(base64.b64decode(api_key))

            # Set environment variable to point to credentials file
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self.CREDENTIALS_PATH
        except Exception as e:
            raise RuntimeError(f"Failed to create credentials file: {e}")

    def _setup_client(self) -> AnthropicVertex:
        # Get Google credentials with explicit cloud platform scope
        creds, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req)
        return AnthropicVertex(
            region=self.LOCATION,
            project_id=self.PROJECT,
            access_token=creds.token,
        )

    def _refresh_client(self):
        # Credentials expire after 1H, so we have to refresh client to use this class instance
        self.client = self._setup_client()

    @classmethod
    def get_text_from_response(cls, response: ChatCompletion) -> str:
        return response.choices[0].message.content or ""

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[List[MessageParam]] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ChatCompletion | Iterable[ChatCompletionChunk]:
        # Handle prompt format if provided
        if prompt is not None:
            messages = self.prompt_to_messages(prompt, uploaded_image_files_context)

        assert messages is not None

        system, messages = self._separate_system_from_conv_messages(messages)

        def make_request_fn():
            return self.client.messages.create(
                model=self.MODEL_NAME_TO_METADATA[self.model_name].model_name,
                system=system,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                stream=self.stream,
                stop_sequences=self.stop,
            )

        try:
            return make_request_fn()  # type: ignore
        except anthropic.AuthenticationError:
            logger.warning("Anthropic auth error, refreshing client", exc_info=True)
            self._refresh_client()
            return make_request_fn()  # type: ignore


if __name__ == "__main__":
    client = VertexClaude(
        model_name="claude-3-5-sonnet@20240620",
        request_timeout=10,
        max_output_tokens=1024,
        stream=True,
        temperature=0,
    )
    for token in client.get_token_generator(
        messages=[
            {
                "role": "user",
                "content": "Hello, world!",
            }
        ]
    ):
        print(token)
