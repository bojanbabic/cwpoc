import json
import re
import sys
import uuid
from typing import (
    Dict,
    Iterable,
    List,
    Literal,
    Optional,
    Type,
    TypeVar,
)

import openai
from openai import NOT_GIVEN, NotGiven
from openai.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    completion_create_params,
)
from pydantic import BaseModel

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import LLM, Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.clients.mixins import StandardCostTrackerMixin
from ydc_services.global_utils.llm.clients.openai_client_mixin import OpenAIClientMixin
from ydc_services.global_utils.llm.tokenizers.base import Tokenizer
from ydc_services.global_utils.llm.tokenizers.openai_tokenizer import OpenAITokenizer
from ydc_services.global_utils.llm.tools.core import Tool
from ydc_services.global_utils.llm.tools.schemas import ToolCallInput
from ydc_services.global_utils.llm_services.prompt_constants import T3

StructuredResponseT = TypeVar("StructuredResponseT", bound=BaseModel)


class OpenAIChat(
    OpenAIClientMixin,
    StandardCostTrackerMixin,
    LLM[ChatCompletion, ChatCompletionChunk],
):
    # Model specs: https://platform.openai.com/docs/models/continuous-model-upgrades
    # NOTE on OAI's max_output_tokens: Not directly documented, but it seems to be 4095 for all models: https://community.openai.com/t/what-is-the-maximum-response-length-output-tokens-for-each-gpt-model/524066/5
    # Pricing: https://openai.com/pricing
    MODEL_NAME_TO_METADATA = {
        "gpt-3.5-turbo": ModelMetadata(
            model_name="gpt-3.5-turbo",
            max_context_tokens=16385,
            max_output_tokens=4095,
            input_token_price=0.0000015,
            output_token_price=0.000002,
        ),
        # DEPRECATED: Use gpt-3.5-turbo-0125 instead
        "gpt-3.5-turbo-0613": ModelMetadata(
            model_name="gpt-3.5-turbo-0613",
            max_context_tokens=16385,
            max_output_tokens=4095,
            input_token_price=0.000001,
            output_token_price=0.000002,
        ),
        "gpt-3.5-turbo-1106": ModelMetadata(
            model_name="gpt-3.5-turbo-1106",
            max_context_tokens=16385,
            max_output_tokens=4095,
            input_token_price=0.000001,
            output_token_price=0.000002,
        ),
        "gpt-3.5-turbo-0125": ModelMetadata(
            model_name="gpt-3.5-turbo-0125",
            max_context_tokens=16385,
            max_output_tokens=4095,
            input_token_price=0.0000005,
            output_token_price=0.0000015,
        ),
        "gpt-3.5-turbo-0301": ModelMetadata(
            model_name="gpt-3.5-turbo-0301",
            max_context_tokens=16385,
            max_output_tokens=4095,
            input_token_price=0.0000015,
            output_token_price=0.000002,
        ),
        "gpt-4": ModelMetadata(
            model_name="gpt-4",
            max_context_tokens=8192,
            max_output_tokens=4095,
            input_token_price=0.00003,
            output_token_price=0.00006,
        ),
        "gpt-4-32k": ModelMetadata(
            model_name="gpt-4-32k",
            max_context_tokens=32768,
            max_output_tokens=4095,
            input_token_price=0.00006,
            output_token_price=0.00012,
        ),
        "gpt-4-turbo-2024-04-09": ModelMetadata(
            model_name="gpt-4-turbo-2024-04-09",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.00001,
            output_token_price=0.00003,
        ),
        "gpt-4-1106-preview": ModelMetadata(
            model_name="gpt-4-1106-preview",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.00001,
            output_token_price=0.00003,
        ),
        "gpt-4-0125-preview": ModelMetadata(
            model_name="gpt-4-0125-preview",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.00001,
            output_token_price=0.00003,
        ),
        "gpt-4-vision-preview": ModelMetadata(
            model_name="gpt-4-vision-preview",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.00001,
            output_token_price=0.00003,
        ),
        "gpt-4o-2024-08-06": ModelMetadata(
            model_name="gpt-4o-2024-08-06",
            max_context_tokens=128000,
            max_output_tokens=16384,
            input_token_price=0.0000025,
            output_token_price=0.000010,
        ),
        "gpt-4o-2024-05-13": ModelMetadata(
            model_name="gpt-4o-2024-05-13",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.000005,
            output_token_price=0.000015,
        ),
        "gpt-4o-2024-11-20": ModelMetadata(
            model_name="gpt-4o-2024-11-20",
            max_context_tokens=128000,
            max_output_tokens=16384,
            input_token_price=0.000005,
            output_token_price=0.000015,
        ),
        "gpt-4o": ModelMetadata(
            model_name="gpt-4o",
            max_context_tokens=128000,
            max_output_tokens=16384,
            input_token_price=0.000005,
            output_token_price=0.000015,
        ),
        "gpt-4o-mini-2024-07-18": ModelMetadata(
            model_name="gpt-4o-mini-2024-07-18",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.00000015,
            output_token_price=0.0000006,
        ),
        "gpt-4o-mini": ModelMetadata(
            model_name="gpt-4o-mini",
            max_context_tokens=128000,
            max_output_tokens=4095,
            input_token_price=0.00000015,
            output_token_price=0.0000006,
        ),
        "gpt-4.5-preview-2025-02-27": ModelMetadata(
            model_name="gpt-4.5-preview-2025-02-27",
            max_context_tokens=128000,
            max_output_tokens=16384,
            input_token_price=0.000075,
            output_token_price=0.00015,
        ),
        "gpt-4.5-preview": ModelMetadata(
            model_name="gpt-4.5-preview",
            max_context_tokens=128000,
            max_output_tokens=16384,
            input_token_price=0.000075,
            output_token_price=0.00015,
        ),
    }

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        *,
        stream: bool = False,
        max_context_tokens: int = sys.maxsize,
        stop: Optional[str | List[str]] = T3.GENERATION_STOP_TOKEN,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        response_type: Literal["text", "json_object"] = "text",
        logprobs: Optional[bool] = False,
        top_logprobs: Optional[int] = None,
        tools: Optional[List[Tool]] = None,
        tool_choice: Optional[Literal["auto", "none", "required"]] = None,
        client_type: str = "not_shared",
        response_format: Type[StructuredResponseT]
        | completion_create_params.ResponseFormat
        | NotGiven = NOT_GIVEN,
        tokenizer: Optional[Tokenizer] = None,
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            tokenizer=tokenizer or OpenAITokenizer(model_name),
        )
        self.request_timeout = request_timeout
        self.stop = stop
        self.top_p = top_p
        self.frequency_penalty = frequency_penalty
        self.presence_penalty = presence_penalty
        self.logprobs = logprobs
        self.top_logprobs = top_logprobs
        self.tools = tools
        self.tool_schemas = (
            [tool.openai_tool_schema for tool in tools] if tools is not None else tools
        )
        self.tool_choice = tool_choice
        self.client_type = client_type
        self.response_format = {"type": response_type}
        if response_format != NOT_GIVEN:
            self.response_format = response_format  # type: ignore

        if self.stream:
            self.stream_options = {"include_usage": True}
        else:
            self.stream_options = None  # type: ignore

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        # NOTE: This is a bad pattern in which we first pack all prompts into a string
        # and then decode back into a list of json dicts
        # Should be refactored to use a list of json dicts from the beginning

        # NOTE: Popular LLM separation tokens often are <|im_start|> and <|im_end|>
        # Because of this, user can use that as a separator token for their own custom prompt,
        # or data from the search results could contain that token.
        # To avoid this, we use a modified separator token for our own prompt to message parsing.
        formatted_messages = []
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                agent = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                formatted_messages.append({"role": agent, "content": message})
        if uploaded_image_files_context:
            image_message_content = cls.convert_image_files_context_to_messages(
                uploaded_image_files_context
            )
            formatted_messages.append(
                {"role": "user", "content": image_message_content}  # type: ignore
            )
        return formatted_messages  # type: ignore

    @classmethod
    def convert_image_files_context_to_messages(
        cls, uploaded_image_files_context: List[FileContextOrError]
    ) -> List:
        image_message_content = []
        for image_file_context in uploaded_image_files_context:
            image_bytes = image_file_context.content
            url = f"data:image/jpeg;base64,{image_bytes}"
            image_message_content.append(
                {"type": "image_url", "image_url": {"url": url}}
            )
        return image_message_content

    @classmethod
    def get_text_from_response(cls, response: ChatCompletion) -> str:
        assert response.choices[0].message.content is not None
        return response.choices[0].message.content

    @classmethod
    def get_tool_calls_from_response(
        cls, response: ChatCompletion
    ) -> List[ToolCallInput]:
        assert response.choices[0].message.tool_calls is not None
        return [
            ToolCallInput(
                call_id=str(uuid.uuid4()),
                tool_name=tool_call.function.name,
                tool_inputs=json.loads(tool_call.function.arguments),
            )
            for tool_call in response.choices[0].message.tool_calls
        ]

    @classmethod
    def get_token_to_logprob_sequence(
        cls, response: ChatCompletion
    ) -> List[Dict[str, float]]:
        assert response.choices[0].logprobs, "No logprobs in response. "
        "Make sure to set logprobs=True."

        assert (
            response.choices[0].logprobs.content is not None
        ), "No content in logprobs."

        assert response.choices[0].logprobs.content[0].top_logprobs, "No top_logprobs. "
        "Make sure to set top_logprobs>0."

        token_to_logprob_sequence = []
        for step in response.choices[0].logprobs.content:
            token_to_logprob = {
                choice.token: choice.logprob for choice in step.top_logprobs
            }

            token_to_logprob_sequence.append(token_to_logprob)

        return token_to_logprob_sequence

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ChatCompletion | Iterable[ChatCompletionChunk]:
        messages = (
            self.prompt_to_messages(
                prompt, uploaded_image_files_context=uploaded_image_files_context
            )
            if prompt
            else messages
        )
        client = self._get_client(self.client_type, self.model_name)

        resp = client.chat.completions.create(  # type: ignore
            messages=messages,
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stream_options=self.stream_options,
            stop=self.stop,
            top_p=self.top_p,
            frequency_penalty=self.frequency_penalty,
            presence_penalty=self.presence_penalty,
            response_format=self.response_format,
            logprobs=self.logprobs,
            top_logprobs=self.top_logprobs,
            tools=self.tool_schemas,
            tool_choice=self.tool_choice,
        )
        if self.client_type != "shared" and not self.stream:
            client.close()
        return resp

    @classmethod
    def _get_request_id(
        cls, response: ChatCompletion | ChatCompletionChunk
    ) -> Optional[str]:
        return response.id

    # TODO: Add proper type hinting for get_structured_response
    def get_structured_response(
        self,
        messages: Optional[Messages] = None,
    ) -> StructuredResponseT:  # type: ignore
        client = self._get_client(self.client_type, self.model_name)
        resp = client.beta.chat.completions.parse(
            messages=messages,  # type: ignore
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            response_format=self.response_format,  # type: ignore
        )
        self._wrap_with_cost_tracker(messages, resp)  # type: ignore
        return resp.choices[0].message.parsed  # type: ignore

    def _yield_token_from_generator(
        self, generator: Iterable[ChatCompletionChunk]
    ) -> Iterable[str]:
        for response in generator:
            if (
                len(response.choices) > 0
                and response.choices[0].delta
                and response.choices[0].delta.content
            ):
                yield response.choices[0].delta.content

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # OpenAI pattern: "string too long. Expected a string with maximum length 1048576, but got a string with length 2000000 instead."
        if (
            isinstance(error, openai.BadRequestError)
            and "string too long" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)

            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # OpenAI pattern: "string too long. Expected a string with maximum length 1048576, but got a string with length 2000000 instead."
        match = re.search(
            r"string too long. Expected a string with maximum length (\d+), but got a string with length (\d+) instead.",
            error_message,
        )
        if match:
            return abs(int(match.group(2)) - int(match.group(1)))
        return None
