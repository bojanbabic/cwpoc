import logging
import os
import sys
from typing import List, Literal, Optional

import openai
from pydantic import BaseModel, Field

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm.tools.core import Tool
from ydc_services.global_utils.llm.tools.schemas import ToolCall

logger = logging.getLogger(__package__)


class GrokChat(OpenAIChat):
    MODEL_NAME_TO_METADATA = {
        "grok-2-1212": ModelMetadata(
            model_name="grok-2-1212",
            max_context_tokens=131072,
            max_output_tokens=4096,
        ),
    }
    BASE_URL = "https://api.x.ai/v1"
    DEFAULT_API_KEY = os.environ.get("GROK_API_KEY")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        stream: bool,
        temperature: float,
        max_context_tokens: int = sys.maxsize,
        stop: Optional[str | List[str]] = None,
        tools: Optional[List[Tool]] = None,
        tool_choice: Optional[Literal["auto", "none", "required"]] = None,
        # Not yet implemented
        client_type: str = "not_shared",
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
            tools=tools,
            tool_choice=tool_choice,
            client_type=client_type,
        )
        if model_name not in ["grok-2-1212"] and tools is not None:
            logger.warning(
                "Model does not seem to support tools. Please double check. Ignoring tools for now.",
                model_name=model_name,
            )
        self.api_key = GrokChat.DEFAULT_API_KEY

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        messages = (
            self.prompt_to_messages(prompt, uploaded_image_files_context)
            if prompt
            else messages
        )
        client = openai.OpenAI(api_key=self.api_key, base_url=self.BASE_URL)

        return client.chat.completions.create(
            messages=messages,  # type: ignore[arg-type]
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
            tools=self.tool_schemas,  # type: ignore
            tool_choice=self.tool_choice,  # type: ignore
        )


if __name__ == "__main__":

    class OpenWebsiteTool(Tool):
        class OpenWebsiteInput(BaseModel):
            url: str = Field(description="A URL", example="https://x.ai/")

        tool_call_cls = ToolCall[Literal["open_website"], OpenWebsiteInput, str]

        def __init__(self):
            super().__init__(
                name="open_website",
                description="Open a website and return the HTML as a string",
            )

        def run_tool(self, inputs: OpenWebsiteInput) -> str:
            return "HTML"

    class ClickTool(Tool):
        class ClickInput(BaseModel):
            html: str = Field(description="A HTML")
            button: str = Field(
                description="A text description of a button on the html page"
            )

        tool_call_cls = ToolCall[Literal["click"], ClickInput, str]

        def __init__(self):
            super().__init__(
                name="click",
                description="Click any button on a website and returns the new HTML",
            )

        def run_tool(self, inputs: ClickInput) -> str:
            return "HTML"

    llm_client = GrokChat(
        model_name="grok-beta",
        temperature=0.0,
        request_timeout=10.0,
        max_output_tokens=4096,
        stream=False,
        tools=[OpenWebsiteTool(), ClickTool()],
        tool_choice="required",
    )

    response = llm_client.get_response(
        messages=[
            {
                "role": "system",
                "content": "You are a helpful webpage navigation assistant. Use the supplied tools to assist the user.",
            },
            {
                "role": "user",
                "content": "Hi, can you go to the career page of xAI website?",
            },
        ],
    )
    text_response = llm_client.get_text_from_response(response)
    tool_response = llm_client.get_tool_calls_from_response(response)
    print(text_response)
    print(tool_response)
