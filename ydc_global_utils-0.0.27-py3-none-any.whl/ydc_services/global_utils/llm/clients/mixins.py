from typing import Any, Callable, Iterable, List, Optional

from openai.types.chat import ChatCompletion, ChatCompletionChunk

from ydc_services.global_utils.file_upload.schemas import (
    FileContextOrError,
)
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import PromptOrMessages
from ydc_services.global_utils.llm.tokenizers.base import Tokenizer


class StandardCostTrackerMixin:
    stream: bool
    model_name: str
    get_text_from_response: Callable[[Any], str]
    tokenizer: Tokenizer

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response: ChatCompletion | Iterable[ChatCompletionChunk],
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if not self.stream:
            assert isinstance(response, ChatCompletion)
            if response.usage:
                if (
                    response.usage.prompt_tokens_details
                    and response.usage.prompt_tokens_details.cached_tokens
                ):
                    num_cached_input_tokens = (
                        response.usage.prompt_tokens_details.cached_tokens
                    )
                else:
                    num_cached_input_tokens = 0
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    num_cached_input_tokens=num_cached_input_tokens,
                    num_input_tokens=response.usage.prompt_tokens,
                )
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=response.usage.completion_tokens,
                )
            else:
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    get_token_count=self.tokenizer.count_tokens,
                )
                text = self.get_text_from_response(response)
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=self.tokenizer.count_tokens(text),
                )
            return response
        else:
            assert not isinstance(response, ChatCompletion)
            return self._wrap_stream_with_cost_tracker(
                prompt_or_messages, response, uploaded_image_files_context
            )

    def _wrap_stream_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response: Iterable[ChatCompletionChunk],
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        generated_event_count = 0
        # We need to keep track of the last usage object to avoid double counting
        # Some providers (e.g. Databricks) return the usage object in every event
        last_usage_object = None
        for event in response:
            if event.usage:
                last_usage_object = event.usage
            generated_event_count += 1
            yield event

        if last_usage_object:
            if (
                last_usage_object.prompt_tokens_details
                and last_usage_object.prompt_tokens_details.cached_tokens
            ):
                num_cached_input_tokens = (
                    last_usage_object.prompt_tokens_details.cached_tokens
                )
            else:
                num_cached_input_tokens = 0
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                num_cached_input_tokens=num_cached_input_tokens,
                num_input_tokens=last_usage_object.prompt_tokens,
            )
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=last_usage_object.completion_tokens,
            )
            if uploaded_image_files_context:
                CostTracker.increment_input_image_count(
                    model_name=self.model_name,
                    num_images=len(uploaded_image_files_context),
                )
        # If we didn't have any event with usage, then we need to count the usage manually
        # once at the end of the stream
        else:
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                get_token_count=self.tokenizer.count_tokens,
            )
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=generated_event_count,
            )
