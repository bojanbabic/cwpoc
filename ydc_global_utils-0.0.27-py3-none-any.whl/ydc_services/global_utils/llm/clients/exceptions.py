import logging
from typing import (
    Dict,
    Type,
    Union,
)

import anthropic
import botocore.exceptions
import cohere
import openai
from aiohttp import web
from google.api_core.exceptions import InvalidArgument as GoogleInvalidArgument

logger = logging.getLogger(__package__)


class EarlyStoppingException(Exception):
    def __init__(self, reason_code, message, error_code):
        super().__init__(f"{reason_code}: {message}")
        self.reason_code = reason_code
        self.message = message
        self.error_code = error_code


class NoAnswerException(Exception):
    pass


class TokenLimitExceededException(Exception):
    """Exception raised when the token limit is exceeded for an LLM."""

    def __init__(self, message: str, excess_tokens=None, provider=None, model=None):
        self.message = message
        self.excess_tokens = excess_tokens
        self.provider = provider
        self.model = model
        super().__init__(self.message)


def get_model_exception_handlers(
    model_name: str,
) -> Dict[Type[Exception], Dict[str, Union[str, int]]]:
    # Too bad, Google doesn't expose the exceptions in the Vertex AI client library for now.
    return {
        # Anthropic exceptions
        anthropic.ConflictError: {
            "log_msg": f"Anthropic conflict error for model {model_name}",
            "metric_name": "anthropicconflict",
            "status": web.HTTPConflict.status_code,
        },
        anthropic.NotFoundError: {
            "log_msg": f"Anthropic not found error for model {model_name}",
            "metric_name": "anthropicnotfound",
            "status": web.HTTPNotFound.status_code,
        },
        anthropic.RateLimitError: {
            "log_msg": f"Anthropic rate limit error for model {model_name}",
            "metric_name": "anthropicratelimit",
            "status": web.HTTPTooManyRequests.status_code,
        },
        anthropic.APITimeoutError: {
            "log_msg": f"Anthropic timeout error for model {model_name}",
            "metric_name": "anthropictimeout",
            "status": web.HTTPGatewayTimeout.status_code,
        },
        anthropic.BadRequestError: {
            "log_msg": f"Anthropic bad request error for model {model_name}",
            "metric_name": "anthropicbadrequest",
            "status": web.HTTPBadRequest.status_code,
        },
        anthropic.AuthenticationError: {
            "log_msg": f"Anthropic authentication error for model {model_name}",
            "metric_name": "anthropicauth",
            "status": web.HTTPUnauthorized.status_code,
        },
        anthropic.InternalServerError: {
            "log_msg": f"Anthropic internal server error for model {model_name}",
            "metric_name": "anthropicinternal",
            "status": web.HTTPInternalServerError.status_code,
        },
        anthropic.PermissionDeniedError: {
            "log_msg": f"Anthropic permission denied error for model {model_name}",
            "metric_name": "anthropicpermission",
            "status": web.HTTPForbidden.status_code,
        },
        anthropic.UnprocessableEntityError: {
            "log_msg": f"Anthropic unprocessable entity error for model {model_name}",
            "metric_name": "anthropicunprocessable",
            "status": web.HTTPUnprocessableEntity.status_code,
        },
        anthropic.APIResponseValidationError: {
            "log_msg": f"Anthropic response validation error for model {model_name}",
            "metric_name": "anthropicresponsevalidation",
            "status": web.HTTPInternalServerError.status_code,
        },
        # OpenAI exceptions
        openai.APITimeoutError: {
            "log_msg": f"OpenAI timed out request for model {model_name}",
            "metric_name": "openaitimeout",
            "status": web.HTTPGatewayTimeout.status_code,
        },
        openai.RateLimitError: {
            "log_msg": f"OpenAI rate limited request for model {model_name}",
            "metric_name": "openairatelimit",
            "status": web.HTTPTooManyRequests.status_code,
        },
        openai.BadRequestError: {
            "log_msg": f"OpenAI bad request for model {model_name}",
            "metric_name": "openairatelimit",
            "status": web.HTTPTooManyRequests.status_code,
        },
        # Google exceptions
        GoogleInvalidArgument: {
            "log_msg": f"Google API invalid argument for model {model_name}",
            "metric_name": "googleinvalidargument",
            "status": web.HTTPBadRequest.status_code,
        },
        # AWS Bedrock exceptions
        botocore.exceptions.EventStreamError: {
            "log_msg": f"AWS Bedrock error for model {model_name}",
            "metric_name": "bedrockstreamerror",
            "status": web.HTTPBadRequest.status_code,
        },
        # Cohere exceptions
        cohere.BadRequestError: {
            "log_msg": f"Cohere rejected generation request for model {model_name}",
            "metric_name": "coherebadrequest",
            "status": web.HTTPBadRequest.status_code,
        },
        cohere.ForbiddenError: {
            "log_msg": f"Cohere rejected generation request for model {model_name}",
            "metric_name": "cohereforbidden",
            "status": web.HTTPForbidden.status_code,
        },
        cohere.InternalServerError: {
            "log_msg": "Cohere internal server error",
            "metric_name": "cohereinternal",
            "status": web.HTTPInternalServerError.status_code,
        },
        cohere.NotFoundError: {
            "log_msg": f"Cohere model {model_name} not found",
            "metric_name": "coherenotfound",
            "status": web.HTTPNotFound.status_code,
        },
        cohere.ServiceUnavailableError: {
            "log_msg": "Cohere service unavailable",
            "metric_name": "cohereserviceunavailable",
            "status": web.HTTPServiceUnavailable.status_code,
        },
        cohere.TooManyRequestsError: {
            "log_msg": "Cohere rate limited request",
            "metric_name": "cohereratelimit",
            "status": web.HTTPTooManyRequests.status_code,
        },
        cohere.UnauthorizedError: {
            "log_msg": "Cohere unauthorized request",
            "metric_name": "cohereunauthorized",
            "status": web.HTTPUnauthorized.status_code,
        },
        ValueError: {
            "log_msg": f"Value error for model {model_name}",
            "metric_name": "valueerror",
            "status": web.HTTPBadRequest.status_code,
        },
    }
