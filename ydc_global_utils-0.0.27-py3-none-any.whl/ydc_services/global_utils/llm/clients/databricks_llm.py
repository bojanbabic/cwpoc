import sys
from typing import Dict, Iterable, List, Optional, Union

from jinja2.sandbox import ImmutableSandboxedEnvironment

from ydc_services.global_utils.databricks.client import get_client
from ydc_services.global_utils.env import Env
from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    Messages,
    ModelMetadata,
    ResponseChunkT,
)
from ydc_services.global_utils.llm.tokenizers.heuristic_tokenizer import (
    HeuristicTokenizer,
)
from ydc_services.global_utils.llm_services.constants import DEFAULT_JINJA_CHAT_TEMPLATE

current_env = Env()


class DatabricksLLMClient(LLM[dict, ResponseChunkT]):
    MODEL_NAME_TO_METADATA = {
        "Qwen/Qwen2-1.5B-Instruct": ModelMetadata(
            model_name="Qwen/Qwen2-1.5B-Instruct",
            max_context_tokens=8192,
            max_output_tokens=4096,
        ),
        "Qwen2_5-0_5b": ModelMetadata(
            model_name="Qwen2_5-0_5b",
            max_context_tokens=8192,
            max_output_tokens=4096,
        ),
    }

    def __init__(
        self,
        model_name: str,
        endpoint_name: str,
        stream: bool,
        temperature: float,
        request_timeout: float = 20,
        max_output_tokens: int = 4096,
        max_context_tokens: int = sys.maxsize,
        params: Optional[Dict[str, Union[list, str, int, float, bool]]] = None,
        chat_template_str: str = DEFAULT_JINJA_CHAT_TEMPLATE,
        env: str = current_env.get_env(),
    ):
        # if params are provided, will override temperature and max_output_tokens
        # this corresponds to mlflow supported params signatures
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            HeuristicTokenizer(model_name),
        )
        if stream:
            raise ValueError("DatabricksLLMClient does not support streaming yet")

        self.jinja_env = ImmutableSandboxedEnvironment(
            trim_blocks=True, lstrip_blocks=True
        )
        self.client = get_client(
            endpoint_name,
            read_timeout=request_timeout,
            env=env,
        )
        self.chat_template_str = chat_template_str
        self.endpoint = endpoint_name
        self.request_timeout = request_timeout
        self.params = params or {}
        self.params["temperature"] = self.params.get("temperature", temperature)
        if max_output_tokens is not None:
            self.params["max_tokens"] = self.params.get("max_tokens", max_output_tokens)

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> list | Iterable[ResponseChunkT]:
        if messages is not None:
            prompt = self.jinja_env.from_string(self.chat_template_str).render(
                messages=messages, add_generation_prompt=True
            )
        data = {
            "inputs": [prompt],
            "params": self.params,
        }
        return self.client.predict(data)

    @classmethod
    def get_text_from_response(cls, response: dict) -> str:
        return response[0]["text"]

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        raise NotImplementedError

    def _yield_token_from_generator(
        self, generator: Iterable[ResponseChunkT]
    ) -> Iterable[str]:
        raise NotImplementedError()
