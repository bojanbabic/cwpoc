import base64
import os
import sys
from typing import Iterable, List, Optional

import google.auth
import google.auth.transport.requests
import openai
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm.tokenizers.gemini_tokenizer import GeminiTokenizer


class GeminiOAIChat(OpenAIChat):
    # https://cloud.google.com/vertex-ai/generative-ai/docs/multimodal/call-vertex-using-openai-library
    # This reduces the need to import a bunch of Google libraries, but with the
    # trade-off of not being able to use the full range of Gemini features. (one of them is safety filters).
    # Given that we don't use the safety filters anymore, due to lots of false positives, this is a good option to reduce dependencies.

    CREDENTIALS_PATH = "/tmp/CARvRa3Mmx3g"  # Deliberately nondescript path
    PROJECT = "gemini-413421"
    LOCATION = "us-central1"

    # https://cloud.google.com/vertex-ai/docs/generative-ai/model-reference/gemini
    MODEL_NAME_TO_METADATA = {
        "gemini-1.5-pro-002": ModelMetadata(
            model_name="google/gemini-1.5-pro-002",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
        "gemini-1.5-flash-002": ModelMetadata(
            model_name="google/gemini-1.5-flash-002",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
        "gemini-2.0-flash-001": ModelMetadata(
            model_name="google/gemini-2.0-flash-001",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
    }

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        stream: bool,
        temperature: float,
        max_context_tokens: int = sys.maxsize,
        stop: Optional[List[str]] = None,
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
            tokenizer=GeminiTokenizer(model_name),
        )
        self._ensure_credentials()
        self.client = self._setup_client()

    def _ensure_credentials(self) -> None:
        """Ensure credentials file exists and is properly set up."""
        # Check if credentials already exist and are valid
        if (
            os.environ.get("GOOGLE_APPLICATION_CREDENTIALS") == self.CREDENTIALS_PATH
            and os.path.exists(self.CREDENTIALS_PATH)
            and os.path.getsize(self.CREDENTIALS_PATH) > 0
        ):
            return

        # Get API key from environment
        api_key = os.getenv("GOOGLE_GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_GEMINI_API_KEY environment variable not set")

        # Create credentials file with restricted permissions
        try:
            with os.fdopen(
                os.open(
                    self.CREDENTIALS_PATH,
                    os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                    mode=0o600,  # File is private
                ),
                "wb",
            ) as fd:
                fd.write(base64.b64decode(api_key))

            # Set environment variable to point to credentials file
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self.CREDENTIALS_PATH
        except Exception as e:
            raise RuntimeError(f"Failed to create credentials file: {e}")

    def _setup_client(self) -> openai.OpenAI:
        # Get Google credentials with explicit cloud platform scope
        creds, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req)

        # Initialize OpenAI client with Vertex AI endpoint
        return openai.OpenAI(
            base_url=f"https://{self.LOCATION}-aiplatform.googleapis.com/v1beta1/projects/{self.PROJECT}/locations/{self.LOCATION}/endpoints/openapi",
            api_key=creds.token,
        )

    @classmethod
    def get_text_from_response(cls, response: ChatCompletion) -> str:
        return response.choices[0].message.content or ""

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ChatCompletion | Iterable[ChatCompletionChunk]:
        formatted_messages = []

        # Handle prompt format if provided
        if prompt:
            formatted_messages = self.prompt_to_messages(
                prompt, uploaded_image_files_context
            )
        else:
            formatted_messages = messages or []

        return self.client.chat.completions.create(
            model=self.MODEL_NAME_TO_METADATA[self.model_name].model_name,
            messages=formatted_messages,
            temperature=self.temperature,
            max_tokens=self.max_output_tokens,
            stream=self.stream,
            stop=self.stop,
        )
