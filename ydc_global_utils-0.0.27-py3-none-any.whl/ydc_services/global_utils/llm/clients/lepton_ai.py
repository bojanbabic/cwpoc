import os
import sys
from typing import (
    List,
    Optional,
)

import openai

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


class LeptonAI(OpenAIChat):
    # https://www.lepton.ai/pricing
    MODEL_NAME_TO_METADATA = {
        "dolphin-mixtral-8x7b": ModelMetadata(
            model_name="dolphin-mixtral-8x7b",
            max_context_tokens=32768,
            max_output_tokens=950,
            input_token_price=0.0000005,
            output_token_price=0.0000005,
        ),
    }
    DEFAULT_API_KEY = os.environ.get("LEPTON_AI_API_KEY")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        api_key: str = DEFAULT_API_KEY,  # type: ignore[assignment]
        stop: Optional[str | List[str]] = "<|eot_id|>",
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
        )
        self.api_key = api_key

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        messages = self.prompt_to_messages(prompt) if prompt else messages
        # TODO: Decide if we want to use the shared client or create a new client for each request
        # for this client after testing on OAI.
        client = openai.OpenAI(
            api_key=self.api_key,
            base_url=f"https://{self.model_name}.lepton.run/api/v1",
        )

        return client.chat.completions.create(
            messages=messages,  # type: ignore[arg-type]
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
        )
