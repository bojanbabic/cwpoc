import os
import sys
from typing import (
    List,
    Optional,
)

import openai

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm_services.prompt_constants import D1


# _StandardCostTrackerMixin over-rides default OAI cost tracking
class Databricks(OpenAIChat):
    MODEL_NAME_TO_METADATA = {
        "databricks-dbrx-instruct": ModelMetadata(
            model_name="databricks-dbrx-instruct",
            max_context_tokens=32768,
            max_output_tokens=4096,
        ),
    }
    DATABRICK_API_URL = (
        "https://dbc-717ce2a2-8606.cloud.databricks.com/serving-endpoints"
    )
    DEFAULT_API_KEY = os.environ.get("DATABRICKS_MODEL_SERVING_TOKEN")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        databrick_api_key: str = DEFAULT_API_KEY,  # type: ignore[assignment]
        stop: Optional[str | List[str]] = D1.GENERATION_STOP_TOKEN,
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
        )
        self.api_key = databrick_api_key

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        messages = self.prompt_to_messages(prompt) if prompt else messages
        # TODO: Decide if we want to use the shared client or create a new client for each request
        # for this client after testing on OAI.
        client = openai.OpenAI(api_key=self.api_key, base_url=self.DATABRICK_API_URL)

        return client.chat.completions.create(
            messages=messages,  # type: ignore[arg-type]
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
        )
