import sys
from typing import (
    Dict,
    Iterable,
    List,
    Literal,
    Optional,
)

from openai.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionReasoningEffort,
)

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


# Due to some limitations in the OpenAI API for Strawberry models, we need to create a separate class to handle them.
class OpenAIO1Chat(OpenAIChat):
    MODEL_NAME_TO_METADATA = {
        "o1-preview": ModelMetadata(
            model_name="o1-preview",
            max_context_tokens=128000,
            max_output_tokens=32768,
            input_token_price=0.000015,
            output_token_price=0.00006,
        ),
        "o1-mini": ModelMetadata(
            model_name="o1-mini",
            max_context_tokens=128000,
            max_output_tokens=65536,
            input_token_price=0.0000011,
            output_token_price=0.0000044,
        ),
        "o1": ModelMetadata(
            model_name="o1",
            max_context_tokens=128000,
            max_output_tokens=65536,
            input_token_price=0.000015,
            output_token_price=0.00006,
        ),
        "o1-2024-12-17": ModelMetadata(
            model_name="o1-2024-12-17",
            max_context_tokens=200000,
            max_output_tokens=100000,
            input_token_price=0.000015,
            output_token_price=0.00006,
        ),
        # https://platform.openai.com/docs/models#o3-mini
        "o3-mini-2025-01-31": ModelMetadata(
            model_name="o3-mini-2025-01-31",
            max_context_tokens=200000,
            max_output_tokens=100000,
            input_token_price=0.0000011,
            output_token_price=0.0000044,
        ),
        "o3-mini": ModelMetadata(
            model_name="o3-mini",
            max_context_tokens=200000,
            max_output_tokens=100000,
            input_token_price=0.0000011,
            output_token_price=0.0000044,
        ),
    }
    TOKEN_REPLACEMENT_FOR_MODELS_WITH_DEV_MESSAGE_MAP = {
        # Yup! It's a single token in the 200k_base tokenizer
        "--------------------------------------------------------------------------------": "```"
    }

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool = False,
        max_context_tokens: int = sys.maxsize,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        response_type: Literal["text", "json_object"] = "text",
        logprobs: Optional[bool] = False,
        top_logprobs: Optional[int] = None,
        system_prompt_strategy: Optional[str] = "not_use",
        reasoning_effort: ChatCompletionReasoningEffort = "medium",
        force_generate_markdown: bool = False,
        client_type: str = "not_shared",
    ):
        super().__init__(
            model_name=model_name,
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            top_p=top_p,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            response_type=response_type,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            client_type=client_type,
        )
        self.system_prompt_strategy = system_prompt_strategy
        self.reasoning_effort = reasoning_effort
        self.force_generate_markdown = force_generate_markdown
        self.token_replacement_map = (
            self.TOKEN_REPLACEMENT_FOR_MODELS_WITH_DEV_MESSAGE_MAP
            if self._is_model_with_developer_message_and_reasoning_effort()
            else None
        )

    @classmethod
    def prompt_to_messages(  # type: ignore
        cls,
        prompt: str,
        system_prompt_strategy: Optional[str] = "add_at_start",
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        # NOTE: Copied from OpenAIChat.prompt_to_messages with some modifications:
        # 1. strip out image_file_context
        # 2. remove the stream and system message
        formatted_messages = []
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                agent = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                formatted_messages.append({"role": agent, "content": message})

        def _insert_instruction_before_serp(
            instruction_message: str, user_message_content: str
        ):
            note_line = "Note: You should not provide a list of sources/bibliography at the end of the response"
            if note_line in user_message_content:
                note_index = user_message_content.index(note_line)
                user_message_content = (
                    user_message_content[:note_index]
                    + instruction_message
                    + "\n"
                    + user_message_content[note_index:]
                )
            # Not adding instruction if there is no search result
            return user_message_content

        def _add_system_prompt_to_last_turn(
            system_prompt_turn: Dict[str, str], last_turn: Dict[str, str]
        ) -> Dict[str, str]:
            if system_prompt_strategy == "add_at_start":
                last_turn["content"] = (
                    system_prompt_turn["content"] + "\n" + last_turn["content"]
                )
            elif system_prompt_strategy == "add_at_end":
                last_turn["content"] += "\n" + system_prompt_turn["content"]
            elif system_prompt_strategy == "add_before_serp":
                last_turn["content"] = _insert_instruction_before_serp(
                    system_prompt_turn["content"], last_turn["content"]
                )
            elif system_prompt_strategy == "add_minimal_instruction_before_serp":
                minimal_instruction = "Answer the question thoroughly and accurately. If search results are provided, referencing sources is encouraged. Cite the relevant search text snippets immediately after making the claim using a '[[<source_number>]]' notation"
                last_turn["content"] = _insert_instruction_before_serp(
                    minimal_instruction, last_turn["content"]
                )

            return last_turn

        system_prompt_turn = formatted_messages.pop(0)
        last_turn = formatted_messages.pop(-1)
        formatted_messages.append(
            _add_system_prompt_to_last_turn(system_prompt_turn, last_turn)
        )
        if uploaded_image_files_context:
            image_message_content = cls.convert_image_files_context_to_messages(
                uploaded_image_files_context
            )
            formatted_messages.append(
                {"role": "user", "content": image_message_content}  # type: ignore
            )
        return formatted_messages  # type: ignore

    def _is_model_with_developer_message_and_reasoning_effort(self) -> bool:
        return self.model_name in {
            "o3-mini",
            "o3-mini-2025-01-31",
            "o1",
            "o1-2024-12-17",
        }

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ChatCompletion | Iterable[ChatCompletionChunk]:
        if prompt:
            if self._is_model_with_developer_message_and_reasoning_effort():
                # If it's o1 full model (not preview or mini) and o3-mini, we can use system message as for normal model
                # system message will be converted to a developer message by OpenAI on their end.
                # https://cdn.openai.com/spec/model-spec-2024-05-08.html#definitions
                messages = super().prompt_to_messages(
                    prompt, uploaded_image_files_context
                )
                if (
                    len(messages) > 0
                    and messages[0].get("role") == "system"
                    and self.force_generate_markdown
                ):
                    # https://community.openai.com/t/o1-api-doesnt-separate-code-blocks-with-three-backticks/1099469
                    messages[0]["content"] = (
                        "Formatting re-enabled\n\n" + messages[0]["content"]
                    )  # type: ignore
            else:
                messages = self.prompt_to_messages(
                    prompt, self.system_prompt_strategy, uploaded_image_files_context
                )

        # NOTE: We are trying out different ways to share httpx client across threads/processes
        # to avoid the network issue like SSL, as well as to reduce the overall latency.
        client = self._get_client(self.client_type, self.model_name)

        # We strip away: `temperature`, `tools`, `tool_choice`, `stop`. They are not supported for this model.
        # `max_output_tokens`` has been replaced with `max_output_tokens_per_turn`
        if self._is_model_with_developer_message_and_reasoning_effort():
            return client.chat.completions.create(
                messages=messages,
                model=self.model_name,
                timeout=self.request_timeout,
                max_completion_tokens=self.max_output_tokens,
                stream=self.stream,
                stream_options=self.stream_options if self.stream else None,  # type: ignore
                top_p=self.top_p,
                frequency_penalty=self.frequency_penalty,
                presence_penalty=self.presence_penalty,
                response_format=self.response_format,
                logprobs=self.logprobs,
                top_logprobs=self.top_logprobs,
                reasoning_effort=self.reasoning_effort,
            )
        else:
            return client.chat.completions.create(
                messages=messages,
                model=self.model_name,
                timeout=self.request_timeout,
                max_completion_tokens=self.max_output_tokens,
                stream=self.stream,
                stream_options=self.stream_options if self.stream else None,  # type: ignore
                top_p=self.top_p,
                frequency_penalty=self.frequency_penalty,
                presence_penalty=self.presence_penalty,
                response_format=self.response_format,
                logprobs=self.logprobs,
                top_logprobs=self.top_logprobs,
            )


if __name__ == "__main__":
    llm_client = OpenAIO1Chat(
        model_name="o1-mini",
        request_timeout=180,
        max_output_tokens=64000,
        temperature=1.0,
        stream=True,
        system_prompt_strategy="add_minimal_instruction_before_serp",
        client_type="not_shared",
        reasoning_effort="high",
    )
    for token in llm_client.get_generator(
        messages=[{"role": "user", "content": "Why is sky blue?"}],
    ):
        print(token)
