import os
import re
import sys
from typing import (
    Iterable,
    List,
    Optional,
)

import cohere
from cohere import NonStreamedChatResponse, StreamedChatResponse
from cohere.core import ApiError as CohereApiError

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    Messages,
    ModelMetadata,
    PromptOrMessages,
)
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.tokenizers.heuristic_tokenizer import (
    HeuristicTokenizer,
)


class CohereChat(LLM[NonStreamedChatResponse, StreamedChatResponse]):
    MODEL_NAME_TO_METADATA = {
        "command-r": ModelMetadata(
            model_name="command-r",
            max_context_tokens=128000,
            max_output_tokens=4000,
        ),
        "command-r-plus": ModelMetadata(
            model_name="command-r-plus",
            max_context_tokens=128000,
            max_output_tokens=4000,
        ),
    }
    DEFAULT_API_KEY = os.environ.get("COHERE_API_KEY")

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        stream: bool,
        temperature: float,
        request_timeout: float,
        max_context_tokens: int = sys.maxsize,
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            HeuristicTokenizer(model_name),
        )
        self.request_timeout = request_timeout

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        formatted_messages = []
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                agent = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                formatted_messages.append({"role": agent, "message": message})
        return formatted_messages

    @classmethod
    def get_text_from_response(cls, response: NonStreamedChatResponse) -> str:
        return response.text

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> NonStreamedChatResponse | Iterable[StreamedChatResponse]:
        if prompt:
            all_messages = self.prompt_to_messages(prompt, uploaded_image_files_context)
            chat_history = all_messages[:-1]
            current_message = all_messages[-1]["message"]
        else:
            assert messages
            chat_history = [message for message in messages[:-1]]
            current_message = messages[-1]["message"]

        client = cohere.Client(self.DEFAULT_API_KEY, timeout=self.request_timeout)

        if self.stream:
            return client.chat_stream(
                chat_history=chat_history,
                message=current_message,
                model=self.model_name,
                max_tokens=self.max_output_tokens,
                temperature=self.temperature,
            )
        else:
            return client.chat(
                chat_history=chat_history,
                message=current_message,
                model=self.model_name,
                max_tokens=self.max_output_tokens,
                temperature=self.temperature,
            )

    def _yield_token_from_generator(
        self, generator: Iterable[StreamedChatResponse]
    ) -> Iterable[str]:
        for item in generator:
            if item.event_type == "text-generation":
                yield item.text

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if not self.stream:
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                num_input_tokens=response.response.meta["tokens"]["input_tokens"],
            )
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=response.response.meta["tokens"]["output_tokens"],
            )
            return response
        else:
            return self._wrap_stream_with_cost_tracker(
                prompt_or_messages, response, uploaded_image_files_context
            )

    def _wrap_stream_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if uploaded_image_files_context:
            CostTracker.increment_input_image_count(
                model_name=self.model_name, num_images=len(uploaded_image_files_context)
            )

        for event in response:
            if event.event_type == "stream-end":
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    num_input_tokens=event.response.meta["tokens"]["input_tokens"],
                )
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=event.response.meta["tokens"]["output_tokens"],
                )
            yield event

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Cohere pattern: "too many tokens: size limit exceeded by 47189 tokens"
        if isinstance(error, CohereApiError) and "too many tokens" in error_message:
            excess_tokens = cls._get_excess_tokens(error_message)
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # Cohere pattern: "too many tokens: size limit exceeded by 47189 tokens"
        match = re.search(
            r"exceeded by (\d+) tokens",
            error_message,
        )
        if match:
            return int(match.group(1))
        return None


class CohereRerank:
    def __init__(self):
        self.client = cohere.Client(os.environ.get("COHERE_API_KEY"))

    def rerank(self, query: str, documents: List[str], top_n: int = 10):
        output = self.client.rerank(
            query=query, documents=documents, top_n=top_n, model="rerank-v3.5"
        )
        return output.results
