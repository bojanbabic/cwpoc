import os
import re
import sys
from typing import (
    List,
    Optional,
)

import openai

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


# _StandardCostTrackerMixin over-rides default OAI cost tracking
class TogetherAI(OpenAIChat):
    # https://docs.together.ai/docs/inference-models
    MODEL_NAME_TO_METADATA = {
        "meta-llama/Llama-3-8b-chat-hf": ModelMetadata(
            model_name="meta-llama/Llama-3-8b-chat-hf",
            max_context_tokens=8000,
            max_output_tokens=2048,
        ),
        "meta-llama/Llama-3-70b-chat-hf": ModelMetadata(
            model_name="meta-llama/Llama-3-70b-chat-hf",
            max_context_tokens=8000,
            max_output_tokens=2048,
        ),
        "meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo": ModelMetadata(
            model_name="meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo",
            max_context_tokens=128000,
            max_output_tokens=4096,
            input_token_price=0.000005,
            output_token_price=0.000015,
        ),
        "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo": ModelMetadata(
            model_name="meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.00000088,
            output_token_price=0.00000264,
        ),
        "meta-llama/Llama-3.2-11B-Vision-Instruct-Turbo": ModelMetadata(
            model_name="meta-llama/Llama-3.2-11B-Vision-Instruct-Turbo",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.00000018,
            output_token_price=0.00000018,
        ),
        "meta-llama/Llama-3.2-90B-Vision-Instruct-Turbo": ModelMetadata(
            model_name="meta-llama/Llama-3.2-90B-Vision-Instruct-Turbo",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.0000012,
            output_token_price=0.0000012,
        ),
        "meta-llama/Llama-3.3-70B-Instruct-Turbo": ModelMetadata(
            model_name="meta-llama/Llama-3.3-70B-Instruct-Turbo",
            max_context_tokens=131072,
            max_output_tokens=131072,
            input_token_price=0.0000009,
            output_token_price=0.0000009,
        ),
        "cognitivecomputations/dolphin-2.5-mixtral-8x7b": ModelMetadata(
            model_name="cognitivecomputations/dolphin-2.5-mixtral-8x7b",
            max_context_tokens=32768,
            max_output_tokens=2048,
        ),
        "Qwen/Qwen2.5-Coder-32B-Instruct": ModelMetadata(
            model_name="Qwen/Qwen2.5-Coder-32B-Instruct",
            max_context_tokens=32768,
            max_output_tokens=4096,
            input_token_price=0.0000008,
            output_token_price=0.0000008,
        ),
        "Qwen/Qwen2.5-72B-Instruct-Turbo": ModelMetadata(
            model_name="Qwen/Qwen2.5-72B-Instruct-Turbo",
            max_context_tokens=32768,
            max_output_tokens=4096,
            input_token_price=0.0000012,
            output_token_price=0.0000012,
        ),
        "deepseek-ai/DeepSeek-V3": ModelMetadata(
            model_name="deepseek-ai/DeepSeek-V3",
            max_context_tokens=131072,
            max_output_tokens=131072,
            input_token_price=0.00000125,
            output_token_price=0.00000125,
        ),
        "deepseek-ai/DeepSeek-R1": ModelMetadata(
            model_name="deepseek-ai/DeepSeek-R1",
            max_context_tokens=163840,
            max_output_tokens=163840,
            input_token_price=0.000007,
            output_token_price=0.000007,
            thinking_start_token="<think>",
            thinking_end_token="</think>",
        ),
        "Qwen/QwQ-32B": ModelMetadata(
            model_name="Qwen/QwQ-32B",
            max_context_tokens=131_072,
            max_output_tokens=32768,
            input_token_price=0.0000012,
            output_token_price=0.0000012,
            thinking_start_token="<think>",
            thinking_end_token="</think>",
        ),
    }
    API_URL = "https://api.together.xyz/v1"
    DEFAULT_API_KEY = os.environ.get("TOGETHER_AI_API_KEY")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        api_key: str = DEFAULT_API_KEY,  # type: ignore[assignment]
        stop: Optional[str | List[str]] = None,
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop or ["<|eot_id|>", "<|eom_id|>"],
        )
        self.api_key = api_key

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        # NOTE: Llama 3.2 models only support 1 image file context right now.
        # We'll need to send the disclaimer message in the answer to inform the user
        # that the image has been truncated.
        first_image_file_context = (
            uploaded_image_files_context[:1] if uploaded_image_files_context else None
        )
        messages = (
            self.prompt_to_messages(
                prompt, uploaded_image_files_context=first_image_file_context
            )
            if prompt
            else messages
        )
        # TODO: Decide if we want to use the shared client or create a new client for each request
        # for this client after testing on OAI.
        client = openai.OpenAI(api_key=self.api_key, base_url=self.API_URL)

        return client.chat.completions.create(
            messages=messages,  # type: ignore[arg-type]
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
        )

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # TogetherAI pattern: "Input validation error: `inputs` tokens + `max_new_tokens` must be <= 163840. Given: 1000004 `inputs` tokens and 4096 `max_new_tokens`"
        if (
            isinstance(error, openai.BadRequestError)
            and "prompt is too long" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # TogetherAI pattern: "Input validation error: `inputs` tokens + `max_new_tokens` must be <= 163840. Given: 1000004 `inputs` tokens and 4096 `max_new_tokens`"
        match = re.search(
            r"must be <= (\d+). Given: (\d+) `inputs` tokens and (\d+) `max_new_tokens`",
            error_message,
        )
        groups = match.groups() if match else ()
        if len(groups) == 3:
            max_tokens, used_input_tokens, expected_output_tokens = (
                int(groups[0]),
                int(groups[1]),
                int(groups[2]),
            )
            return used_input_tokens + expected_output_tokens - max_tokens

        return None


if __name__ == "__main__":
    client = TogetherAI(
        model_name="Qwen/QwQ-32B",
        request_timeout=10,
        stream=True,
        max_output_tokens=32000,
        temperature=0.1,
    )

    res = client.get_token_generator(
        messages=[
            {"role": "user", "content": "Why is sky blue?"},
        ]
    )

    for chunk in res:
        print(chunk)
