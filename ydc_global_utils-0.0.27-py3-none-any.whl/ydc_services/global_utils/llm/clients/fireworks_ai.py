import os
import re
import sys
from typing import (
    Iterable,
    List,
    Optional,
)

import openai
from openai.types.chat import ChatCompletionChunk

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


class FireworksAI(OpenAIChat):
    # https://www.fireworks.ai/pricing
    MODEL_NAME_TO_METADATA = {
        "qwen2p5-coder-32b-instruct": ModelMetadata(
            model_name="qwen2p5-coder-32b-instruct",
            max_context_tokens=32768,
            max_output_tokens=4096,
            input_token_price=0.0000009,
            output_token_price=0.0000009,
        ),
        "qwen2p5-72b-instruct": ModelMetadata(
            model_name="qwen2p5-72b-instruct",
            max_context_tokens=32768,
            max_output_tokens=4096,
            input_token_price=0.0000009,
            output_token_price=0.0000009,
        ),
        "qwq-32b": ModelMetadata(
            model_name="qwq-32b",
            max_context_tokens=128_000,
            max_output_tokens=16384,
            input_token_price=0.0000009,
            output_token_price=0.0000009,
            thinking_start_token="<think>",
            thinking_end_token="</think>",
        ),
        "llama-v3p3-70b-instruct": ModelMetadata(
            model_name="llama-v3p3-70b-instruct",
            max_context_tokens=131072,
            max_output_tokens=4096,
            input_token_price=0.0000009,
            output_token_price=0.0000009,
        ),
        "deepseek-v3": ModelMetadata(
            model_name="deepseek-v3",
            max_context_tokens=131072,
            max_output_tokens=4096,
            input_token_price=0.0000009,
            output_token_price=0.0000009,
        ),
        "deepseek-r1": ModelMetadata(
            model_name="deepseek-r1",
            max_context_tokens=163840,
            max_output_tokens=20480,
            input_token_price=0.000008,
            output_token_price=0.000008,
            thinking_start_token="<think>",
            thinking_end_token="</think>",
        ),
    }
    API_URL = "https://api.fireworks.ai/inference/v1"
    DEFAULT_API_KEY = os.environ.get("FIREWORKS_AI_API_KEY")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        api_key: str = DEFAULT_API_KEY,  # type: ignore
        stop: Optional[str | List[str]] = "<|eot_id|>",
        client_type: str = "not_shared",  # not used
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
            client_type=client_type,
        )
        self.api_key = api_key

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        messages = self.prompt_to_messages(prompt) if prompt else messages
        # TODO: Decide if we want to use the shared client or create a new client for each request
        # for this client after testing on OAI.
        client = openai.OpenAI(
            api_key=self.api_key,
            base_url=self.API_URL,
        )

        return client.chat.completions.create(
            messages=messages,  # type: ignore
            model=f"accounts/fireworks/models/{self.model_name}",
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
        )

    def _yield_token_from_generator(
        self, generator: Iterable[ChatCompletionChunk]
    ) -> Iterable[str]:
        if self.model_metadata.thinking_start_token is None:
            for token in super()._yield_token_from_generator(generator):
                yield token
            return

        # If the model is a thinking model, we need to make sure that we yield the thinking start token
        # at the first token, before yielding any other tokens. This is because Fireworks AI seems to set "<think>\n"
        # as the assistant's prefix response for QwQ, following this suggestion: https://huggingface.co/Qwen/QwQ-32B/discussions/4
        # thus there is no opening "<think>" token to yield.
        has_yield_first_token = False
        for response in generator:
            if (
                len(response.choices) > 0
                and response.choices[0].delta
                and response.choices[0].delta.content
            ):
                token = response.choices[0].delta.content
                if not has_yield_first_token and not self.is_thinking_start(token):
                    yield self.model_metadata.thinking_start_token
                yield token
                has_yield_first_token = True

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Fireworks pattern: "The prompt is too long: 135847, model maximum context length: 131071"
        if (
            isinstance(error, openai.BadRequestError)
            and "prompt is too long" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "
            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # Fireworks pattern: "The prompt is too long: 135847, model maximum context length: 131071"
        match = re.search(
            r"The prompt is too long: (\d+), model maximum context length: (\d+)",
            error_message,
        )
        if match:
            return abs(int(match.group(2)) - int(match.group(1)))
        return None


if __name__ == "__main__":
    client = FireworksAI(
        model_name="deepseek-v3",
        request_timeout=10,
        stream=True,
        max_output_tokens=16000,
        temperature=0.0,
    )

    res = client.get_token_generator(
        messages=[{"role": "user", "content": "Why is sky blue?"}]
    )

    for chunk in res:
        print(chunk)
