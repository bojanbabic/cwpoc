import os
import sys
from typing import (
    List,
    Optional,
)

import openai

from ydc_services.global_utils.file_upload.schemas import FileContext
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


class DeepSeekAI(OpenAIChat):
    # Pricing and limits:
    # https://api-docs.deepseek.com/quick_start/pricing
    MODEL_NAME_TO_METADATA = {
        "deepseek-chat": ModelMetadata(
            model_name="deepseek-chat",
            max_context_tokens=64000,
            max_output_tokens=8000,
            input_token_price=0.00000014,
            output_token_price=0.00000028,
        ),
        "deepseek-reasoner": ModelMetadata(
            model_name="deepseek-reasoner",
            max_context_tokens=64000,
            max_output_tokens=40000,  # 32K COT tokens + 8K output tokens
            input_token_price=0.00000014,
            output_token_price=0.00000219,
        ),
    }
    API_URL = "https://api.deepseek.com"
    DEFAULT_API_KEY = os.environ.get("DEEPSEEK_API_KEY")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        api_key: str = DEFAULT_API_KEY,  # type: ignore[assignment]
        stop: Optional[str | List[str]] = None,
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
        )
        self.api_key = api_key

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContext]] = None,
    ):
        messages = self.prompt_to_messages(prompt) if prompt else messages
        client = openai.OpenAI(
            api_key=self.api_key,
            base_url=self.API_URL,
        )

        return client.chat.completions.create(
            messages=messages,  # type: ignore[arg-type]
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
        )


if __name__ == "__main__":
    client = DeepSeekAI(
        model_name="deepseek-reasoner",
        request_timeout=10,
        stream=True,
        max_output_tokens=1000,
        temperature=0.0,
    )

    res = client.get_token_generator(
        messages=[
            {"role": "user", "content": "Tell me a joke"},
        ]
    )

    for chunk in res:
        print(chunk)
