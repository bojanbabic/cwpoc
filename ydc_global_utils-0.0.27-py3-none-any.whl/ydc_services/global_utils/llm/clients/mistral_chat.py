import os
import sys
from typing import (
    Iterable,
    List,
    Optional,
)

from mistralai.client import MistralClient
from mistralai.models.chat_completion import (
    ChatCompletionResponse,
    ChatCompletionStreamResponse,
    ChatMessage,
)

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import LLM, Messages, ModelMetadata
from ydc_services.global_utils.llm.tokenizers.heuristic_tokenizer import (
    HeuristicTokenizer,
)


class MistralChat(LLM[ChatCompletionResponse, ChatCompletionStreamResponse]):
    # Model specs: https://docs.mistral.ai/platform/endpoints/#mistral-ai-generative-models
    # max_output_tokens is not documented, but it seems to be 4096 for all models (guessing)
    # Pricing: https://docs.mistral.ai/platform/pricing/
    MODEL_NAME_TO_METADATA = {
        "mistral-medium-latest": ModelMetadata(
            model_name="mistral-medium-latest",
            max_context_tokens=32768,
            max_output_tokens=4096,
            input_token_price=0.0000027,
            output_token_price=0.0000081,
        ),
        "mistral-large-latest": ModelMetadata(
            model_name="mistral-large-latest",
            max_context_tokens=32768,
            max_output_tokens=4096,
            input_token_price=0.000008,
            output_token_price=0.000024,
        ),
    }
    DEFAULT_API_KEY = os.environ.get("MISTRAL_API_KEY")

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        stream: bool,
        request_timeout: float,
        temperature: float,
        max_context_tokens: int = sys.maxsize,
        api_key: str = DEFAULT_API_KEY,  # type: ignore[assignment]
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            HeuristicTokenizer(model_name),
        )
        self.api_key = api_key
        self.request_timeout = int(request_timeout)

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> List[ChatMessage]:
        formatted_messages = []
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                agent = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                formatted_messages.append(ChatMessage(role=agent, content=message))
        return formatted_messages

    @classmethod
    def get_text_from_response(cls, response: ChatCompletionResponse) -> str:
        return response.choices[0].message.content

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ChatCompletionResponse | Iterable[ChatCompletionStreamResponse]:
        if prompt:
            formatted_messages: List[ChatMessage] = self.prompt_to_messages(prompt)
        else:
            assert messages is not None
            formatted_messages = [ChatMessage(**message) for message in messages]

        client = MistralClient(api_key=self.api_key, timeout=self.request_timeout)
        if self.stream:
            return client.chat_stream(
                model=self.model_name,
                messages=formatted_messages,
                max_tokens=self.max_output_tokens,
            )
        else:
            return client.chat(
                model=self.model_name,
                messages=formatted_messages,
                max_tokens=self.max_output_tokens,
            )

    def _yield_token_from_generator(
        self, generator: Iterable[ChatCompletionStreamResponse]
    ) -> Iterable[str]:
        for response in generator:
            token = response.choices[0].delta.content
            if token:
                yield token
            if response.choices[0].finish_reason is not None:
                break
