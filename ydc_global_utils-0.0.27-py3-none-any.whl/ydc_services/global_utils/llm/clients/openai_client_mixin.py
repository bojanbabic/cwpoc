import logging
import os

import httpx
import openai

from ydc_services.global_utils.aiohttp.middlewares_and_headers import (
    request_context_var,
)

logger = logging.getLogger(__package__)


class OpenAIClientMixin:
    DEFAULT_API_KEY = os.environ.get("OPENAI_API_KEY")
    DEFAULT_ORGANIZATION = os.environ.get("OPENAI_ORGANIZATION_ID")

    TEAMS_ZDR_API_KEY = os.environ.get("OPENAI_ENTERPRISE_ZDR_API_KEY")
    TEAMS_ZDR_ORGANIZATION = os.environ.get("OPENAI_ENTERPRISE_ZDR_ORGANIZATION_ID")

    """
    The default limit 100 with max alive connections is 20, but it might not work at scale
    The author of OAI SDK suggests to set a higher number and share one client:
    - https://github.com/openai/openai-python/issues/874#issuecomment-1824966775
    - https://github.com/openai/openai-python/issues/821#issuecomment-1811659617
    """
    CUSTOM_LIMITS = httpx.Limits(max_connections=1000, max_keepalive_connections=100)

    shared_default_client = openai.OpenAI(
        api_key=DEFAULT_API_KEY,
        organization=DEFAULT_ORGANIZATION,
        max_retries=0,
        http_client=httpx.Client(limits=CUSTOM_LIMITS),
    )
    shared_zdr_client = openai.OpenAI(
        api_key=TEAMS_ZDR_API_KEY,
        organization=TEAMS_ZDR_ORGANIZATION,
        max_retries=0,
        http_client=httpx.Client(limits=CUSTOM_LIMITS),
    )

    @classmethod
    def _create_client(cls, model_name: str) -> openai.OpenAI:
        tenant_id = request_context_var.get().get("tenant_id", None)
        if tenant_id:
            logger.info("openai_chat: Using ZDR API key")
            api_key = cls.TEAMS_ZDR_API_KEY
            organization_id = cls.TEAMS_ZDR_ORGANIZATION
        else:
            logger.info("openai_chat: Using default API key")
            api_key = cls.DEFAULT_API_KEY
            organization_id = cls.DEFAULT_ORGANIZATION

        return openai.OpenAI(
            api_key=api_key,
            organization=organization_id,
            max_retries=0,
            http_client=httpx.Client(limits=cls.CUSTOM_LIMITS),
        )

    @classmethod
    def _get_client(cls, client_type: str, model_name: str) -> openai.OpenAI:
        if client_type == "not_shared":
            return cls._create_client(model_name)

        elif client_type == "shared":
            tenant_id = request_context_var.get().get("tenant_id", None)
            if tenant_id:
                logger.info("openai_chat: Using ZDR Shared Client")
                return cls.shared_zdr_client
            else:
                logger.info("openai_chat: Using Default Shared Client")
                return cls.shared_default_client

        else:
            raise ValueError(
                f"Invalid client type: {client_type}. "
                "Expected one of: 'not_shared', 'shared'."
            )
