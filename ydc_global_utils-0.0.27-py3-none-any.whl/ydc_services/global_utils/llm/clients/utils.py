from typing import Any, Dict, List, Optional

from ydc_services.global_utils.llm.clients.base import LLM
from ydc_services.global_utils.llm.clients.bedrock_claude import BedrockClaude3Chat
from ydc_services.global_utils.llm.clients.claude3_chat import Claude3Chat
from ydc_services.global_utils.llm.clients.fireworks_ai import FireworksAI
from ydc_services.global_utils.llm.clients.grok_chat import GrokChat
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm.clients.openai_o1_chat import OpenAIO1Chat
from ydc_services.global_utils.llm.clients.schemas import Base64Data
from ydc_services.global_utils.llm.clients.vertex_claude import VertexClaude
from ydc_services.global_utils.types import NOT_GIVEN, NotGiven


# model_name_with_provider should be of the format "{provider}/{model_name}",
# i.e "anthropic/claude-3-haiku-20240307"
def init_llm_from_model_name(
    model_name_with_provider: str,
    request_timeout: int = 30,
    max_output_tokens: int = 1024,
    temperature: float | NotGiven = NOT_GIVEN,
    stream: bool = False,
    **kwargs,
) -> LLM:
    parts = model_name_with_provider.split("/")
    if len(parts) != 2:
        raise ValueError(
            f"Invalid model_name format: {model_name_with_provider}. Require <provider>/<model_name>"
        )

    provider, model_name = parts

    _temperature: float = (
        (
            1
            if provider == "openai"
            and (model_name.startswith("o1") or model_name.startswith("o3"))
            else 0
        )
        if isinstance(temperature, NotGiven)
        else temperature
    )

    match provider.lower():
        case "openai":
            if model_name.startswith("o1") or model_name.startswith("o3"):
                return OpenAIO1Chat(
                    model_name=model_name,
                    request_timeout=180,
                    max_output_tokens=32000,
                    # Note: temperature is not used for OpenAIO1_Mini due to the model's current limitations
                    temperature=_temperature,
                    stream=stream,
                    **kwargs,
                )
            else:
                return OpenAIChat(
                    model_name=model_name,
                    request_timeout=request_timeout,
                    max_output_tokens=max_output_tokens,
                    temperature=_temperature,
                    stream=stream,
                    **kwargs,
                )
        case "fireworks":
            return FireworksAI(
                model_name=model_name,
                request_timeout=request_timeout,
                max_output_tokens=max_output_tokens,
                stream=stream,
                temperature=_temperature,
                **kwargs,
            )
        case "vertex":
            return VertexClaude(
                model_name=model_name,
                request_timeout=request_timeout,
                max_output_tokens=max_output_tokens,
                temperature=_temperature,
                stream=stream,
                **kwargs,
            )
        case "anthropic":
            return Claude3Chat(
                model_name=model_name,
                request_timeout=request_timeout,
                max_output_tokens=max_output_tokens,
                temperature=_temperature,
                stream=stream,
                **kwargs,
            )
        case "bedrock" if "claude" in model_name:
            return BedrockClaude3Chat(
                model_name=model_name,
                request_timeout=request_timeout,
                max_output_tokens=max_output_tokens,
                temperature=_temperature,
                stream=stream,
                **kwargs,
            )
        case "grok":
            return GrokChat(
                model_name=model_name,
                request_timeout=request_timeout,
                max_output_tokens=max_output_tokens,
                temperature=_temperature,
                stream=stream,
                **kwargs,
            )
        case _:
            raise ValueError(f"Invalid LLM client type: {provider} {model_name}")


def init_llm_client_based_on_algo(
    algo: str,
    request_timeout: int = 30,
    max_output_tokens: int = 1024,
    temperature: float | NotGiven = NOT_GIVEN,
    stream: bool = False,
    **kwargs,
) -> LLM:
    _temperature: float = 0 if isinstance(temperature, NotGiven) else temperature
    if algo == "A":
        return OpenAIChat(
            model_name="gpt-4o-2024-08-06",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "B":
        return OpenAIChat(
            model_name="gpt-4o-2024-11-20",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "C":
        return Claude3Chat(
            "claude-3-5-sonnet-20240620",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "D":
        return Claude3Chat(
            "claude-3-5-sonnet-20241022",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "E":
        return BedrockClaude3Chat(
            model_name="anthropic.claude-3-5-sonnet-20240620-v1:0",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "F":
        return BedrockClaude3Chat(
            "us.anthropic.claude-3-5-sonnet-20241022-v2:0",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "G":
        return Claude3Chat(
            "claude-3-7-sonnet-20250219",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    elif algo == "H":
        return BedrockClaude3Chat(
            "us.anthropic.claude-3-7-sonnet-20250219-v1:0",
            request_timeout=request_timeout,
            max_output_tokens=max_output_tokens,
            temperature=_temperature,
            stream=stream,
            **kwargs,
        )
    raise ValueError(f"Unknown algo: {algo}")


def init_llm_clients_based_on_algos(
    algos: str,
    request_timeout: int = 30,
    max_output_tokens: int = 1024,
    temperature: float | NotGiven = NOT_GIVEN,
    stream: bool = False,
    max_clients: int = 4,
    **kwargs,
) -> List[LLM]:
    llm_clients = []
    for algo in algos:
        llm_clients.append(
            init_llm_client_based_on_algo(
                algo,
                request_timeout=request_timeout,
                max_output_tokens=max_output_tokens,
                temperature=temperature,
                stream=stream,
                **kwargs,
            )
        )
    return llm_clients[:max_clients]


def create_messages_with_image(
    llm_client: LLM,
    system_prompt: str,
    user_prompt: Optional[str],
    base64_data_list: list[Base64Data],
) -> List[Dict[str, Any]]:
    if isinstance(llm_client, Claude3Chat):
        user_content = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": base64_data.mime_type,
                    "data": base64_data.base64,
                },
            }
            for base64_data in base64_data_list
        ]
        if user_prompt:
            user_content.append({"type": "text", "text": user_prompt})

        return [
            {
                "role": "system",
                "content": [{"type": "text", "text": system_prompt}],
            },
            {
                "role": "user",
                "content": user_content,
            },
        ]
    elif isinstance(llm_client, OpenAIChat):
        user_content = [
            {
                "type": "image_url",
                "image_url": {"url": base64_data.html_src},
            }
            for base64_data in base64_data_list
        ]
        if user_prompt:
            user_content.append({"type": "text", "text": user_prompt})
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
    else:
        raise ValueError(f"Unknown LLM client: {llm_client}")


def construct_base64_data(base64_string: str, content_type: str) -> Base64Data:
    return Base64Data(
        base64=base64_string,
        mime_type=content_type,
        html_src=f"data:{content_type};base64,{base64_string}",
    )


if __name__ == "__main__":
    client = init_llm_client_based_on_algo("H", stream=True)
    response = client.get_token_generator(
        messages=[{"role": "user", "content": "Why is the sky blue in one sentence?"}]
    )
    for token in response:
        print(token)
