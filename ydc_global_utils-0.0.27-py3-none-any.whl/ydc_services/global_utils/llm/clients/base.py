import logging
from abc import ABC, abstractmethod
from typing import (
    Dict,
    Generic,
    Iterable,
    List,
    Optional,
    TypeAlias,
    TypeVar,
    Union,
)

from pydantic import BaseModel

from ydc_services.global_utils.file_upload.schemas import (
    FileContext,
    FileContextOrError,
)
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm.tokenizers.base import Tokenizer
from ydc_services.global_utils.llm.tools.schemas import ToolCallInput

logger = logging.getLogger(__package__)


class ModelMetadata(BaseModel):
    model_name: str
    max_context_tokens: int
    max_output_tokens: int
    # Default to 0 for any model we don't have pricing info for
    input_token_price: float = 0
    output_token_price: float = 0
    thinking_start_token: Optional[str] = None
    thinking_end_token: Optional[str] = None

    class Config:
        protected_namespaces = ()


Messages: TypeAlias = List[Dict[str, str | List]]
PromptOrMessages: TypeAlias = Union[str, Messages]
ResponseT = TypeVar("ResponseT")
ResponseChunkT = TypeVar("ResponseChunkT")


class LLM(ABC, Generic[ResponseT, ResponseChunkT]):
    MODEL_NAME_TO_METADATA: Dict[str, ModelMetadata] = {}

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        max_context_tokens: int,
        stream: bool,
        temperature: float,
        tokenizer: Tokenizer,
    ):
        self.model_name = model_name
        model_metadata = self.MODEL_NAME_TO_METADATA.get(self.model_name)
        if model_metadata is None:
            for model_name in self.MODEL_NAME_TO_METADATA:
                if model_name in self.model_name:
                    # fine-tuning model names
                    model_metadata = self.MODEL_NAME_TO_METADATA[model_name]
                    break

        assert (
            model_metadata is not None
        ), f"Model name {self.model_name} not listed in MODEL_NAME_TO_METADATA"
        self.model_metadata = model_metadata

        self.max_output_tokens = min(
            max_output_tokens, model_metadata.max_output_tokens
        )
        self.max_context_tokens = min(
            max_context_tokens, model_metadata.max_context_tokens
        )

        self.stream = stream
        self.temperature = temperature
        self.tokenizer = tokenizer
        self.token_replacement_map: Optional[Dict[str, str]] = None

    def get_token_generator(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Iterable[str]:
        generator = self.get_generator(
            prompt, messages, uploaded_image_files_context=uploaded_image_files_context
        )
        return self._yield_token_from_generator(generator)

    def get_generator(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Iterable[ResponseChunkT]:
        if self.stream is False:
            raise ValueError(
                "get_generator() only supports stream=True - use get_response() for non-streaming calls instead."
            )
        return self._create_request_and_add_wrappers(
            prompt, messages, uploaded_image_files_context
        )

    def get_response_text(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
    ) -> str:
        response = self.get_response(prompt, messages)
        return self.get_text_from_response(response)

    def get_response_tool_calls(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
    ) -> List[ToolCallInput]:
        response = self.get_response(prompt, messages)
        return self.get_tool_calls_from_response(response)

    def get_response(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ResponseT:
        if self.stream is True:
            raise ValueError(
                "get_response() only supports stream=False - use get_generator() for streaming calls instead."
            )
        return self._create_request_and_add_wrappers(
            prompt, messages, uploaded_image_files_context
        )

    def is_thinking_start(self, token: str) -> bool:
        if self.model_metadata.thinking_start_token is None:
            return False
        return self.model_metadata.thinking_start_token in token

    def is_thinking_end(self, token: str) -> bool:
        if self.model_metadata.thinking_end_token is None:
            return False
        return self.model_metadata.thinking_end_token in token

    def supports_continuation(self) -> bool:
        return False

    def _create_request_and_add_wrappers(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        self._validate_input_data(prompt, messages, uploaded_image_files_context)

        stream_type = "stream" if self.stream else "non_stream"
        with record(
            # Do not keep adding new "/" because it can result in high cardinality
            # (|Model Names| x |Stream Type| does not create too many variations now to
            # exceed NR limits)
            f"llm/{self.model_name}/{stream_type}",
            logger=logger,
        ) as rec:
            try:
                response = self._create_request(
                    prompt,
                    messages,
                    uploaded_image_files_context=uploaded_image_files_context,
                )
            except Exception as e:
                # Let the client implementation handle token limit errors
                if self._handle_token_limit_error(e, self.model_name):
                    pass  # Error already handled and re-raised by _handle_token_limit_error
                raise

            prompt_or_messages = prompt if prompt else messages
            assert prompt_or_messages is not None
            if self.stream:
                return self._wrap_with_cost_tracker(
                    prompt_or_messages,
                    self._wrap_stream_with_logging(response, rec),  # type: ignore
                    uploaded_image_files_context,
                )
            else:
                request_id = self._get_request_id(response)  # type: ignore
                if request_id:
                    rec.log_info("request_id", request_id)
                return self._wrap_with_cost_tracker(
                    prompt_or_messages, response, uploaded_image_files_context
                )

    def _validate_input_data(
        self,
        prompt: Optional[str],
        messages: Optional[Messages],
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> None:
        if prompt is None and messages is None:
            raise ValueError("Either prompt or messages must be provided")

        if messages is None and not isinstance(prompt, str):
            raise ValueError("Provided prompt is not a string")

        if prompt is None and not isinstance(messages, list):
            raise ValueError("Provided messages is not a list")
        elif (
            isinstance(messages, list)
            and len(messages) > 0
            and not all(isinstance(message, dict) for message in messages)
        ):
            raise ValueError("Provided messages is not a list of dictionaries")

        if uploaded_image_files_context:
            for file_context in uploaded_image_files_context:
                if not isinstance(file_context, FileContext) or not isinstance(
                    file_context.content, str
                ):
                    raise ValueError(
                        "Provided uploaded_image_files_context contains file context missing content"
                    )

    def _wrap_stream_with_logging(
        self,
        generator: Iterable[ResponseChunkT],
        rec: record,
        log_every_n_tokens: int = 100,
    ) -> Iterable[ResponseChunkT]:
        num_tokens = 0
        for value in generator:
            num_tokens += 1
            if num_tokens == 1:
                rec.log_latency("ttft")
                request_id = self._get_request_id(value)
                if request_id:
                    rec.log_info("request_id", request_id)

            if num_tokens % log_every_n_tokens == 0:
                rec.log_info("num_tokens_hit", num_tokens)

            yield value

        time_elapsed = rec.get_time_elapsed()
        if num_tokens:
            rec.log_latency("tpot", time_elapsed / num_tokens)

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        CostTracker.increment_input_count(
            self.model_name,
            prompt_or_messages,
            get_token_count=self.tokenizer.count_tokens,
        )

        if uploaded_image_files_context:
            CostTracker.increment_input_image_count(
                model_name=self.model_name, num_images=len(uploaded_image_files_context)
            )
        if not self.stream:
            text_to_count_tokens = None
            try:
                text = self.get_text_from_response(response)
                if text:
                    text_to_count_tokens = text
            except Exception:
                pass

            try:
                tool_call_inputs = self.get_tool_calls_from_response(response)
                if tool_call_inputs:
                    text_to_count_tokens = str(
                        [tci.model_dump_json() for tci in tool_call_inputs]
                    )
            except Exception:
                pass

            if text_to_count_tokens:
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=self.tokenizer.count_tokens(text_to_count_tokens),
                )
        else:
            response = CostTracker.wrap_with_increment_event(response, self.model_name)
        return response

    @classmethod
    @abstractmethod
    def get_text_from_response(cls, response: ResponseT) -> str:
        raise NotImplementedError

    @classmethod
    def get_tool_calls_from_response(cls, response: ResponseT) -> List[ToolCallInput]:
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        raise NotImplementedError

    @abstractmethod
    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ResponseT | Iterable[ResponseChunkT]:
        raise NotImplementedError

    @classmethod
    def _get_request_id(cls, response: ResponseT | ResponseChunkT) -> Optional[str]:
        return None

    @abstractmethod
    def _yield_token_from_generator(
        self, generator: Iterable[ResponseChunkT]
    ) -> Iterable[str]:
        raise NotImplementedError

    @classmethod
    def convert_image_files_context_to_messages(
        cls, uploaded_image_files_context: List[FileContextOrError]
    ) -> List:
        raise NotImplementedError

    @classmethod
    def get_in_out_token_price(cls, model_name_lookup: str) -> tuple[float, float]:
        if model_name_lookup not in cls.MODEL_NAME_TO_METADATA:
            logger.error(
                "Model not found in MODEL_NAME_TO_METADATA",
                model_name=model_name_lookup,
            )
            return (0, 0)

        return (
            cls.MODEL_NAME_TO_METADATA[model_name_lookup].input_token_price,
            cls.MODEL_NAME_TO_METADATA[model_name_lookup].output_token_price,
        )

    def get_max_input_tokens(self) -> int:
        return self.max_context_tokens - self.max_output_tokens

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        raise error
