import base64
import re
import sys
from typing import (
    Dict,
    Iterable,
    List,
    Optional,
    Tuple,
)

import boto3
import botocore.exceptions
from botocore.client import Config
from botocore.eventstream import EventStream

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    Messages,
    ModelMetadata,
    PromptOrMessages,
)
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.clients.shared_bedrock import BedrockWest2
from ydc_services.global_utils.llm.tokenizers.heuristic_tokenizer import (
    HeuristicTokenizer,
)


# TODO: We should refactor to delay processing the bytes
# until we need to send the request to the LLM to avoid
# unnecessary base64 decoding in the lambda function
def get_blob_from_base64_image(base64_string: str):
    return base64.b64decode(base64_string)


class BedrockLlama3Chat(LLM[Dict, EventStream]):
    MODEL_NAME_TO_METADATA = {
        "meta.llama3-8b-instruct-v1:0": ModelMetadata(
            model_name="meta.llama3-8b-instruct-v1:0",
            max_context_tokens=8000,
            max_output_tokens=2048,
            input_token_price=0.0000004,
            output_token_price=0.0000006,
        ),
        "meta.llama3-1-70b-instruct-v1:0": ModelMetadata(
            model_name="meta.llama3-1-70b-instruct-v1:0",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.00000265,
            output_token_price=0.0000035,
        ),
        "meta.llama3-1-405b-instruct-v1:0": ModelMetadata(
            model_name="meta.llama3-1-405b-instruct-v1:0",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.00000532,
            output_token_price=0.000016,
        ),
        "us.meta.llama3-2-11b-instruct-v1:0": ModelMetadata(
            model_name="us.meta.llama3-2-11b-instruct-v1:0",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.00000265,
            output_token_price=0.0000035,
        ),
        "us.meta.llama3-2-90b-instruct-v1:0": ModelMetadata(
            model_name="us.meta.llama3-2-90b-instruct-v1:0",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.00000265,
            output_token_price=0.0000035,
        ),
    }

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        request_timeout: float,
        temperature: float,
        max_context_tokens: int = sys.maxsize,
        stream: bool = False,
        max_retries: int = 0,
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            HeuristicTokenizer(model_name),
        )
        self.request_timeout = request_timeout
        self.max_retries = max_retries

    @classmethod
    def get_text_from_response(cls, response: Dict) -> str:
        return response["output"]["message"]["content"][0]["text"]

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Tuple[Optional[str], Messages]:
        # This pattern is adapted from OpenAIChat.prompt_to_messages class method
        # Ref to the docs for the Request syntax: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/bedrock-runtime/client/converse_stream.html
        # NOTE: This is a bad pattern in which we first pack all prompts into a string
        # and then decode back into a list of json dicts
        # Should be refactored to use a list of json dicts from the beginning
        formatted_messages = []
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                agent = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                formatted_messages.append(
                    {"role": agent, "content": [{"text": message}]}
                )
        if uploaded_image_files_context:
            image_message_content = cls.convert_image_files_context_to_messages(
                uploaded_image_files_context
            )
            formatted_messages[-1] = {
                "role": "user",
                "content": image_message_content + formatted_messages[-1]["content"],  # type: ignore
            }

        system_turn = (
            formatted_messages.pop(0)
            if formatted_messages[0]["role"] == "system"
            else None
        )
        system_prompt = system_turn["content"] if system_turn else None
        return system_prompt, formatted_messages  # type: ignore

    @classmethod
    def convert_image_files_context_to_messages(
        cls,
        uploaded_image_files_context: List[FileContextOrError],
    ) -> Messages:
        image_message_content = []
        for image_file_context in uploaded_image_files_context:
            image_format = image_file_context.user_filename.split(".")[-1]
            image_bytes = get_blob_from_base64_image(image_file_context.content)
            image_message_content.append(
                {"image": {"format": image_format, "source": {"bytes": image_bytes}}}
            )
        return image_message_content  # type: ignore

    def _create_request(
        self,
        prompt: str | None = None,
        messages: Messages | None = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Dict | EventStream:
        assert prompt, "Prompt is required for BedrockLlama3Chat"
        # NOTE: Llama 3.2 models only support 1 image file context right now.
        # We'll need to send the disclaimer message in the answer to inform the user
        # that the image has been truncated.
        first_image_file_context = (
            uploaded_image_files_context[:1] if uploaded_image_files_context else None
        )

        config = Config(
            connect_timeout=self.request_timeout,
            read_timeout=self.request_timeout,
            retries={"max_attempts": self.max_retries},
        )
        boto3_client = boto3.client(
            "bedrock-runtime",
            region_name=BedrockWest2.REGION_NAME,
            aws_access_key_id=BedrockWest2.DEFAULT_BEDROCK_ACCESS_KEY,
            aws_secret_access_key=BedrockWest2.DEFAULT_BEDROCK_SECRET_KEY,
            config=config,
        )
        invoke_model_func = (
            boto3_client.converse if not self.stream else boto3_client.converse_stream
        )
        system_prompt, adapted_messages = self.prompt_to_messages(
            prompt, first_image_file_context
        )
        return invoke_model_func(
            modelId=self.model_name, messages=adapted_messages, system=system_prompt
        )

    def _yield_token_from_generator(self, generator: EventStream):
        for event in generator:
            if "contentBlockDelta" in event:
                yield event["contentBlockDelta"]["delta"]["text"]
            if "contentBlockStop" in event or "messageStop" in event:
                break

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response: Dict | EventStream,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if not self.stream:
            assert isinstance(response, Dict)
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                num_input_tokens=response["usage"]["inputTokens"],
            )
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=response["usage"]["totalTokens"],
            )
            return response
        else:
            generator = response["stream"]
            return self._wrap_stream_with_cost_tracker(prompt_or_messages, generator)

    def _wrap_stream_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response: Iterable[Dict],
    ):
        CostTracker.increment_input_count(
            self.model_name,
            prompt_or_messages,
            get_token_count=self.tokenizer.count_tokens,
        )
        return CostTracker.wrap_with_increment_event(response, self.model_name)

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Bedrock Llama pattern: "Prompt contains 187190 tokens and 0 draft tokens, too large for model with 131072 maximum context length"
        if (
            isinstance(error, botocore.exceptions.EventStreamError)
            and "too large for model with" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # Bedrock Llama pattern: "Prompt contains 187190 tokens and 0 draft tokens, too large for model with 131072 maximum context length"
        match = re.search(
            r"contains (\d+) tokens and.+with (\d+) maximum context length",
            error_message,
        )
        if match:
            return abs(int(match.group(2)) - int(match.group(1)))
        return None
