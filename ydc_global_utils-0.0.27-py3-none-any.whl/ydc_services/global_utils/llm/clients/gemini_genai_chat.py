import os
import sys
from typing import Iterable, List, Optional

import openai
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


class GeminiGenaiChat(OpenAIChat):
    # EXPERIMENTAL: Gemini GenAI Chat. For production, use GeminiChat which uses
    # the Vertex AI.
    # https://cloud.google.com/vertex-ai/docs/generative-ai/model-reference/gemini
    MODEL_NAME_TO_METADATA = {
        "gemini-exp-1206": ModelMetadata(
            model_name="gemini-exp-1206",
            max_context_tokens=2000000,
            max_output_tokens=8192,
        )
    }
    GOOGLE_GENAI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        stream: bool,
        temperature: float,
        max_context_tokens: int = sys.maxsize,
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
        )

    @classmethod
    def get_text_from_response(cls, response: ChatCompletion) -> str:
        return response.choices[0].message.content or ""

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> ChatCompletion | Iterable[ChatCompletionChunk]:
        formatted_messages = []

        # Handle prompt format if provided
        if prompt:
            formatted_messages = self.prompt_to_messages(
                prompt, uploaded_image_files_context
            )
        else:
            formatted_messages = messages or []

        client = openai.OpenAI(
            api_key=os.environ.get("GOOGLE_STUDIO_API_KEY"),
            base_url=self.GOOGLE_GENAI_BASE_URL,
        )
        return client.chat.completions.create(
            model=self.model_name,
            messages=formatted_messages,
            temperature=self.temperature,
            max_tokens=self.max_output_tokens,
            stream=self.stream,
            stop=self.stop,
        )
