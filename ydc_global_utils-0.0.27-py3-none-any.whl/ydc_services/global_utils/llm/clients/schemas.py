from pydantic import BaseModel


class Base64Data(BaseModel):
    base64: str
    mime_type: str
    html_src: str
