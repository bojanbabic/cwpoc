import os

import anthropic
import httpx


class BedrockWest2:
    DEFAULT_BEDROCK_ACCESS_KEY = os.environ.get("BEDROCK_IAM_USER_ACCESS_KEY")
    DEFAULT_BEDROCK_SECRET_KEY = os.environ.get("BEDROCK_IAM_USER_SECRET_KEY")
    REGION_NAME = "us-west-2"

    SHARED_ANTHROPIC_CLIENT = anthropic.AnthropicBedrock(
        aws_access_key=DEFAULT_BEDROCK_ACCESS_KEY,
        aws_secret_key=DEFAULT_BEDROCK_SECRET_KEY,
        http_client=httpx.Client(
            timeout=45,
            limits=httpx.Limits(max_connections=500, max_keepalive_connections=100),
        ),
        aws_region=REGION_NAME,
        max_retries=0,
    )


class BedrockEast1:
    DEFAULT_BEDROCK_ACCESS_KEY = os.environ.get("BEDROCK_IAM_USER_ACCESS_KEY")
    DEFAULT_BEDROCK_SECRET_KEY = os.environ.get("BEDROCK_IAM_USER_SECRET_KEY")
    REGION_NAME = "us-east-1"

    SHARED_ANTHROPIC_CLIENT = anthropic.AnthropicBedrock(
        aws_access_key=DEFAULT_BEDROCK_ACCESS_KEY,
        aws_secret_key=DEFAULT_BEDROCK_SECRET_KEY,
        http_client=httpx.Client(
            timeout=45,
            limits=httpx.Limits(max_connections=500, max_keepalive_connections=100),
        ),
        aws_region=REGION_NAME,
        max_retries=0,
    )
