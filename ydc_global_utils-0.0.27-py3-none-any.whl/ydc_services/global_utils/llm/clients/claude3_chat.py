import logging
import os
import re
import sys
import uuid
from typing import (
    Iterable,
    List,
    Optional,
)

import anthropic
import httpx
from anthropic import NOT_GIVEN, NotGiven
from anthropic.types import (
    ContentBlockDeltaEvent,
    ContentBlockStartEvent,
    Message,
    MessageParam,
    MessageStartEvent,
    MessageStopEvent,
    MessageStreamEvent,
    RawMessageStartEvent,
    SignatureDelta,
    TextBlock,
    TextBlockParam,
    TextDelta,
    ThinkingBlock,
    ThinkingConfigParam,
    ThinkingDelta,
    ToolChoiceParam,
    ToolUseBlock,
)

from ydc_services.global_utils.file_upload.constants import (
    ALLOWED_IMAGE_FILE_EXTENSIONS,
)
from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    ModelMetadata,
    PromptOrMessages,
)
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.tokenizers.anthropic_tokenizer import (
    init_anthropic_tokenizer,
)
from ydc_services.global_utils.llm.tools.core import Tool
from ydc_services.global_utils.llm.tools.schemas import ToolCallInput

logger = logging.getLogger(__package__)


class Claude3Chat(LLM[Message, MessageStreamEvent]):
    # Model specs: https://docs.anthropic.com/claude/docs/models-overview#model-comparison
    # Pricing: https://www.anthropic.com/api
    MODEL_NAME_TO_METADATA = {
        "claude-3-haiku-20240307": ModelMetadata(
            model_name="claude-3-haiku-20240307",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.00000025,
            output_token_price=0.00000125,
        ),
        "claude-3-5-haiku-20241022": ModelMetadata(
            model_name="claude-3-5-haiku-20241022",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.00000025,
            output_token_price=0.00000125,
        ),
        "claude-3-sonnet-20240229": ModelMetadata(
            model_name="claude-3-sonnet-20240229",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "claude-3-5-sonnet-20240620": ModelMetadata(
            model_name="claude-3-5-sonnet-20240620",
            max_context_tokens=200000,
            max_output_tokens=8192,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "claude-3-5-sonnet-20241022": ModelMetadata(
            model_name="claude-3-5-sonnet-20241022",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.000003,
            output_token_price=0.000015,
        ),
        "claude-3-opus-20240229": ModelMetadata(
            model_name="claude-3-opus-20240229",
            max_context_tokens=200000,
            max_output_tokens=4096,
            input_token_price=0.000015,
            output_token_price=0.000075,
        ),
        "claude-3-7-sonnet-20250219": ModelMetadata(
            model_name="claude-3-7-sonnet-20250219",
            max_context_tokens=200000,
            max_output_tokens=64000,
            input_token_price=0.000003,
            output_token_price=0.000015,
            thinking_start_token="<think>",
            thinking_end_token="</think>",
        ),
    }

    DEFAULT_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
    SHARED_CLIENT = anthropic.Anthropic(
        api_key=DEFAULT_API_KEY,
        http_client=httpx.Client(
            timeout=45,
            limits=httpx.Limits(max_connections=500, max_keepalive_connections=100),
        ),
        max_retries=0,
    )

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        temperature: int | float,
        request_timeout: float,
        max_context_tokens: int = sys.maxsize,
        max_retries: int = 0,
        stop: List[str] | NotGiven = NOT_GIVEN,
        tool_choice: ToolChoiceParam | NotGiven = NOT_GIVEN,
        tools: List[Tool] | NotGiven = NOT_GIVEN,
        client_type: str = "not_shared",
        stream: bool = False,
        cache_system_prompt: bool = False,
        thinking_config: Optional[ThinkingConfigParam] = None,
    ):
        tokenizer = init_anthropic_tokenizer(self._get_anthropic_model_name(model_name))
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            tokenizer,
        )
        self.request_timeout = request_timeout
        self.max_retries = max_retries
        self.stop = stop
        self.tool_choice = tool_choice
        self.tools = tools
        self.tool_schemas = (
            [tool.claude_tool_schema for tool in tools]
            if isinstance(tools, list)
            else NOT_GIVEN
        )
        self.client_type = client_type
        self.cache_system_prompt = cache_system_prompt
        self.thinking_config = thinking_config
        if self.thinking_config:
            assert (
                self.model_metadata.thinking_start_token
                and self.model_metadata.thinking_end_token
            ), f"Model {self.model_name} does not support thinking or has not been configured with thinking start and end tokens"

            # NOTE: Temperature must be set to 1.0 for thinking to work
            self.temperature = 1.0

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> list[MessageParam]:
        messages = []
        # NOTE: Adapted from OpenAI's prompt_to_messages
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                agent = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                messages.append(
                    {"role": agent, "content": [{"type": "text", "text": message}]}
                )

        if uploaded_image_files_context:
            image_message_content = cls.convert_image_files_context_to_messages(
                uploaded_image_files_context
            )
            if len(image_message_content) > 0:
                messages[-1]["content"].extend(image_message_content)  # type: ignore
        return messages  # type: ignore

    def supports_continuation(self) -> bool:
        return True

    @classmethod
    def _separate_system_from_conv_messages(
        cls, messages: List[MessageParam]
    ) -> tuple[Optional[List[TextBlockParam]], List[MessageParam]]:
        system = None
        for i, message in enumerate(messages):
            if message["role"] == "system":
                system = messages.pop(i)["content"]
                break
        return system, messages  # type: ignore # typedict warning

    @classmethod
    def get_text_from_response(cls, response: Message) -> str:
        return response.content[0].text  # type: ignore

    @classmethod
    def get_tool_calls_from_response(cls, response: Message) -> List[ToolCallInput]:
        return [
            ToolCallInput(
                call_id=str(uuid.uuid4()),
                tool_name=block.name,
                tool_inputs=block.input,  # type: ignore[arg-type]
            )
            for block in response.content
            if isinstance(block, ToolUseBlock)
        ]

    @classmethod
    def convert_image_files_context_to_messages(
        cls, uploaded_image_files_context: List[FileContextOrError]
    ) -> List:
        image_message_content = []
        for image_file_context in uploaded_image_files_context:
            image_bytes = image_file_context.content
            file_type = image_file_context.user_filename.split(".")[-1]
            if file_type == "jpg":
                file_type = "jpeg"
            if "." + file_type in ALLOWED_IMAGE_FILE_EXTENSIONS:
                image_message_content.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": f"image/{file_type}",
                            "data": image_bytes,
                        },
                    }
                )
        return image_message_content

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[List[MessageParam]] = None,  # type: ignore
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Message | Iterable[MessageStreamEvent]:
        system = None
        if prompt is not None:
            messages = self.prompt_to_messages(prompt, uploaded_image_files_context)

        assert messages is not None

        system, messages = self._separate_system_from_conv_messages(messages)
        if system and self.cache_system_prompt:
            if isinstance(system, str):
                system = [{"type": "text", "text": system}]

            assert isinstance(system, list)
            assert isinstance(system[0], dict)
            system[0]["cache_control"] = {"type": "ephemeral"}  # type: ignore

        kwargs = {}
        if system is not None:
            kwargs["system"] = system
        if self.thinking_config:
            kwargs["thinking"] = self.thinking_config

        if self.client_type == "not_shared":
            client = anthropic.Anthropic(
                api_key=self.DEFAULT_API_KEY,
                timeout=self.request_timeout,
                # Disable retries
                # https://github.com/anthropics/anthropic-sdk-python/blob/1f110a29db91f1857743ac5841977d709fae2712/README.md?plain=1#L267
                max_retries=self.max_retries,
            )
        else:
            client = self.SHARED_CLIENT

        resp = client.messages.create(
            messages=messages,
            model=self.model_name,
            stop_sequences=self.stop,
            stream=self.stream,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            tool_choice=self.tool_choice,
            tools=self.tool_schemas,
            **kwargs,
        )

        if self.client_type != "shared" and not self.stream:
            client.close()
        return resp

    @classmethod
    def _get_request_id(cls, response: Message | MessageStreamEvent) -> Optional[str]:
        if isinstance(response, Message):
            return response.id
        elif isinstance(response, RawMessageStartEvent):
            return response.message.id
        else:
            return None

    def _yield_token_from_generator(self, generator: Iterable[MessageStreamEvent]):
        delta_event_i = 0
        for item in generator:
            if isinstance(item, ContentBlockStartEvent):
                if isinstance(item.content_block, TextBlock):
                    token = item.content_block.text
                elif isinstance(item.content_block, ThinkingBlock):
                    token = item.content_block.thinking
                    yield self.model_metadata.thinking_start_token
                else:
                    logger.warning(
                        "Unexpected content block start type",
                        block_type=type(item.content_block),
                    )
                    continue

            elif isinstance(item, ContentBlockDeltaEvent):
                if isinstance(item.delta, TextDelta):
                    token = item.delta.text

                elif isinstance(item.delta, ThinkingDelta):
                    token = item.delta.thinking

                elif isinstance(item.delta, SignatureDelta):
                    # https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking#understanding-thinking-blocks
                    # signature_delta is in the final content_block_delta before the content_block_stop event
                    yield self.model_metadata.thinking_end_token
                    token = None  # Can't call continue after yielding

                else:
                    logger.warning(
                        "Unexpected content block delta type",
                        delta_type=type(item.delta),
                    )
                    continue

                if delta_event_i == 0 and token and token.startswith("\n"):
                    # TODO: Check if we can remove this condition
                    # Remove the newline at the beginning of the answer.
                    # This is uniquely seen in the Claude model and likely related to our prompt format.
                    token = token[1:]

                if token is not None:
                    delta_event_i += 1
                    yield token
            elif isinstance(item, MessageStopEvent):
                break

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if not self.stream:
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                num_input_tokens=response.usage.input_tokens,
            )
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=response.usage.output_tokens,
            )
            return response
        else:
            return self._wrap_stream_with_cost_tracker(
                prompt_or_messages, response, uploaded_image_files_context
            )

    def _wrap_stream_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if uploaded_image_files_context:
            CostTracker.increment_input_image_count(
                model_name=self.model_name, num_images=len(uploaded_image_files_context)
            )

        for event in response:
            if isinstance(event, MessageStartEvent):
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    num_input_tokens=event.message.usage.input_tokens,
                )
            CostTracker.increment_output_token_count(self.model_name)
            yield event

    @classmethod
    def _get_anthropic_model_name(cls, model_name: str) -> str:
        anthropic_model_name = model_name
        if "anthropic." in anthropic_model_name:
            try:
                anthropic_model_name = anthropic_model_name.split("anthropic.")[
                    1
                ].split("-v")[0]
                assert anthropic_model_name in Claude3Chat.MODEL_NAME_TO_METADATA
            except Exception:
                # Default to the most recent model if the model name is invalid
                logger.warning(
                    "Invalid Anthropic model name. Defaulting to claude-3-5-sonnet-20241022.",
                    model_name=model_name,
                )
                anthropic_model_name = "claude-3-5-sonnet-20241022"
        return anthropic_model_name

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Anthropic pattern: "prompt is too long: 207266 tokens > 200000 maximum"
        if (
            isinstance(error, anthropic.BadRequestError)
            and "prompt is too long" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)

            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        match = re.search(r"(\d+) tokens > (\d+) maximum", error_message)
        if match:
            return abs(int(match.group(1)) - int(match.group(2)))
        return None


if __name__ == "__main__":
    llm_client = Claude3Chat(
        model_name="claude-3-7-sonnet-20250219",
        max_output_tokens=40960,
        temperature=1.0,
        request_timeout=45,
        stream=True,
        thinking_config={"type": "enabled", "budget_tokens": 32000},
    )
    response = llm_client.get_token_generator(
        messages=[
            {
                "role": "user",
                "content": "what is the hardest physics problem in the world?",
                # "content": "Why is the sky blue?",
            }
        ]
    )
    for token in response:
        print(token)
