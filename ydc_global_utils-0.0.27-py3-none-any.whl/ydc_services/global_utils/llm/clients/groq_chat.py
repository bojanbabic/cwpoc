# Need to add `groq==0.11.0` to requirements.text, this file to all_clients.py
# and add GROQ_API_KEY if we want to use in Prod.
import os
import sys
from typing import (
    List,
    Optional,
)

from groq import Groq

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.llm.clients.base import Messages, ModelMetadata
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat


# _StandardCostTrackerMixin over-rides default OAI cost tracking
class GroqChat(OpenAIChat):
    # https://console.groq.com/docs/models
    # TODO: max_output_tokens have not been updated
    MODEL_NAME_TO_METADATA = {
        "llama-3.2-90b-text-preview": ModelMetadata(
            model_name="llama-3.2-90b-text-preview",
            # Low because of preview
            max_context_tokens=8192,
            max_output_tokens=2048,
        ),
        "llama-3.2-11b-text-preview": ModelMetadata(
            model_name="llama-3.2-11b-text-preview",
            # Low because of preview
            max_context_tokens=8192,
            max_output_tokens=2048,
        ),
        "llama-3.2-3b-preview": ModelMetadata(
            model_name="llama-3.2-3b-preview",
            # Low because of preview
            max_context_tokens=8192,
            max_output_tokens=2048,
        ),
        "llama-3.2-1b-preview": ModelMetadata(
            model_name="llama-3.2-1b-preview",
            # Low because of preview
            max_context_tokens=8192,
            max_output_tokens=2048,
        ),
        # TODO: Llama 3.1 405B is offline due to overwhelming demand
        # "llama-3.1-405b": ModelMetadata(
        #     model_name="llama-3.1-405b",
        #     max_context_tokens=131072,
        #     max_output_tokens=2048,
        # ),
        "llama-3.1-70b-versatile": ModelMetadata(
            model_name="llama-3.1-70b-versatile",
            max_context_tokens=131072,
            max_output_tokens=2048,
        ),
        "llama-3.1-8b-instant": ModelMetadata(
            model_name="llama-3.1-8b-instant",
            max_context_tokens=131072,
            max_output_tokens=2048,
        ),
        "llama3-70b-8192": ModelMetadata(
            model_name="llama3-70b-8192",
            max_context_tokens=8000,
            max_output_tokens=2048,
        ),
        "llama3-8b-8192": ModelMetadata(
            model_name="llama3-8b-8192",
            max_context_tokens=8000,
            max_output_tokens=2048,
        ),
    }
    DEFAULT_API_KEY = os.environ.get("GROQ_API_KEY")

    def __init__(
        self,
        model_name: str,
        request_timeout: float,
        max_output_tokens: int,
        temperature: float,
        stream: bool,
        max_context_tokens: int = sys.maxsize,
        api_key: str = DEFAULT_API_KEY,  # type: ignore[assignment]
        stop: Optional[str | List[str]] = "<|eot_id|>",
    ):
        super().__init__(
            model_name,
            request_timeout,
            max_output_tokens,
            temperature,
            stream=stream,
            max_context_tokens=max_context_tokens,
            stop=stop,
        )
        self.api_key = api_key

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        messages = self.prompt_to_messages(prompt) if prompt else messages
        # TODO: Decide if we want to use the shared client or create a new client for each request
        # for this client after testing on OAI.
        client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

        return client.chat.completions.create(
            messages=messages,  # type: ignore[arg-type]
            model=self.model_name,
            timeout=self.request_timeout,
            max_tokens=self.max_output_tokens,
            temperature=self.temperature,
            stream=self.stream,
            stop=self.stop,
        )
