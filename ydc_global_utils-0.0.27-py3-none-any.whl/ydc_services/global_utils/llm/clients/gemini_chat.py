import base64
import logging
import os
import re
import sys
from typing import (
    Iterable,
    List,
    Optional,
)

import filelock
import vertexai
from google.api_core.exceptions import InvalidArgument as GoogleInvalidArgument
from google.cloud.aiplatform_v1beta1.types import (
    content as gapic_content_types,
)
from vertexai.preview.generative_models import (
    Content,
    FinishReason,
    GenerationConfig,
    GenerationResponse,
    GenerativeModel,
    Image,
    Part,
)

from ydc_services.global_utils.file_upload.schemas import (
    FileContext,
    FileContextOrError,
)
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    Messages,
    ModelMetadata,
    PromptOrMessages,
)
from ydc_services.global_utils.llm.clients.exceptions import (
    EarlyStoppingException,
    TokenLimitExceededException,
)
from ydc_services.global_utils.llm.tokenizers.gemini_tokenizer import GeminiTokenizer

logger = logging.getLogger(__package__)


class GeminiChat(LLM[GenerationResponse, GenerationResponse]):
    # https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models
    MODEL_NAME_TO_METADATA = {
        "gemini-pro": ModelMetadata(
            model_name="gemini-pro",
            max_context_tokens=32760,
            max_output_tokens=8192,
        ),
        "gemini-1.5-pro-002": ModelMetadata(
            model_name="gemini-1.5-pro-002",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
        "gemini-1.5-flash-002": ModelMetadata(
            model_name="gemini-1.5-flash-002",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
        "gemini-2.0-flash-001": ModelMetadata(
            model_name="gemini-2.0-flash-001",
            max_context_tokens=1000000,
            max_output_tokens=8192,
        ),
    }
    CREDENTIALS_PATH = "/tmp/CARvRa3Mmx3g"  # Deliberately nondescript path
    LOCATION = "us-central1"  # Previous default was "us-east4", but Gemini 2 is only in us-central1
    PROJECT = "gemini-413421"
    BLOCK_NONE = {
        category: gapic_content_types.SafetySetting.HarmBlockThreshold.BLOCK_NONE
        for category in list(gapic_content_types.HarmCategory)
    }
    FINISH_REASON_TO_MESSAGE = {
        # These 2 other reasons that we ignore now are MAX_TOKENS and STOP - they are not relevant for the user.
        FinishReason.SAFETY: "The token generation was stopped as the response was flagged for safety reasons.",
        FinishReason.RECITATION: "The token generation was stopped as the response was flagged for unauthorized citations.",
        FinishReason.OTHER: "The token generation was stopped for other reasons.",
        FinishReason.BLOCKLIST: "The token generation was stopped as the response was flagged for the terms which are included from the terminology blocklist.",
        FinishReason.PROHIBITED_CONTENT: "The token generation was stopped as the response was flagged for the prohibited contents.",
        FinishReason.SPII: "The token generation was stopped as the response was flagged for Sensitive Personally Identifiable Information (SPII) contents.",
    }

    # Access key is passed separately, currently via a file pointed to by the GOOGLE_APPLICATION_CREDENTIALS environment vaiable
    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        stream: bool,
        temperature: int | float,
        max_context_tokens: int = sys.maxsize,
        stop_sequences: Optional[List[str]] = None,
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            GeminiTokenizer(model_name),
        )
        self._ensure_credentials()
        vertexai.init(project=self.PROJECT, location=self.LOCATION)
        self.generation_config = GenerationConfig(
            temperature=temperature,
            candidate_count=1,
            max_output_tokens=max_output_tokens,
            stop_sequences=stop_sequences if stop_sequences else ["STOP!"],
        )

    @classmethod
    def get_text_from_response(cls, response: GenerationResponse) -> str:
        return response.text

    def _create_request(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Messages] = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> GenerationResponse | Iterable[GenerationResponse]:
        if prompt:
            messages = self.prompt_to_messages(prompt)

        assert messages is not None

        converted_messages: List[
            Content
        ] = self._openai_style_messages_to_gemini_content_list(
            messages, uploaded_image_files_context
        )

        chat_history = converted_messages[:-1]
        current_message = converted_messages[-1]

        client = GenerativeModel(model_name=self.model_name)
        chat_session = client.start_chat(
            # Turn off response validation to bypass the ResponseValidationError exception
            # when the model didn't finish the response due to max_output_tokens, or other reasons.
            response_validation=False,
            history=chat_history,
        )
        return chat_session.send_message(
            current_message.parts,
            generation_config=self.generation_config,
            safety_settings=self.BLOCK_NONE,
            stream=self.stream,
        )

    @classmethod
    def _openai_style_messages_to_gemini_content_list(
        cls,
        oai_style_messages: Messages,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> List[Content]:
        chat_history: List[Content] = []
        for item in oai_style_messages:
            role, message = item["role"], item["content"]
            if role == "system":
                # VertexAI/Gemini doesn't support other roles except user and model: https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/gemini
                # From their getting-started guide, they put the system messages in the user role. https://github.com/GoogleCloudPlatform/generative-ai/blob/main/gemini/getting-started/intro_gemini_pro_python.ipynb
                chat_history.append(
                    Content(role="user", parts=[Part.from_text(message)])
                )
                # TODO: We should put this confirmation message into the prompt instead.
                # Currently @Roger is reusing Turbo prompt for Gemini so we have to put it here temporarily.
                chat_history.append(
                    Content(role="model", parts=[Part.from_text("Understood.")])
                )
            elif role == "user":
                parts = [Part.from_text(message)]
                if uploaded_image_files_context:
                    parts.extend(
                        cls.convert_image_files_context_to_messages(
                            uploaded_image_files_context
                        )
                    )
                chat_history.append(Content(role="user", parts=parts))
            elif role in ["assistant", "model"]:
                chat_history.append(
                    Content(role="model", parts=[Part.from_text(message)])
                )
            else:
                logger.error(
                    "Unknown role",
                    role=role,
                    message=message,
                )
        return chat_history

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        formatted_messages: Messages = []
        for line in prompt.split("<||im_start||>"):
            if len(line.splitlines()) > 1:
                all_lines = line.splitlines()
                role = all_lines[0]
                last_token_index = all_lines.index("<||im_end||>")
                message = "\n".join(all_lines[1:last_token_index]).strip()
                formatted_messages.append({"role": role, "content": message})
        return formatted_messages

    @classmethod
    def convert_image_files_context_to_messages(
        cls, uploaded_image_files_context: List[FileContextOrError]
    ) -> List[Part]:
        image_parts = []
        for image_file_context in uploaded_image_files_context:
            if isinstance(image_file_context, FileContext):
                image_bytes = base64.b64decode(image_file_context.content)
                image_part = Part.from_image(Image.from_bytes(image_bytes))
                image_parts.append(image_part)
        return image_parts

    def _yield_token_from_generator(self, generator: Iterable[GenerationResponse]):
        for chunk in generator:
            finish_reason_code = chunk.candidates[0].finish_reason

            if finish_reason_code != FinishReason.FINISH_REASON_UNSPECIFIED:
                try:
                    token = chunk.text
                    yield str(token)
                except Exception:
                    logger.error(
                        "Gemini model returned an unexpected finish reason. No text was returned.",
                        finish_reason_code=finish_reason_code,
                        exc_info=True,
                    )
                    error_code = f"STREAMING_EARLY_STOPPING_{finish_reason_code.name}"
                    error_message = self.FINISH_REASON_TO_MESSAGE.get(
                        finish_reason_code,
                        self.FINISH_REASON_TO_MESSAGE[FinishReason.OTHER],
                    )
                    raise EarlyStoppingException(
                        finish_reason_code, error_message, error_code
                    )
                break

            yield chunk.text

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if not self.stream:
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                num_input_tokens=response.usage_metadata.prompt_token_count,
            )
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=response.usage_metadata.candidates_token_count,
            )
            return response
        else:
            return self._wrap_stream_with_cost_tracker(
                prompt_or_messages, response, uploaded_image_files_context
            )

    def _wrap_stream_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if uploaded_image_files_context:
            CostTracker.increment_input_image_count(
                model_name=self.model_name, num_images=len(uploaded_image_files_context)
            )

        for event in response:
            finish_reason_code = event.candidates[0].finish_reason
            if finish_reason_code == FinishReason.STOP:
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    num_input_tokens=event.usage_metadata.prompt_token_count,
                )
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=event.usage_metadata.candidates_token_count,
                )
            yield event

    def _ensure_credentials(self) -> None:
        """Ensure credentials file exists and is properly set up."""
        # Check if credentials already exist and are valid

        # https://py-filelock.readthedocs.io/en/latest/index.html
        # Create a lock file path to prevent race conditions
        lock_path = f"{self.CREDENTIALS_PATH}.lock"
        file_lock = filelock.FileLock(lock_path)

        try:
            with file_lock:
                # Check if credentials already exist and are valid
                if (
                    os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
                    == self.CREDENTIALS_PATH
                    and os.path.exists(self.CREDENTIALS_PATH)
                    and os.path.getsize(self.CREDENTIALS_PATH) > 0
                ):
                    return

                # Get API key from environment
                api_key = os.getenv("GOOGLE_GEMINI_API_KEY")
                if not api_key:
                    raise ValueError(
                        "GOOGLE_GEMINI_API_KEY environment variable not set"
                    )

                # Create credentials file with restricted permissions
                try:
                    with os.fdopen(
                        os.open(
                            self.CREDENTIALS_PATH,
                            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                            mode=0o600,  # File is private
                        ),
                        "wb",
                    ) as fd:
                        fd.write(base64.b64decode(api_key))

                    # Set environment variable to point to credentials file
                    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = self.CREDENTIALS_PATH
                except Exception as e:
                    raise RuntimeError(f"Failed to create credentials file: {e}")
        except filelock.Timeout:
            raise RuntimeError("Could not acquire lock for credentials file")

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Gemini pattern: "The input token count (3000011) exceeds the maximum number of tokens allowed (1000000)"
        if (
            isinstance(error, GoogleInvalidArgument)
            and "exceeds the maximum number of tokens allowed" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # Gemini pattern: "The input token count (3000011) exceeds the maximum number of tokens allowed (1000000)"
        match = re.search(r"token count \((\d+)\).+allowed \((\d+)\)", error_message)
        if match:
            return abs(int(match.group(2)) - int(match.group(1)))
        return None


if __name__ == "__main__":
    llm = GeminiChat(
        model_name="gemini-2.0-flash-001",
        temperature=0.5,
        max_output_tokens=1000,
        stream=True,
    )

    for token in llm.get_token_generator(
        messages=[{"role": "user", "content": "What can you do?"}]
    ):
        print(token)
