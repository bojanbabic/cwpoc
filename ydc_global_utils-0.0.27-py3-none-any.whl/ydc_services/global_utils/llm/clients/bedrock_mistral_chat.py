import json
import re
import sys
from typing import (
    Dict,
    Iterable,
    List,
    Optional,
)

import boto3
import botocore.exceptions
from botocore.client import Config
from botocore.response import StreamingBody

from ydc_services.global_utils.file_upload.schemas import FileContextOrError
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.llm.clients.base import (
    LLM,
    Messages,
    ModelMetadata,
    PromptOrMessages,
)
from ydc_services.global_utils.llm.clients.exceptions import TokenLimitExceededException
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm.clients.shared_bedrock import BedrockWest2
from ydc_services.global_utils.llm.tokenizers.heuristic_tokenizer import (
    HeuristicTokenizer,
)


class BedrockMistralChat(LLM[StreamingBody, dict]):
    MODEL_NAME_TO_METADATA = {
        "mistral.mistral-large-2402-v1:0": ModelMetadata(
            model_name="mistral.mistral-large-2402-v1:0",
            max_context_tokens=32000,
            max_output_tokens=2048,
            input_token_price=0.000004,
            output_token_price=0.000012,
        ),
        "mistral.mistral-large-2407-v1:0": ModelMetadata(
            model_name="mistral.mistral-large-2407-v1:0",
            max_context_tokens=128000,
            max_output_tokens=2048,
            input_token_price=0.000003,
            output_token_price=0.000009,
        ),
    }

    def __init__(
        self,
        model_name: str,
        max_output_tokens: int,
        request_timeout: float,
        temperature: float,
        max_context_tokens: int = sys.maxsize,
        stream: bool = False,
        max_retries: int = 0,
    ):
        super().__init__(
            model_name,
            max_output_tokens,
            max_context_tokens,
            stream,
            temperature,
            HeuristicTokenizer(model_name),
        )
        self.request_timeout = request_timeout
        self.max_retries = max_retries

    @classmethod
    def get_text_from_response(cls, response: Dict) -> str:
        # Decode the response body.
        model_response = json.loads(
            response.read().decode("utf-8")  # type: ignore[attr-defined]
        )
        return model_response["choices"][0]["message"]["content"]

    @classmethod
    def prompt_to_messages(
        cls,
        prompt: str,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Messages:
        # NOTE: Ignoring uploaded_image_files_context for now since it's not supported
        return OpenAIChat.prompt_to_messages(prompt)

    def _create_request(
        self,
        prompt: str | None = None,
        messages: Messages | None = None,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ) -> Dict | Dict:
        assert prompt, "Prompt is required for BedrockMistralChat"

        config = Config(
            connect_timeout=self.request_timeout,
            read_timeout=self.request_timeout,
            retries={"max_attempts": self.max_retries},
        )
        boto3_client = boto3.client(
            "bedrock-runtime",
            region_name=BedrockWest2.REGION_NAME,
            aws_access_key_id=BedrockWest2.DEFAULT_BEDROCK_ACCESS_KEY,
            aws_secret_access_key=BedrockWest2.DEFAULT_BEDROCK_SECRET_KEY,
            config=config,
        )
        invoke_model_func = (
            boto3_client.invoke_model
            if not self.stream
            else boto3_client.invoke_model_with_response_stream
        )
        request_messages = messages or self.prompt_to_messages(prompt)
        native_request = {
            "messages": request_messages,
            "max_tokens": self.max_output_tokens,
            "temperature": self.temperature,
        }
        # Convert the native request to JSON.
        request = json.dumps(native_request)
        return invoke_model_func(modelId=self.model_name, body=request)["body"]

    def _yield_token_from_generator(self, generator: Iterable[dict]):
        for event in generator:
            chunk = json.loads(event["chunk"]["bytes"])
            choice = chunk["choices"][0]
            if "message" in choice:
                yield choice["message"]["content"]
            if "stop_reason" in choice and choice["stop_reason"]:
                break

    def _wrap_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        response,
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        if not self.stream:
            CostTracker.increment_input_count(
                self.model_name,
                prompt_or_messages,
                get_token_count=self.tokenizer.count_tokens,
            )
            text = self.get_text_from_response(response)
            CostTracker.increment_output_token_count(
                self.model_name,
                num_output_tokens=self.tokenizer.count_tokens(text),
            )
            return response
        else:
            return self._wrap_stream_with_cost_tracker(
                prompt_or_messages, response, uploaded_image_files_context
            )

    def _wrap_stream_with_cost_tracker(
        self,
        prompt_or_messages: PromptOrMessages,
        generator: Iterable[Dict],
        uploaded_image_files_context: Optional[List[FileContextOrError]] = None,
    ):
        generated_event_count = 0
        last_usage_object = None
        # try/finally to ensure that we always call the cost tracker
        # There are cases where the generator is not completed which causes the cost tracker to not be called (without try/finally)
        try:
            for event in generator:
                if "amazon-bedrock-invocationMetrics" in event:
                    last_usage_object = event["amazon-bedrock-invocationMetrics"]
                generated_event_count += 1
                yield event

        finally:
            if uploaded_image_files_context:
                CostTracker.increment_input_image_count(
                    model_name=self.model_name,
                    num_images=len(uploaded_image_files_context),
                )
            if last_usage_object:
                # If there is a usage object, then we can use it to get the token count
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    num_input_tokens=last_usage_object["inputTokenCount"],
                )
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=last_usage_object["outputTokenCount"],
                )
            else:
                CostTracker.increment_input_count(
                    self.model_name,
                    prompt_or_messages,
                    get_token_count=self.tokenizer.count_tokens,
                )
                CostTracker.increment_output_token_count(
                    self.model_name,
                    num_output_tokens=generated_event_count,
                )

    @classmethod
    def _handle_token_limit_error(cls, error: Exception, model_name: str) -> bool:
        error_message = str(error)
        class_name = cls.__name__

        # Bedrock Llama pattern: "Prompt contains 187190 tokens and 0 draft tokens, too large for model with 131072 maximum context length"
        if (
            isinstance(error, botocore.exceptions.EventStreamError)
            and "too large for model with" in error_message
        ):
            excess_tokens = cls._get_excess_tokens(error_message)
            message = f"Token limit exceeded for {class_name} provider (model: {model_name}). "

            if excess_tokens:
                message += f"Exceeded by approximately {excess_tokens} tokens."
            else:
                message += "Unable to determine exact excess token count."

            raise TokenLimitExceededException(
                message, excess_tokens, class_name, model_name
            )

        return False

    @staticmethod
    def _get_excess_tokens(error_message: str) -> Optional[int]:
        # Bedrock Mistral pattern: "Prompt contains 187190 tokens and 0 draft tokens, too large for model with 131072 maximum context length"
        match = re.search(
            r"contains (\d+) tokens and.+with (\d+) maximum context length",
            error_message,
        )
        if match:
            return abs(int(match.group(2)) - int(match.group(1)))
        return None
