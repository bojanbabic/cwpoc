from abc import ABC, abstractmethod
from typing import Collection, Literal, Optional, Tuple, TypeAlias

CitationTemplateType = Literal["simple", "self_cite", "simple_self_cite"]


# WARNING: When you implement a new CitableItem currently, you need to update
#  step_update_answer_and_citation if you would like to use LLMCitationHandler.
class CitableItem(ABC):
    @abstractmethod
    def get_citation_link_and_score(
        self,
        snippet_to_be_cited: Optional[str] = None,
        use_highlight_snippet: bool = False,
    ) -> Tuple[str, Optional[float]]:
        # Score will be provided if snippet_to_be_cited is provided
        ...

    @abstractmethod
    def form_llm_context_with_citation_number(
        self, starting_citation_num: int, template_type: CitationTemplateType
    ) -> str:
        ...


class CitableItemsCollection(ABC):
    # A CitableItemsCollection cannot be cited as a whole. Instead, it holds many
    # CitableItems that can be individually cited.
    @abstractmethod
    def get_citable_items(self) -> Collection[CitableItem]:
        ...

    @abstractmethod
    def form_llm_context_with_citation_numbers_for_collection(
        self, starting_citation_num: int, template_type: CitationTemplateType
    ) -> str:
        ...


Citable: TypeAlias = CitableItem | CitableItemsCollection


def form_citation_num_string(
    citation_template_type: CitationTemplateType, citation_num: int
) -> str:
    if citation_template_type == "simple":
        return f"[{citation_num}]"
    elif citation_template_type == "self_cite":
        return f"Source [{citation_num}],"
    elif citation_template_type == "simple_self_cite":
        return f"[[{citation_num}]]."
    else:
        raise ValueError(f"Unknown citation_template_type: {citation_template_type}")
