IMAGE_CAPTION_REGEX = (
    # Have 1 or 2 stars, not capture the asterisks group, capture whole caption line + optional the description line
    # See these test cases for what this regex does:
    # https://github.com/Su-Sea/youdotcom-services/blob/dce93c30000e64a8c2bdc3db2b0d2491394ad614/ydc_services/ml_services/export_service/tests/test_markdown_image_parser.py#L172
    "(?:\n?\n?(?:\*\*?(.*)\*?\*)(.*)(\n: .*)?|"
    # Caption in next line
    "\n(.*)"
    # End of caption group
    ")"
)
