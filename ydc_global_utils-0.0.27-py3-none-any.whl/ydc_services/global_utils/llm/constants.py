from typing import List

from pydantic import BaseModel

from ydc_services.global_utils.llm.clients.bedrock_mistral_chat import (
    BedrockMistralChat,
)
from ydc_services.global_utils.llm.clients.claude3_chat import Claude3Chat
from ydc_services.global_utils.llm.clients.cohere_chat import CohereChat
from ydc_services.global_utils.llm.clients.databricks import Databricks
from ydc_services.global_utils.llm.clients.fireworks_ai import FireworksAI
from ydc_services.global_utils.llm.clients.gemini_chat import GeminiChat
from ydc_services.global_utils.llm.clients.grok_chat import GrokChat
from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat
from ydc_services.global_utils.llm.clients.openai_o1_chat import OpenAIO1Chat
from ydc_services.global_utils.llm.clients.together_ai import TogetherAI
from ydc_services.global_utils.llm.clients.upstage_ai import UpstageAI

CDN_YDC_BASE = "https://cdn.you.com/img"


def get_icon_url(model_name: str) -> str:
    return f"{CDN_YDC_BASE}/shared/chat-mode-switcher/models/{model_name}.png"


class AiModel(BaseModel):
    id: str
    imageUrl: str
    name: str
    company: str
    tagline: str
    isUncensoredModel: bool
    isAllowedForUserChatModes: bool
    isProOnly: bool
    contextLimit: int


RESERVED_TOKENS_FOR_INSTRUCTIONS = 2000


def get_conservative_limit(model_limit: int):
    # we cap the context limit at 200k tokens for all models even if the model has a higher limit
    if model_limit > 200_000:
        return 200_000

    return model_limit - RESERVED_TOKENS_FOR_INSTRUCTIONS


AI_MODELS: List[AiModel] = [
    AiModel(
        id="gpt_4_5_preview",
        imageUrl=get_icon_url("gpt_4_5_preview"),
        name="GPT-4.5 Preview",
        company="OpenAI",
        tagline="OpenAI's largest multimodal model (preview)",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIChat.MODEL_NAME_TO_METADATA[
                "gpt-4.5-preview-2025-02-27"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="openai_o3_mini_high",
        imageUrl=get_icon_url("openai_o3_mini_high"),
        name="o3 Mini (High Effort)",
        company="OpenAI",
        tagline="OpenAI's most advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIO1Chat.MODEL_NAME_TO_METADATA["o3-mini"].max_context_tokens
        ),
    ),
    AiModel(
        id="openai_o3_mini_medium",
        imageUrl=get_icon_url("openai_o3_mini_medium"),
        name="o3 Mini",
        company="OpenAI",
        tagline="OpenAI's efficient reasoning model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIO1Chat.MODEL_NAME_TO_METADATA["o3-mini"].max_context_tokens
        ),
    ),
    AiModel(
        id="openai_o1",
        # We can't use the "openai_o1" icon because it has been used for o1 Preview
        imageUrl=get_icon_url("openai_o1_full"),
        name="o1",
        company="OpenAI",
        tagline="OpenAI's original reasoning model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIO1Chat.MODEL_NAME_TO_METADATA["o1"].max_context_tokens
        ),
    ),
    AiModel(
        id="openai_o1_preview",
        imageUrl=get_icon_url("openai_o1"),
        name="o1 Preview",
        company="OpenAI",
        tagline="OpenAI's beta reasoning model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIO1Chat.MODEL_NAME_TO_METADATA["o1-preview"].max_context_tokens
        ),
    ),
    AiModel(
        id="openai_o1_mini",
        imageUrl=get_icon_url("openai_o1_mini"),
        name="o1 Mini",
        company="OpenAI",
        tagline="OpenAI's lightweight reasoning model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIO1Chat.MODEL_NAME_TO_METADATA["o1-mini"].max_context_tokens
        ),
    ),
    AiModel(
        id="gpt_4o_mini",
        imageUrl=get_icon_url("gpt_4o_mini"),
        name="GPT-4o mini",
        company="OpenAI",
        tagline="OpenAI's efficient multimodal model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            OpenAIChat.MODEL_NAME_TO_METADATA["gpt-4o-mini"].max_context_tokens
        ),
    ),
    AiModel(
        id="gpt_4o",
        imageUrl=get_icon_url("gpt_4o"),
        name="GPT-4o",
        company="OpenAI",
        tagline="OpenAI's advanced multimodal model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            OpenAIChat.MODEL_NAME_TO_METADATA["gpt-4o"].max_context_tokens
        ),
    ),
    AiModel(
        id="gpt_4_turbo",
        imageUrl=get_icon_url("gpt_4_turbo"),
        name="GPT-4 Turbo",
        company="OpenAI",
        tagline="OpenAI's legacy fast model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            OpenAIChat.MODEL_NAME_TO_METADATA["gpt-4o"].max_context_tokens
        ),
    ),
    AiModel(
        id="gpt_4",
        imageUrl=get_icon_url("gpt_4"),
        name="GPT-4",
        company="OpenAI",
        tagline="OpenAI's legacy advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            OpenAIChat.MODEL_NAME_TO_METADATA["gpt-4"].max_context_tokens
        ),
    ),
    AiModel(
        id="claude_3_7_sonnet_thinking",
        imageUrl=get_icon_url("claude_3_7_sonnet_thinking"),
        name="Claude 3.7 Sonnet (Extended)",
        company="Anthropic",
        tagline="Anthropic's extended reasoning model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            Claude3Chat.MODEL_NAME_TO_METADATA[
                "claude-3-7-sonnet-20250219"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="claude_3_7_sonnet",
        imageUrl=get_icon_url("claude_3_7_sonnet"),
        name="Claude 3.7 Sonnet",
        company="Anthropic",
        tagline="Anthropic's most intelligent model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            Claude3Chat.MODEL_NAME_TO_METADATA[
                "claude-3-7-sonnet-20250219"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="claude_3_5_sonnet",
        imageUrl=get_icon_url("claude_3_5_sonnet"),
        name="Claude 3.5 Sonnet",
        company="Anthropic",
        tagline="Anthropic's legacy intelligent model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            Claude3Chat.MODEL_NAME_TO_METADATA[
                "claude-3-5-sonnet-20241022"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="claude_3_opus",
        imageUrl=get_icon_url("claude_3_opus"),
        name="Claude 3 Opus",
        company="Anthropic",
        tagline="Anthropic's legacy powerful model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            Claude3Chat.MODEL_NAME_TO_METADATA[
                "claude-3-opus-20240229"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="claude_3_sonnet",
        imageUrl=get_icon_url("claude_3_sonnet"),
        name="Claude 3 Sonnet",
        company="Anthropic",
        tagline="Anthropic's legacy balanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            Claude3Chat.MODEL_NAME_TO_METADATA[
                "claude-3-sonnet-20240229"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="claude_3_5_haiku",
        imageUrl=get_icon_url("claude_3_5_haiku"),
        name="Claude 3.5 Haiku",
        company="Anthropic",
        tagline="Anthropic's fastest model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            Claude3Chat.MODEL_NAME_TO_METADATA[
                "claude-3-5-haiku-20241022"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="qwq_32b",
        imageUrl=get_icon_url("qwq_32b"),
        name="QwQ 32B",
        company="Alibaba",
        tagline="Alibaba's reasoning model (US hosted)",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            FireworksAI.MODEL_NAME_TO_METADATA["qwq-32b"].max_context_tokens
        ),
    ),
    AiModel(
        id="qwen2p5_72b",
        imageUrl=get_icon_url("qwen2p5_72b"),
        name="Qwen2.5 72B",
        company="Alibaba",
        tagline="Alibaba's most advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "Qwen/Qwen2.5-72B-Instruct-Turbo"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="qwen2p5_coder_32b",
        imageUrl=get_icon_url("qwen2p5_coder_32b"),
        name="Qwen2.5 Coder 32B",
        company="Alibaba",
        tagline="Alibaba's most advanced coding model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "Qwen/Qwen2.5-Coder-32B-Instruct"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="deepseek_r1",
        imageUrl=get_icon_url("deepseek_r1"),
        name="DeepSeek-R1",
        company="DeepSeek",
        tagline="Advanced reasoning model (US hosted)",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "deepseek-ai/DeepSeek-R1"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="deepseek_v3",
        imageUrl=get_icon_url("deepseek_v3"),
        name="DeepSeek-V3",
        company="DeepSeek",
        tagline="Advanced language model (US hosted)",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=True,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "deepseek-ai/DeepSeek-V3"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="grok_2",
        imageUrl=get_icon_url("grok_2"),
        name="Grok 2",
        company="xAI",
        tagline="xAI's latest language model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            GrokChat.MODEL_NAME_TO_METADATA["grok-2-1212"].max_context_tokens
        ),
    ),
    AiModel(
        id="llama3_3_70b",
        imageUrl=get_icon_url("llama3_3_70b"),
        name="Llama 3.3 70B",
        company="Meta",
        tagline="Meta's most advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "meta-llama/Llama-3.3-70B-Instruct-Turbo"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="llama3_2_90b",
        imageUrl=get_icon_url("llama3_2_90b"),
        name="Llama 3.2 90B",
        company="Meta",
        tagline="Meta's legacy advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "meta-llama/Llama-3.2-90B-Vision-Instruct-Turbo"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="llama3_1_405b",
        imageUrl=get_icon_url("llama3_1_405b"),
        name="Llama 3.1 405B",
        company="Meta",
        tagline="Meta's legacy advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "meta-llama/Meta-Llama-3.1-405B-Instruct-Turbo"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="mistral_large_2",
        imageUrl=get_icon_url("mistral_large_2"),
        name="Mistral Large 2",
        company="Mistral AI",
        tagline="Mistral AI's most advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            BedrockMistralChat.MODEL_NAME_TO_METADATA[
                "mistral.mistral-large-2407-v1:0"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="gemini_2_flash",
        imageUrl=get_icon_url("gemini_2_flash"),
        name="Gemini 2.0 Flash",
        company="Google",
        tagline="Google's latest and fastest model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            GeminiChat.MODEL_NAME_TO_METADATA["gemini-2.0-flash-001"].max_context_tokens
        ),
    ),
    AiModel(
        id="gemini_1_5_flash",
        imageUrl=get_icon_url("gemini_1_5_flash"),
        name="Gemini 1.5 Flash",
        company="Google",
        tagline="Google's legacy fast model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            GeminiChat.MODEL_NAME_TO_METADATA["gemini-1.5-flash-002"].max_context_tokens
        ),
    ),
    AiModel(
        id="gemini_1_5_pro",
        imageUrl=get_icon_url("gemini_1_5_pro"),
        name="Gemini 1.5 Pro",
        company="Google",
        tagline="Google's most advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            GeminiChat.MODEL_NAME_TO_METADATA["gemini-1.5-pro-002"].max_context_tokens
        ),
    ),
    AiModel(
        id="databricks_dbrx_instruct",
        imageUrl=get_icon_url("databricks_dbrx_instruct"),
        name="DBRX-Instruct",
        company="Databricks",
        tagline="Databricks' latest model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            Databricks.MODEL_NAME_TO_METADATA[
                "databricks-dbrx-instruct"
            ].max_context_tokens
        ),
    ),
    AiModel(
        id="command_r_plus",
        imageUrl=get_icon_url("command_r_plus"),
        name="Command R+",
        company="Cohere",
        tagline="Cohere's most advanced model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=True,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            CohereChat.MODEL_NAME_TO_METADATA["command-r-plus"].max_context_tokens
        ),
    ),
    AiModel(
        id="solar_1_mini",
        imageUrl=get_icon_url("solar_1_mini"),
        name="Solar 1 Mini",
        company="Upstage AI",
        tagline="Upstage's latest model",
        isUncensoredModel=False,
        isAllowedForUserChatModes=False,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            UpstageAI.MODEL_NAME_TO_METADATA["solar-1-mini-chat"].max_context_tokens
        ),
    ),
    AiModel(
        id="dolphin_2_5",
        imageUrl=get_icon_url("dolphin_2_5"),
        name="Dolphin 2.5",
        company="Cognitive Computation",
        tagline="Uncensored fine-tuned Mixtral model",
        isUncensoredModel=True,
        isAllowedForUserChatModes=False,
        isProOnly=False,
        contextLimit=get_conservative_limit(
            TogetherAI.MODEL_NAME_TO_METADATA[
                "cognitivecomputations/dolphin-2.5-mixtral-8x7b"
            ].max_context_tokens
        ),
    ),
]

AI_MODELS_WITH_IMAGE_SUPPORT: List[str] = [
    "gpt_4_5_preview",
    "gpt_4o_mini",
    "gpt_4o",
    "gpt_4_turbo",
    "claude_3_5_sonnet",
    "claude_3_7_sonnet",
    "claude_3_7_sonnet_thinking",
    "gemini_2_flash",
    "gemini_1_5_flash",
    "gemini_1_5_pro",
    "claude_3_sonnet",
    "claude_3_opus",
    "llama3_2_90b",
    "openai_o1",
]
