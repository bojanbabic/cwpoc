import json
import logging
import traceback
from abc import ABC, abstractmethod
from typing import Generic, List, Type, TypeVar, get_args

from anthropic.types import ToolParam
from openai.types import FunctionParameters
from openai.types.beta import FunctionToolParam
from pydantic import BaseModel, ValidationError

from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm.tools.schemas import (
    ToolCall,
    ToolCallInput,
    ToolCallInputsError,
)

I = TypeVar("I", bound=BaseModel)  # noqa: E741
O = TypeVar("O")  # noqa: E741

logger = logging.getLogger(__package__)


class Tool(Generic[I, O], ABC):
    tool_call_cls: Type[ToolCall[str, I, O]]

    def __init__(
        self,
        name: str,
        description: str,
        should_remove_title_from_properties: bool = False,
        use_strict_mode: bool = False,
    ):
        assert self.tool_call_cls
        # Name and description will be provided to the LLM
        self.name = name
        self.description = description
        self.should_remove_title_from_properties = should_remove_title_from_properties
        self.use_strict_mode = use_strict_mode

        model_fields = self.tool_call_cls.model_fields
        self.tool_id: str = get_args(model_fields["tool_id"].annotation)[0]
        assert model_fields["input"].annotation
        self.input_cls: Type[I] = model_fields["input"].annotation
        self.openai_tool_schema = self._get_openai_tool_schema()
        self.claude_tool_schema = self._get_claude_tool_schema()

    @abstractmethod
    def run_tool(self, inputs: I) -> O:
        ...

    def run(
        self, tool_call_input: ToolCallInput
    ) -> ToolCallInputsError | ToolCall[str, I, O]:  # noqa: E741
        # Raises ValidationError if it does not conform to schema
        try:
            inputs = self.input_cls(**tool_call_input.tool_inputs)
        except ValidationError as exc:
            return ToolCallInputsError(
                tool_inputs=tool_call_input, error=json.dumps(exc.errors())
            )
        except Exception as exc:
            return ToolCallInputsError(tool_inputs=tool_call_input, error=str(exc))

        output = None
        error = None
        try:
            with record(f"tool_call_run/{self.tool_id}/{self.name}", logger=logger):
                output = self.run_tool(inputs)
        except Exception:
            error = traceback.format_exc()

        return ToolCall(
            tool_inputs=tool_call_input,
            tool_id=self.tool_id,
            tool_name=tool_call_input.tool_name,
            input=inputs,
            output=output,
            error=error,
        )

    def _get_openai_tool_schema(self) -> FunctionToolParam:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self._get_tool_schema_parameters(),
                **({"strict": True} if self.use_strict_mode else {}),  # type: ignore[typeddict-item] # `name` is in already
            },
        }

    def _get_claude_tool_schema(self) -> ToolParam:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self._get_tool_schema_parameters(),
        }

    def _get_tool_schema_parameters(self) -> FunctionParameters:
        input_cls_schema_json = self.input_cls.schema_json()
        parameters = json.loads(input_cls_schema_json)
        if self.should_remove_title_from_properties:
            # The other titles are just a capitalized version of the field names.
            parameters_without_title = remove_non_property_fields_recursively(
                parameters, ["title"]
            )
            return parameters_without_title
        else:
            # The top-level title is the same as the class name. We omit to avoid confusion the LLM.
            parameters.pop("title")
            return parameters


def remove_non_property_fields_recursively(data, fields_to_remove: List[str]):
    if isinstance(data, dict):
        # Create new dictionary without non-property fields
        return {
            key: remove_non_property_fields_recursively(value, fields_to_remove)
            for key, value in data.items()
            if key not in fields_to_remove
            # `key` is a property field that should not be removed if `value` is a dict
            or isinstance(value, dict)
        }
    elif isinstance(data, list):
        # Create new list with processed items
        return [
            remove_non_property_fields_recursively(item, fields_to_remove)
            for item in data
        ]
    else:
        # Return non-dict/non-list values as is
        return data
