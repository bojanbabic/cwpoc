from typing import Any, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=str)
I = TypeVar("I")  # noqa: E741
O = TypeVar("O")  # noqa: E741
TC = TypeVar("TC")


class ToolCallInput(BaseModel):
    call_id: str
    tool_name: str
    tool_inputs: Dict[str, Any]


class ToolCallInputsError(BaseModel):
    tool_inputs: ToolCallInput
    error: str


class ToolCall(BaseModel, Generic[T, I, O]):
    # This is a fixed name that will not be shown to the LLM and should not change frequently
    tool_id: T
    tool_inputs: ToolCallInput
    # This is shown to the LLM and can be changed for different experiments
    tool_name: str
    input: I
    output: Optional[O]
    error: Optional[str] = None


class ToolEngineTurn(BaseModel, Generic[TC]):
    tool_calls: List[ToolCallInputsError | TC]


class MultiTurnToolEngineOutput(BaseModel, Generic[TC]):
    turns: List[ToolEngineTurn[TC]]
    termination_reason: Optional[str] = None
