from typing import List, Optional

from ydc_services.global_utils.llm.clients.base import LLM


def get_total_timeout_for_llm_clients(
    llm_clients: List[LLM], default_timeout: int = 20, additional_buffer: int = 10
) -> Optional[float]:
    return (
        sum(
            [
                getattr(llm_client, "request_timeout", default_timeout)
                for llm_client in llm_clients
            ]
        )
        + additional_buffer
    )
