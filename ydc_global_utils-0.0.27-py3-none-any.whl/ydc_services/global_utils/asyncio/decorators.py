import asyncio
import functools
import json
from contextvars import copy_context
from typing import Any, Dict, Optional

import aiohttp
from aiohttp import BodyPartReader, TCPConnector, web
from aiohttp.web_request import Request

from ydc_services.global_utils.launchdarkly.constants import LD_CONTEXT_KEY
from ydc_services.global_utils.launchdarkly.utils import (
    update_request_json_with_launchdarkly_flags,
)


def get_request_context():
    """Propagate the captured request global context to the executor.

    The context includes 'request_context_var' generated at the aiohttp web
    app's middleware layer
    """
    context = copy_context()
    return context.run


def requests_async_event_loop(
    cb=None,
    *,
    executor_name="executor",
    include_request=False,
    update_json_with_launchdarkly=False,
    wrap_response=False,
):
    """Generic Decorator that is used for almost all HTTP endpoints except SSE

    This decorator wraps a request handler function to run in an executor.
    This is where we transition from async to sync code.

    Parameters:
    - cb: The callback function to wrap.
    - executor_name: The name of the executor in the app.
    - include_request: Whether to pass the original request object to the callback.
    - update_json_with_launchdarkly: Whether to update the json with launchdarkly flags.
    - wrap_response: Whether to wrap the return value in the web.Response body.
    """
    if cb is None:
        # When called with arguments (e.g., @requests_async_event_loop(...)), cb is set to None. Since the function doesn't yet have a callable to decorate,
        # it returns a partial function with the provided arguments. This part func acts as the actual decorator that will receive the cb function later.
        return functools.partial(
            requests_async_event_loop,
            executor_name=executor_name,
            include_request=include_request,
            update_json_with_launchdarkly=update_json_with_launchdarkly,
            wrap_response=wrap_response,
        )

    @functools.wraps(cb)
    async def return_func(*args, **kwargs):
        request = args[-1]
        loop = asyncio.get_event_loop()
        executor = request.app[executor_name]

        try:
            request_json = await request.json()
        except Exception:
            request_json = None

        if request_json and update_json_with_launchdarkly:
            launchdarkly_context_str = request.headers.get(LD_CONTEXT_KEY, "{}")
            launchdarkly_context = json.loads(launchdarkly_context_str)
            request_json = update_request_json_with_launchdarkly_flags(
                request_json, launchdarkly_context=launchdarkly_context
            )

        if len(args) == 1:
            if include_request:
                wrapped_function = functools.partial(
                    cb, request, request_json, **kwargs
                )
            else:
                wrapped_function = functools.partial(cb, request_json, **kwargs)
        else:
            if include_request:
                wrapped_function = functools.partial(
                    cb, args[0], request, request_json, **kwargs
                )
            else:
                wrapped_function = functools.partial(
                    cb, args[0], request_json, **kwargs
                )
        out = await loop.run_in_executor(
            executor, get_request_context(), wrapped_function
        )
        if wrap_response:
            return web.Response(body=out.content)
        return out

    return return_func


def multipart_async_event_loop(cb=None, *, wrap_response=False):
    """Decorator for handling CSV file uploads

    This decorator wraps a request handler function to run in an executor,
    handling both multipart/form-data and direct CSV content uploads.

    Parameters:
    - cb: The callback function to wrap
    - wrap_response: Whether to wrap the return value in web.Response body
    """
    if cb is None:
        return functools.partial(
            multipart_async_event_loop, wrap_response=wrap_response
        )

    @functools.wraps(cb)
    async def return_func(self, request: Request):
        loop = asyncio.get_event_loop()
        executor = request.app["executor"]

        try:
            content_type = request.headers.get("Content-Type", "")
            if "multipart/form-data" not in content_type:
                return web.Response(status=400, text="Must be multipart")

            reader = await request.multipart()
            form_data: Dict[str, Any] = {}

            # Type annotation to help mypy understand the field type
            field: Optional[BodyPartReader] = await reader.next()  # type: ignore
            while field is not None:
                name = field.name
                if name is None:
                    continue

                if name == "file":
                    form_data["file"] = await field.read()
                else:
                    form_data[name] = await field.text()
                field = await reader.next()  # type: ignore

            wrapped_function = functools.partial(cb, self, request, form_data)
            response = await loop.run_in_executor(
                executor, get_request_context(), wrapped_function
            )

            if wrap_response:
                return web.Response(body=response.content)
            else:
                return response

        except Exception:
            return web.json_response({"error": "Failed to process request"}, status=500)

    return return_func


async def fetch_text_from_url(session, url, headers=None):
    async with session.get(url, headers=headers) as resp:
        return await resp.text()


async def get_json_session(request):
    request_json = update_request_json_with_launchdarkly_flags(await request.json())
    session = request.app["session"]
    return request_json, session


def create_session(limit=500):
    connector = TCPConnector(
        loop=asyncio.get_event_loop(), limit=limit, keepalive_timeout=3600
    )
    return aiohttp.ClientSession(connector=connector)
