import logging
import os
from typing import Optional

from ydc_services.global_utils.databricks.constants import (
    API_KEY_NAME_MAP,
    DEFAULT_API_KEY_NAME,
    DEFAULT_REGION,
    HOST_MAP,
)

logger = logging.getLogger(__package__)


def init_region(region: Optional[str]) -> str:
    if region is None:
        logger.info("No region provided, loading from env var: REGION")
        region = os.getenv("REGION", DEFAULT_REGION)

    if region not in HOST_MAP:
        logger.warning(
            "Provided region not supported. Falling back to default region",
            provided_region=region,
            default_region=DEFAULT_REGION,
        )
        return DEFAULT_REGION
    return region


def init_api_key(api_key: Optional[str], region: str) -> str:
    assert region in API_KEY_NAME_MAP
    if api_key is not None:
        return api_key

    # if given key is none, we will load API keys based on the given region
    # if region is not available (for example on local), we fallback to the west region
    api_key_name = API_KEY_NAME_MAP.get(region, DEFAULT_API_KEY_NAME)
    logger.info(
        "Databricks client using api_key from env",
        api_key_name=api_key_name,
    )
    return os.getenv(api_key_name)


def init_principal_client_id(principal_client_id: Optional[str]) -> str:
    if principal_client_id is not None:
        return principal_client_id
    return os.getenv("DATABRICKS_PRINCIPAL_CLIENT_ID")


def init_principal_client_secret(principal_client_secret: Optional[str]) -> str:
    if principal_client_secret is not None:
        return principal_client_secret
    return os.getenv("DATABRICKS_PRINCIPAL_CLIENT_SECRET")
