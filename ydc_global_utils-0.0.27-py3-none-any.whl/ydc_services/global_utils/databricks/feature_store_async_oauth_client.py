import json
import os
from abc import ABC
from datetime import datetime, timedelta
from typing import Any, Optional, Tuple

import aiohttp
import pandas as pd
import requests
from retry import retry

from ydc_services.global_utils.databricks.constants import (
    DEFAULT_ENVIRONMENT,
    DEFAULT_SUFFIX,
    FS_ENDPOINT_SUFFIX_MAP,
    HOST_MAP_OAUTH,
    SUPPORTED_FS_ENDPOINTS_OAUTH,
    WORKSPACE_URL_MAP,
)
from ydc_services.global_utils.databricks.utils import (
    init_api_key,
    init_principal_client_id,
    init_principal_client_secret,
    init_region,
)

DEFAULT_API_KEY = os.environ.get("DATABRICKS_TOKEN", None)
DEFAULT_CONNECTION_TIMEOUT = 0.5
DEFAULT_READ_TIMEOUT = 0.5
KEEP_ALIVE_TIMEOUT_SEC = 60


class FeatureStoreOauthClientAsync(ABC):
    def __init__(
        self,
        artifact_name: str,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: Optional[str] = DEFAULT_API_KEY,
        region: Optional[str] = None,
        env: Optional[str] = None,
        principal_client_id: Optional[str] = None,
        principal_client_secret: Optional[str] = None,
        skip_token_refresh: bool = False,
    ) -> None:
        self.session = None  # Delayed creation of the session
        self.artifact_name = artifact_name
        self.connection_timeout = aiohttp.ClientTimeout(
            total=None, connect=connection_timeout, sock_read=read_timeout
        )
        self.region = init_region(region)
        self.workspace_url = self.get_workspace_url()
        self.api_key = init_api_key(api_key, self.region)
        self.env = env or os.getenv("ENV", DEFAULT_ENVIRONMENT)
        self.endpoint_id = self.get_endpoint_prefix().split(".")[0].split("//")[1]
        self.principal_client_id = init_principal_client_id(principal_client_id)
        self.principal_client_secret = init_principal_client_secret(
            principal_client_secret
        )
        self.skip_token_refresh = skip_token_refresh
        if not skip_token_refresh:
            self.oauth, self.expiration = self.get_oauth_token()

    async def get_session(self):
        if not self.session:
            self.conn = aiohttp.TCPConnector(keepalive_timeout=KEEP_ALIVE_TIMEOUT_SEC)
            self.session = aiohttp.ClientSession(
                timeout=self.connection_timeout, connector=self.conn
            )
        return self.session

    async def lookup(self, df: pd.DataFrame, oauth_token: Optional[str] = None) -> list[dict[Any, Any]]:
        data_json = {"dataframe_split": df.to_dict(orient="split", index=False)}
        session = (
            await self.get_session()
        )  # Ensure session is created in the same event loop
        self.check_token_expiration(oauth_token)
        async with session.post(
            url=self.get_url(),
            headers=self.get_headers(),
            data=json.dumps(data_json),
        ) as response:
            response.raise_for_status()
            outputs = await response.json()
            return outputs["outputs"]

    def get_url(self):
        if self.env == "prod":
            return f"{self.workspace_url}serving-endpoints/{self.artifact_name}/invocations"
        if self.env == "local":
            return f"{self.workspace_url}serving-endpoints/{self.artifact_name}-staging/invocations"
        return f"{self.workspace_url}serving-endpoints/{self.artifact_name}-{self.env}/invocations"

    def get_artifact_name(self):
        return self.artifact_name

    async def close_session(self):
        if self.session:
            await self.session.close()
            self.session = None

    def get_endpoint_prefix(self):
        return HOST_MAP_OAUTH[self.env][self.region][self.artifact_name]

    def get_workspace_url(self):
        return WORKSPACE_URL_MAP[self.region]

    def get_env_suffix(self):
        return (
            FS_ENDPOINT_SUFFIX_MAP[self.env]
            if self.env in FS_ENDPOINT_SUFFIX_MAP
            else DEFAULT_SUFFIX
        )

    def get_headers(self):
        return {
            "Authorization": f"Bearer {self.oauth}",
            "Content-Type": "application/json",
        }

    def check_token_expiration(self, oauth_token: Optional[str] = None):
        """
        This function is used to check if the oauth token has expired and if it has, refreshes the token
        """
        if oauth_token:
            self.oauth, self.expiration = oauth_token, datetime.now() + timedelta(minutes=55)
            return
        if datetime.now() > self.expiration and not self.skip_token_refresh:
            self.oauth, self.expiration = self.get_oauth_token(timedelta=timedelta(minutes=55))

    @retry(tries=3)
    def get_oauth_token(
        self, token_lifetime: timedelta = timedelta(minutes=55)
    ) -> Tuple[str, datetime]:
        """
        This function is used to get the oauth token and returns the token as a string and the expiration datetime
        """
        # Make the request to get the access token
        response = requests.post(
            url=f"{self.workspace_url}/oidc/v1/token",
            auth=(self.principal_client_id, self.principal_client_secret),
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "scope": "all-apis",
                "authorization_details": json.dumps(
                    [
                        {
                            "type": "workspace_permission",
                            "object_type": "serving-endpoints",
                            "object_path": f"/serving-endpoints/{self.endpoint_id}",
                            "actions": ["query_inference_endpoint"],
                        }
                    ]
                ),
            },
        )
        if response.status_code != 200:
            raise Exception(
                f"Failed to get oauth token for {self.artifact_name} {self.workspace_url} {self.endpoint_id} {response.status_code} {response.text}"
            )
        token, expiration = (
            response.json().get("access_token"),
            datetime.now() + token_lifetime,
        )
        if token is None:
            raise Exception(
                f"Failed to get oauth token for {self.artifact_name} {self.workspace_url} {self.endpoint_id}"
            )
        return token, expiration


def get_client(
    endpoint: str,
    connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
    read_timeout: float = DEFAULT_READ_TIMEOUT,
    api_key: Optional[str] = DEFAULT_API_KEY,
    region: Optional[str] = None,
    env: Optional[str] = None,
    skip_token_refresh: bool = False,
) -> FeatureStoreOauthClientAsync:
    if endpoint in SUPPORTED_FS_ENDPOINTS_OAUTH:
        return FeatureStoreOauthClientAsync(
            artifact_name=endpoint,
            read_timeout=read_timeout,
            connection_timeout=connection_timeout,
            api_key=api_key,
            region=region,
            env=env,
            skip_token_refresh=skip_token_refresh,
        )
    else:
        raise Exception(
            f"Endpoint not supported. Supported endpoints are {SUPPORTED_FS_ENDPOINTS_OAUTH}"
        )
