import json
import os
from abc import ABC
from typing import Any, Dict, List, Optional

import aiohttp
import pandas as pd

from ydc_services.global_utils.databricks.constants import (
    DEFAULT_ENVIRONMENT,
    DEFAULT_SUFFIX,
    FS_ENDPOINT_SUFFIX_MAP,
    HOST_MAP,
    SUPPORTED_FS_ENDPOINTS,
)
from ydc_services.global_utils.databricks.utils import init_api_key, init_region

DEFAULT_API_KEY = os.environ.get("DATABRICKS_TOKEN", None)
DEFAULT_CONNECTION_TIMEOUT = 0.5
DEFAULT_READ_TIMEOUT = 0.5
KEEP_ALIVE_TIMEOUT_SEC = 60


class FeatureStoreClientAsync(ABC):
    def __init__(
        self,
        artifact_name: str,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: Optional[str] = DEFAULT_API_KEY,
        region: Optional[str] = None,
        env: Optional[str] = None,
    ) -> None:
        self.session = None  # Delayed creation of the session
        self.artifact_name = artifact_name
        self.connection_timeout = aiohttp.ClientTimeout(
            total=None, connect=connection_timeout, sock_read=read_timeout
        )
        self.region = init_region(region)
        self.api_key = init_api_key(api_key, self.region)
        self.env = env or os.getenv("ENV", DEFAULT_ENVIRONMENT)

    async def get_session(self):
        if not self.session:
            self.conn = aiohttp.TCPConnector(keepalive_timeout=KEEP_ALIVE_TIMEOUT_SEC)
            self.session = aiohttp.ClientSession(
                timeout=self.connection_timeout, connector=self.conn
            )
        return self.session

    async def lookup(self, dataset: pd.DataFrame, oauth_token: Optional[str] = None) -> List[Dict[Any, Any]]:
        ds_dict = {"dataframe_split": dataset.to_dict(orient="split")}
        data_json = json.dumps(ds_dict, allow_nan=True)
        session = (
            await self.get_session()
        )  # Ensure session is created in the same event loop
        async with session.post(
            url=self.get_url(),
            headers=self.get_headers(),
            data=data_json,
        ) as response:
            response.raise_for_status()
            outputs = await response.json()
            return outputs["outputs"]

    def get_url(self):
        return f"{self.get_host()}/{self.get_artifact_name()}{self.get_env_suffix()}/invocations"

    def get_artifact_name(self):
        return self.artifact_name

    async def close_session(self):
        if self.session:
            await self.session.close()
            self.session = None

    def get_host(self):
        return HOST_MAP[self.region]

    def get_env_suffix(self):
        return (
            FS_ENDPOINT_SUFFIX_MAP[self.env]
            if self.env in FS_ENDPOINT_SUFFIX_MAP
            else DEFAULT_SUFFIX
        )

    def get_headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }


def get_client(
    endpoint: str,
    connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
    read_timeout: float = DEFAULT_READ_TIMEOUT,
    api_key: Optional[str] = DEFAULT_API_KEY,
    region: Optional[str] = None,
    env: Optional[str] = None,
) -> FeatureStoreClientAsync:
    if endpoint in SUPPORTED_FS_ENDPOINTS:
        return FeatureStoreClientAsync(
            artifact_name=endpoint,
            read_timeout=read_timeout,
            connection_timeout=connection_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )
    else:
        raise Exception(
            f"Endpoint not supported. Supported endpoints are {SUPPORTED_FS_ENDPOINTS}"
        )
