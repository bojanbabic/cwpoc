import json
import os
from abc import ABC
from typing import Any, Dict, List

import aiohttp
import pandas as pd

from ydc_services.global_utils.databricks.constants import (
    CROSS_ENCODER,
    DDG_LTR,
    DEFAULT_ENVIRONMENT,
    DEFAULT_SUFFIX,
    ENDPOINT_SUFFIX_MAP,
    FLAIR_GERMAN_NER,
    HOST_MAP,
    IP_L0_CLASSIFIER,
    IP_L1_CLASSIFIER,
    LLM_QWEN2,
    NER,
    PQC_QWEN_FT,
    QU_ANNOTATION,
    QU_SPLADE,
    SUPPORTED_ENDPOINTS,
    TEXT_EMBEDDINGS,
    YDC_IP_L1_CLASSIFIER,
)
from ydc_services.global_utils.databricks.utils import init_api_key, init_region

DEFAULT_API_KEY = os.environ.get("DATABRICKS_TOKEN", None)
DEFAULT_CONNECTION_TIMEOUT = 0.5
DEFAULT_READ_TIMEOUT = 0.5
KEEP_ALIVE_TIMEOUT_SEC = 60


class BaseClientAsync(ABC):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        self.session = None  # Delayed creation of the session
        self.connection_timeout = aiohttp.ClientTimeout(
            total=None, connect=connection_timeout, sock_read=read_timeout
        )
        self.region = init_region(region)
        self.api_key = init_api_key(api_key, self.region)
        self.env = env or os.getenv("ENV", DEFAULT_ENVIRONMENT)

    async def get_session(self):
        if not self.session:
            self.conn = aiohttp.TCPConnector(keepalive_timeout=KEEP_ALIVE_TIMEOUT_SEC)
            self.session = aiohttp.ClientSession(
                timeout=self.connection_timeout, connector=self.conn
            )
        return self.session

    async def predict(self, dataset: pd.DataFrame) -> List[Dict[Any, Any]]:
        ds_dict = {"dataframe_split": dataset.to_dict(orient="split")}
        data_json = json.dumps(ds_dict, allow_nan=True)
        session = (
            await self.get_session()
        )  # Ensure session is created in the same event loop
        async with session.post(
            url=self.get_url(),
            headers=self.get_headers(),
            data=data_json,
        ) as response:
            response.raise_for_status()
            predictions = await response.json()
            return predictions["predictions"]

    def get_url(self):
        return f"{self.get_host()}/{self.get_artifact_name()}{self.get_env_suffix()}/invocations"

    def get_artifact_name(self):
        raise NotImplementedError()

    async def close_session(self):
        if self.session:
            await self.session.close()
            self.session = None

    def get_host(self):
        return HOST_MAP[self.region]

    def get_env_suffix(self):
        return (
            ENDPOINT_SUFFIX_MAP[self.env]
            if self.env in ENDPOINT_SUFFIX_MAP
            else DEFAULT_SUFFIX
        )

    def get_headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }


class IntentPredictionClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return IP_L1_CLASSIFIER


class L0IntentPredictionClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return IP_L0_CLASSIFIER


class NerClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return NER


class FlairNerClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return FLAIR_GERMAN_NER


class TextEmbeddingsClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return TEXT_EMBEDDINGS


class CrossEncoderClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return CROSS_ENCODER


class SpladeQuClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return QU_SPLADE


class QuAnnotationClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return QU_ANNOTATION


class Qwen2LLMClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return LLM_QWEN2


class PQCQwenFTClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return PQC_QWEN_FT


class DDGLTRClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return DDG_LTR


class YDCIntentPredictionClientAsync(BaseClientAsync):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return YDC_IP_L1_CLASSIFIER


def get_client(
    endpoint: str,
    connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
    read_timeout: float = DEFAULT_READ_TIMEOUT,
    api_key: str = DEFAULT_API_KEY,
    region: str = None,
    env: str = None,
) -> BaseClientAsync:
    if endpoint == IP_L1_CLASSIFIER:
        return IntentPredictionClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == IP_L0_CLASSIFIER:
        return L0IntentPredictionClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == NER:
        return NerClientAsync(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == FLAIR_GERMAN_NER:
        return FlairNerClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == TEXT_EMBEDDINGS:
        return TextEmbeddingsClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == CROSS_ENCODER:
        return CrossEncoderClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == QU_SPLADE:
        return SpladeQuClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == QU_ANNOTATION:
        return QuAnnotationClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == LLM_QWEN2:
        return Qwen2LLMClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == PQC_QWEN_FT:
        return PQCQwenFTClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == DDG_LTR:
        return DDGLTRClientAsync(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == YDC_IP_L1_CLASSIFIER:
        return YDCIntentPredictionClientAsync(
            read_timeout, connection_timeout, api_key, region, env
        )
    else:
        raise Exception(
            f"Endpoint not supported. Supported endpoints are {SUPPORTED_ENDPOINTS}"
        )
