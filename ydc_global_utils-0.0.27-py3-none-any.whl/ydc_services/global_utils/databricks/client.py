import json
import os
from abc import ABC
from typing import Any, Dict, List, Union

import httpx
import pandas as pd

from ydc_services.global_utils.databricks.constants import (
    CROSS_ENCODER,
    DDG_LTR,
    DEFAULT_ENVIRONMENT,
    DEFAULT_SUFFIX,
    ENDPOINT_SUFFIX_MAP,
    FLAIR_GERMAN_NER,
    HOST_MAP,
    IP_L0_CLASSIFIER,
    IP_L1_CLASSIFIER,
    LLM_QWEN2,
    NER,
    PQC_QWEN_FT,
    QU_ANNOTATION,
    QU_SPLADE,
    SUPPORTED_ENDPOINTS,
    TEXT_EMBEDDINGS,
    YDC_IP_L1_CLASSIFIER,
)
from ydc_services.global_utils.databricks.utils import (
    init_api_key,
    init_region,
)

DEFAULT_API_KEY = os.environ.get("DATABRICKS_TOKEN", None)
DEFAULT_CONNECTION_TIMEOUT = 0.5
DEFAULT_READ_TIMEOUT = 0.5
DEFAULT_KEEPALIVE_EXPIRY = 60


class BaseClient(ABC):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        self.session = httpx.Client(
            limits=httpx.Limits(keepalive_expiry=DEFAULT_KEEPALIVE_EXPIRY)
        )
        self.connection_timeout = connection_timeout
        self.read_timeout = read_timeout
        self.region = init_region(region)
        self.api_key = init_api_key(api_key, self.region)
        self.env = env or os.getenv("ENV", DEFAULT_ENVIRONMENT)

    def predict(self, dataset: Union[pd.DataFrame, dict]) -> List[Dict[Any, Any]]:
        ds_dict = dataset
        if isinstance(dataset, pd.DataFrame):
            ds_dict = {"dataframe_split": dataset.to_dict(orient="split")}

        data_json = json.dumps(ds_dict, allow_nan=True)
        response = self.session.request(
            method="POST",
            headers=self.get_headers(),
            url=self.get_url(),
            data=data_json,
            timeout=(self.connection_timeout, self.read_timeout),
        )
        response.raise_for_status()
        predictions = response.json()["predictions"]
        return predictions

    def get_url(self):
        return f"{self.get_host()}/{self.get_artifact_name()}{self.get_env_suffix()}/invocations"

    def get_artifact_name(self):
        raise NotImplementedError()

    def get_host(self):
        return HOST_MAP[self.region]

    def get_env_suffix(self):
        return (
            ENDPOINT_SUFFIX_MAP[self.env]
            if self.env in ENDPOINT_SUFFIX_MAP
            else DEFAULT_SUFFIX
        )

    def get_headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }


class IntentPredictionClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return IP_L1_CLASSIFIER


class L0IntentPredictionClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return IP_L0_CLASSIFIER


class NerClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return NER


class FlairNerClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return FLAIR_GERMAN_NER


class TextEmbeddingsClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return TEXT_EMBEDDINGS


class CrossEncoderClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return CROSS_ENCODER


class SpladeQuClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return QU_SPLADE


class QuAnnotationClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return QU_ANNOTATION


class Qwen2LLMClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return LLM_QWEN2


class PQCQwenFTClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return PQC_QWEN_FT


class DDGLTRClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return DDG_LTR


class YDCIntentPredictionClient(BaseClient):
    def __init__(
        self,
        read_timeout: float = DEFAULT_READ_TIMEOUT,
        connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
        api_key: str = DEFAULT_API_KEY,
        region: str = None,
        env: str = None,
    ) -> None:
        super().__init__(
            connection_timeout=connection_timeout,
            read_timeout=read_timeout,
            api_key=api_key,
            region=region,
            env=env,
        )

    def get_artifact_name(self):
        return YDC_IP_L1_CLASSIFIER


def get_client(
    endpoint: str,
    connection_timeout: float = DEFAULT_CONNECTION_TIMEOUT,
    read_timeout: float = DEFAULT_READ_TIMEOUT,
    api_key: str = DEFAULT_API_KEY,
    region: str = None,
    env: str = None,
) -> BaseClient:
    if endpoint == IP_L1_CLASSIFIER:
        return IntentPredictionClient(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == NER:
        return NerClient(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == FLAIR_GERMAN_NER:
        return FlairNerClient(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == TEXT_EMBEDDINGS:
        return TextEmbeddingsClient(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == CROSS_ENCODER:
        return CrossEncoderClient(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == QU_SPLADE:
        return SpladeQuClient(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == QU_ANNOTATION:
        return QuAnnotationClient(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == LLM_QWEN2:
        return Qwen2LLMClient(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == IP_L0_CLASSIFIER:
        return L0IntentPredictionClient(
            read_timeout, connection_timeout, api_key, region, env
        )
    elif endpoint == PQC_QWEN_FT:
        return PQCQwenFTClient(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == DDG_LTR:
        return DDGLTRClient(read_timeout, connection_timeout, api_key, region, env)
    elif endpoint == YDC_IP_L1_CLASSIFIER:
        return YDCIntentPredictionClient(
            read_timeout, connection_timeout, api_key, region, env
        )
    else:
        raise Exception(
            f"Endpoint not supported. Supported endpoints are {SUPPORTED_ENDPOINTS}"
        )
