import logging
import threading
from collections import Counter
from typing import Any, Callable, Dict, Iterator, List, Optional, TypeVar, Union

from ydc_services.global_utils.aiohttp.middlewares_and_headers import (
    RequestContext,
    request_context_var,
    update_request_context_var,
)
from ydc_services.global_utils.instrument.cost_data import CostData

logger = logging.getLogger(__package__)

T = TypeVar("T")


class CostTracker:
    # NOTE: We use a global lock to ensure thread safety when updating metrics.
    # This approach is chosen over accumulating events because accumulating a large number of events (e.g., 100k events) could significantly increase memory usage (~1MB).
    # https://gist.github.com/thsunkid/38ece1fd45cc99d676d22788d7f66c92?permalink_comment_id=5218319#gistcomment-5218319
    # While both approaches are thread-safe (threading.lock ensures that only one thread can update the metrics at a time, preventing race conditions and ensuring data consistency - List.append by default is thread-safe),
    # updating the cost data on-the-fly using a class-level global lock uses less memory and does not add much latency in practice (partially due to GIL, and also because we only do some simple arithmetic).
    # Moreover, the lock mechanism is simple and more explicit for our use case, where the latency introduced by the lock is minimal and acceptable.
    # That said, we want to reevaluate this if we see any performance issues.
    #
    # Context of the discussion: https://youdotcom.slack.com/archives/C07QFQLPV97/p1727903954480789
    # TPRD: https://www.notion.so/youdotcom/An-interesting-case-for-contextvars-in-python-113ed842b58b80e28f09ef3e9328fff3
    _lock = threading.Lock()

    @classmethod
    def init_and_set_cost_data(cls):
        cost_data = CostData()
        update_request_context_var(RequestContext(cost_data=cost_data))

    @classmethod
    def _get_cost_data(cls) -> Optional[CostData]:
        # NOTE: _get_cost_data must always be called within cls._lock
        return request_context_var.get().cost_data

    @classmethod
    def _init_model_name(cls, model_name: str, cost_data: CostData):
        if model_name not in cost_data.model_counts:
            cost_data.model_counts[model_name] = Counter(
                {
                    "num_cached_input_tokens": 0,
                    "num_input_tokens": 0,
                    "num_input_words": 0,
                    "num_input_chars": 0,
                    "num_output_tokens": 0,
                    "num_input_images": 0,
                    "num_output_images": 0,
                }
            )

    @classmethod
    def _init_filename_extension(cls, filename_extension: str, cost_data: CostData):
        if filename_extension not in cost_data.file_counts:
            cost_data.file_counts[filename_extension] = Counter(
                {
                    "num_input_tokens": 0,
                    "num_input_words": 0,
                    "num_input_chars": 0,
                }
            )

    @classmethod
    def get_metrics(cls):
        cost_data = cls._get_cost_data()
        return cost_data.model_dump() if cost_data else {}

    @classmethod
    def update_metrics(cls, metrics: Dict):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            for cost_data_var, cost_data_val in metrics.items():
                assert hasattr(
                    cost_data, cost_data_var
                ), f"CostData variable {cost_data_var} not found"
                cost_data_var_value = getattr(cost_data, cost_data_var)
                for service_name, service_data in cost_data_val.items():
                    if isinstance(service_data, dict):
                        curr_counter = cost_data_var_value.get(service_name, Counter())
                        curr_counter.update(service_data)
                        cost_data_var_value[service_name] = curr_counter
                    elif isinstance(service_data, bool):
                        cost_data_var_value[service_name] = service_data
                    else:
                        raise ValueError(
                            f"Unexpected service data type: {type(service_data)}"
                        )

    @classmethod
    def increment_input_count(
        cls,
        model_name: str,
        prompt_or_messages: Union[str, List[Dict[str, str | List]]],
        num_cached_input_tokens: int = 0,
        num_input_tokens: Optional[int] = None,
        get_token_count: Optional[Callable[[str], int]] = None,
    ):
        if isinstance(prompt_or_messages, str):
            est_num_input_tokens = num_input_tokens or 0
            if get_token_count:
                est_num_input_tokens = get_token_count(prompt_or_messages)
            num_input_words = len(prompt_or_messages.split())
            num_input_chars = len(prompt_or_messages)
        elif isinstance(prompt_or_messages, list):
            est_num_input_tokens = num_input_tokens or 0
            num_input_words = 0
            num_input_chars = 0
            for message in prompt_or_messages:
                prompt_content = message["content"]
                if isinstance(prompt_content, list):
                    prompt = ""
                    for prompt_dict in prompt_content:
                        if "text" in prompt_dict:
                            text = prompt_dict["text"] + " "
                            prompt += text
                else:
                    prompt = prompt_content

                if get_token_count:
                    est_num_input_tokens += get_token_count(prompt)
                num_input_words += len(prompt.split())
                num_input_chars += len(prompt)

        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            cls._init_model_name(model_name, cost_data)
            cost_data.model_counts[model_name][
                "num_cached_input_tokens"
            ] += num_cached_input_tokens
            cost_data.model_counts[model_name]["num_input_tokens"] += (
                num_input_tokens or est_num_input_tokens
            )
            cost_data.model_counts[model_name]["num_input_words"] += num_input_words
            cost_data.model_counts[model_name]["num_input_chars"] += num_input_chars

    @classmethod
    def increment_output_token_count(cls, model_name: str, num_output_tokens: int = 1):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            cls._init_model_name(model_name, cost_data)
            cost_data.model_counts[model_name]["num_output_tokens"] += num_output_tokens

    @classmethod
    def wrap_with_increment_event(
        cls, generator: Iterator[T], model_name: str
    ) -> Iterator[T]:
        count = 0
        for value in generator:
            count += 1
            yield value
        cls.increment_output_token_count(model_name, num_output_tokens=count)

    @classmethod
    def increment_file_count(
        cls, filename_extension: Optional[str], text: str, num_input_tokens: int
    ):
        if not filename_extension:
            return
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            cls._init_filename_extension(filename_extension, cost_data)
            file_counter = cost_data.file_counts[filename_extension]
            file_counter["num_input_tokens"] += num_input_tokens
            file_counter["num_input_words"] += len(text.split())
            file_counter["num_input_chars"] += len(text)

    @classmethod
    def increment_input_image_count(cls, model_name: str, num_images: int = 1):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            cls._init_model_name(model_name, cost_data)
            cost_data.model_counts[model_name]["num_input_images"] += num_images

    @classmethod
    def increment_output_image_count(cls, model_name: str, num_images: int = 1):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            cls._init_model_name(model_name, cost_data)
            cost_data.model_counts[model_name]["num_output_images"] += num_images

    @classmethod
    def increment_web_search_calls_count(cls, provider: str, count: int = 1):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            if provider in cost_data.web_search_calls:
                cost_data.web_search_calls[provider]["num_calls"] += count
            else:
                cost_data.web_search_calls[provider] = Counter({"num_calls": count})

    @classmethod
    def increment_web_scrape_calls_count(cls, provider: str, num_calls: int = 1):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            if provider in cost_data.web_scrape_calls:
                cost_data.web_scrape_calls[provider]["num_calls"] += num_calls
            else:
                cost_data.web_scrape_calls[provider] = Counter({"num_calls": num_calls})

    @classmethod
    def set_request_metadata(cls, key: str, value: Any):
        with cls._lock:
            cost_data = cls._get_cost_data()
            if cost_data is None:
                return
            cost_data.request_metadata[key] = value

    @classmethod
    def record_metrics(
        cls,
        request_json,
        chat_mode: str,
        record_event_fn: Callable[[str, Dict, Dict], None],
        additional_metadata: Optional[Dict] = None,
    ):
        cost_data = cls._get_cost_data()
        if cost_data is None:
            return

        web_search_calls_str = (
            "web search calls: " if cost_data.web_search_calls else ""
        )
        for provider, info in cost_data.web_search_calls.items():
            num_calls = info["num_calls"]
            web_search_calls_str += f"provider: {provider}, calls: {num_calls} | "

        if cost_data.web_scrape_calls:
            web_scrape_calls_str = "web scrape calls: "
        else:
            web_scrape_calls_str = ""

        for provider, info in cost_data.web_scrape_calls.items():
            num_calls = info["num_calls"]
            web_scrape_calls_str += f"provider: {provider}, calls: {num_calls} | "

        model_counts_str = ""
        for model_name, counts_dict in cost_data.model_counts.items():
            num_cached_input_tokens = counts_dict["num_cached_input_tokens"]
            num_input_tokens = counts_dict["num_input_tokens"]
            num_input_words = counts_dict["num_input_words"]
            num_input_chars = counts_dict["num_input_chars"]
            num_output_tokens = counts_dict["num_output_tokens"]
            num_input_images = counts_dict["num_input_images"]
            num_output_images = counts_dict["num_output_images"]

            model_counts_str += (
                f"model name: {model_name}, cached input tokens: {num_cached_input_tokens}, input tokens: {num_input_tokens}, "
                f"input words: {num_input_words}, input chars: {num_input_chars}, "
                f"output tokens: {num_output_tokens}, input images: {num_input_images}, "
                f"output images: {num_output_images} | "
            )

        logger.info(
            "Cost tracker",
            chat_mode=chat_mode,
            web_search_calls=web_search_calls_str,
            web_scrape_calls=web_scrape_calls_str,
            model_counts=model_counts_str,
        )

        event_data = {
            "llm_model_info": cost_data.model_counts,
            "web_search_info": cost_data.web_search_calls,
            "web_scrape_info": cost_data.web_scrape_calls,
            "file_info": cost_data.file_counts,
            "request_metadata": cost_data.request_metadata,
            **(additional_metadata or {}),
        }

        record_event_fn("cost_tracker", request_json, event_data)
