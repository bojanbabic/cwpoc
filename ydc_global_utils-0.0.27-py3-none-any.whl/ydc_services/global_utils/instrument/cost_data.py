from collections import Counter
from typing import Any, Dict

from pydantic import BaseModel


class CostData(BaseModel):
    model_counts: Dict[str, Counter] = {}
    web_search_calls: Dict[str, Counter] = {}
    web_scrape_calls: Dict[str, Counter] = {}
    file_counts: Dict[str, Counter] = {}
    request_metadata: Dict[str, Any] = {}

    class Config:
        protected_namespaces = ()
