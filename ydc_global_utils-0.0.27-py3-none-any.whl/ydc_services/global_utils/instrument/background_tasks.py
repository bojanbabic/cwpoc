import asyncio
import logging
import threading
import time
from collections import Counter

from aiohttp import web

from ydc_services.global_utils.instrument.new_relic import record_newrelic

logger = logging.getLogger(__package__)


async def log_thread_and_event_loop_stats(interval: float = 5):
    loop = asyncio.get_event_loop()
    while True:
        try:
            thread_breakdown = Counter(
                [thread.name for thread in threading.enumerate()]
            ).most_common()
            num_threads = threading.active_count()
            logger.info(
                "Active thread count",
                num_threads=num_threads,
                thread_breakdown=thread_breakdown,
                extra={"handler_name": "sumo"},
            )
            record_newrelic("active_thread_count", num_threads)

            # We use the lag between actual time after sleeping vs expected time
            # after sleeping to detect load on main event loop.
            # https://blog.meadsteve.dev/programming/2020/02/23/monitoring-async-python/
            last_sleep_time = time.time()
            await asyncio.sleep(interval)
            lag = time.time() - last_sleep_time - interval

            event_loop_tasks = asyncio.all_tasks(loop)
            # Run this if we are interested in the exact coroutines
            # for task in event_loop_tasks:
            #     logger.info("coroutine", task_name=task.get_name(), task_coro=task.get_coro())
            logger.info(
                "Event loop lag",
                lag=f"{lag:.5f}s",
                num_tasks=len(event_loop_tasks),
                extra={"handler_name": "sumo"},
            )
            record_newrelic("event_loop_lag", lag)
            record_newrelic("event_loop_num_tasks", len(event_loop_tasks))
        except Exception:
            logger.error("log_thread_and_event_loop_stats error", exc_info=True)


async def thread_and_event_loop_monitor(app: web.Application):
    app["thread_and_event_loop_monitor"] = asyncio.create_task(
        log_thread_and_event_loop_stats()
    )
    yield
    app["thread_and_event_loop_monitor"].cancel()
    await app["thread_and_event_loop_monitor"]


def add_background_tasks(app: web.Application):
    # Background tasks: https://docs.aiohttp.org/en/stable/web_advanced.html#background-tasks
    app.cleanup_ctx.append(thread_and_event_loop_monitor)
