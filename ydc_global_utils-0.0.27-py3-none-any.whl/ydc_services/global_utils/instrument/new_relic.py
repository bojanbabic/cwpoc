import functools
import inspect
import logging
import os
import time
from contextlib import (
    AsyncContextDecorator,
    ContextDecorator,
)
from typing import Any, Awaitable, Callable, Optional, ParamSpec, TypeVar

import newrelic.agent

LOGGER = logging.getLogger(__package__)

application = newrelic.agent.application()

T = TypeVar("T")
P = ParamSpec("P")


def make_newrelic_instrumentation(
    metric_name,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def instrumentation_factory(cb: Callable[P, T]) -> Callable[P, T]:
        @functools.wraps(cb)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            start = time.time()
            record_newrelic(f"{metric_name}calls", 1)
            out = cb(*args, **kwargs)
            record_newrelic(f"{metric_name}success", 1)
            record_newrelic(f"{metric_name}time", time.time() - start)
            return out

        # The solution online to type function decorators is to use functools.wrap,
        # however it does not lead to proper typing for functions in a class.
        # Using a TypeVar works but violates the typing so we ignore here.
        return wrapper  # type: ignore

    return instrumentation_factory


def make_scoped_newrelic_instrumentation(
    metric_name,
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def instrumentation_factory(cb: Callable[P, T]) -> Callable[P, T]:
        @functools.wraps(cb)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            # Intentionally raise errors if `newrelic_logging_scope` does not exist
            assert args, f"args must exist: {args}"
            assert hasattr(args[0], "newrelic_logging_scope")
            logging_scope_var = args[0].newrelic_logging_scope
            if not logging_scope_var or not isinstance(logging_scope_var, str):
                raise ValueError(
                    f"newrelic_logging_scope must be present and of type string for "
                    f"function {cb.__name__} but is: {logging_scope_var}"
                )
            logging_scope = f"{logging_scope_var}/"

            start = time.time()
            record_newrelic(f"{logging_scope}{metric_name}calls", 1)
            out = cb(*args, **kwargs)
            record_newrelic(f"{logging_scope}{metric_name}success", 1)
            record_newrelic(f"{logging_scope}{metric_name}time", time.time() - start)
            return out

        return wrapper  # type: ignore

    return instrumentation_factory


def record_latency(metric_name) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def instrumentation_factory(cb: Callable[P, T]) -> Callable[P, T]:
        @functools.wraps(cb)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            start = time.time()
            out = cb(*args, **kwargs)
            record_newrelic(f"{metric_name}_time", time.time() - start)
            return out

        return wrapper  # type: ignore

    return instrumentation_factory


def record_newrelic(metric_name, metric_value):
    newrelic.agent.record_custom_metric(
        f'Custom/{os.environ.get("NEW_RELIC_EVENT_APP_NAME", "default")}/{os.environ.get("REGION", "none")}/{metric_name}',
        metric_value,
        application,
    )


def record_nr_custom_event(event_type: str, event_params: dict):
    # NOTE: We should not create too many event_type values, otherwise we will hit
    # the limit of unique events. Instead, try to use event_params to store the
    # different values.
    newrelic.agent.record_custom_event(
        event_type,
        event_params,
        application,
    )


def record_nr_and_log(
    metric_name, metric_value, is_error: bool = False, skip_logging: bool = False
):
    record_newrelic(metric_name, metric_value)

    if skip_logging:
        return

    if is_error:
        LOGGER.error(
            "%(metric_name)s: %(metric_value)s",
            metric_name=metric_name,
            metric_value=metric_value,
            exc_info=True,
            stacklevel=2,
        )
    else:
        LOGGER.info(
            "%(metric_name)s: %(metric_value)s",
            metric_name=metric_name,
            metric_value=metric_value,
            stacklevel=2,
        )


def emit_metric_for_search(search_type, metric_name, metric_value, domain=None):
    if domain:
        record_newrelic(f"{search_type}/{domain}/{metric_name}", metric_value)
    else:
        record_newrelic(f"{search_type}/{metric_name}", metric_value)


# Log with a special and easily search-able value to allow us to easily search Sumo logs
# for errors in areas where there is supposed to be none. When a surprising error has been
# identified, they should be stamped out to 0. Otherwise, this function should not be used.
def log_surprising_error(error: str):
    LOGGER.error(
        "[SURPRISING ERROR]: (error)s", error=error, exc_info=True, stacklevel=2
    )


class record(ContextDecorator, AsyncContextDecorator):
    """
    This class can be used for logging success/failure/latency metrics on both sync and
    async functions.
    """

    def __init__(
        self,
        metric_name: str,
        should_log_calls: bool = True,
        should_log_latency: bool = True,
        should_log_success: bool = True,
        should_log_error: bool = True,
        should_send_newrelic: bool = True,
        should_send_sumo: bool = True,
        high_latency_threshold: Optional[float] = None,
        is_via_decorator: bool = False,
        logger: Optional[logging.LoggerAdapter | logging.Logger] = None,
        **log_vars,
    ):
        self.metric_name = metric_name
        self.should_log_calls = should_log_calls
        self.should_log_latency = should_log_latency
        self.should_log_success = should_log_success
        self.should_log_error = should_log_error
        self.should_send_newrelic = should_send_newrelic
        self.should_send_sumo = should_send_sumo
        self.high_latency_threshold = high_latency_threshold
        self.is_via_decorator = is_via_decorator
        self.logger = logger or LOGGER
        self.log_vars = log_vars
        self._start_time = None

    def _enter(self):
        self._start_time = time.time()
        if self.should_log_calls:
            if self.should_send_sumo:
                self.logger.info(
                    "%(metric_name)s called",
                    metric_name=self.metric_name,
                    log_vars=self.log_vars,
                    # We add stacklevel so that the metadata of the logs (e.g. function, filename)
                    # are associated with a few stacks higher instead of the current new_relic file.
                    # and _enter function.
                    stacklevel=3,
                )
            if self.should_send_newrelic:
                record_newrelic(f"{self.metric_name}_called", 1)

        # If we do `with record(...) as x:`, then the return value here becomes `x`
        return self

    def _exit(self, exc_type, exc, tb):
        has_failed = exc is not None

        time_taken = self.get_time_elapsed()
        _high_latency_text = (
            " (high latency)"
            if self.high_latency_threshold and time_taken > self.high_latency_threshold
            else ""
        )

        if self.should_log_latency:
            self.log_latency(
                status="failure" if has_failed else "success",
                # Not sending to Sumo since we will be logging latency via self.logger below
                should_send_sumo=False,
                high_latency_threshold=self.high_latency_threshold,
            )

        if has_failed:
            if self.should_log_error:
                if self.should_send_sumo:
                    self.logger.error(
                        f"%(metric_name)s error took %(time_taken).3fs{_high_latency_text}.",
                        metric_name=self.metric_name,
                        time_taken=time_taken,
                        log_vars=self.log_vars,
                        exc_info=True,
                        stacklevel=5 if self.is_via_decorator else 3,
                    )
                if self.should_send_newrelic:
                    record_newrelic(f"{self.metric_name}_failure", 1)
        else:
            if self.should_log_success:
                if self.should_send_sumo:
                    self.logger.info(
                        f"%(metric_name)s success took %(time_taken).3fs{_high_latency_text}.",
                        metric_name=self.metric_name,
                        time_taken=time_taken,
                        log_vars=self.log_vars,
                        stacklevel=5 if self.is_via_decorator else 3,
                    )
                if self.should_send_newrelic:
                    record_newrelic(f"{self.metric_name}_success", 1)

    # Without the types Callable[P, T] -> Callable[P, T], mypy will not be able to typecheck
    # a decorated function.
    def __call__(self, func: Callable[P, T]) -> Callable[P, T]:  # type: ignore[override]
        filename = inspect.getfile(func)
        lines, start_line = inspect.getsourcelines(func)

        logger = logging.LoggerAdapter(
            self.logger,
            {
                "__filename": os.path.basename(filename),
                "__name": ".".join(func.__module__.split(".")[:-1]),
                "__funcName": func.__name__,
                "__lineno": start_line,
            },
        )

        @functools.wraps(func)
        def wrapped(*args: P.args, **kwargs: P.kwargs) -> T:
            # We cannot do `with self` because `_start_time` would be shared and a race
            # condition can occur.
            variables = {
                k: v
                for k, v in self.__dict__.items()
                if k not in ["_start_time", "logger", "is_via_decorator"]
            }
            with record(**variables, logger=logger, is_via_decorator=True):
                result = func(*args, **kwargs)
            return result

        @functools.wraps(func)
        async def awrapped(*args: P.args, **kwargs: P.kwargs) -> Awaitable[T]:
            variables = {
                k: v
                for k, v in self.__dict__.items()
                if k not in ["_start_time", "logger", "is_via_decorator"]
            }
            async with record(**variables, logger=logger, is_via_decorator=True):
                result = await func(*args, **kwargs)  # type: ignore[misc]
            return result

        return awrapped if inspect.iscoroutinefunction(func) else wrapped  # type: ignore[return-value]

    async def __aenter__(self):
        return self._enter()

    async def __aexit__(self, exc_type, exc, tb):
        self._exit(exc_type, exc, tb)

    def __enter__(self):
        return self._enter()

    def __exit__(self, exc_type, exc, tb):
        self._exit(exc_type, exc, tb)

    def log_info(self, log_name: str, log_value: Any):
        """Log information with the context block's metric name as prefix"""
        if self.should_send_sumo:
            self.logger.info(
                "%(metric_name)s/%(log_name)s",
                metric_name=self.metric_name,
                log_name=log_name,
                log_value=log_value,
                log_vars=self.log_vars,
                stacklevel=2,
            )

    def log_error(self, log_name: str, log_value: Any):
        """Log error with the context block's metric name as prefix"""
        if self.should_send_sumo:
            self.logger.error(
                "%(metric_name)s/%(log_name)s",
                metric_name=self.metric_name,
                log_name=log_name,
                log_value=log_value,
                log_vars=self.log_vars,
                stacklevel=2,
            )

    def log_metric(self, metric_name: str, metric_value: float | int):
        """Log metric with the context block's metric name as prefix"""
        if self.should_send_sumo:
            self.logger.info(
                "%(metric_name)s/%(log_name)s",
                metric_name=self.metric_name,
                log_name=metric_name,
                log_value=metric_value,
                log_vars=self.log_vars,
                stacklevel=2,
            )
        if self.should_send_newrelic:
            record_newrelic(f"{self.metric_name}/{metric_name}", metric_value)

    def log_latency(
        self,
        name: Optional[str] = None,
        value: Optional[float] = None,
        status: Optional[str] = None,
        high_latency_threshold: Optional[float] = None,
        should_send_sumo: Optional[bool] = None,
    ) -> float:
        metric_name = f"{self.metric_name}/{name}" if name else self.metric_name
        time_taken = value if value is not None else self.get_time_elapsed()
        should_send_sumo = (
            should_send_sumo if should_send_sumo is not None else self.should_send_sumo
        )
        high_latency_threshold = (
            high_latency_threshold
            if high_latency_threshold is not None
            else self.high_latency_threshold
        )
        if should_send_sumo:
            if high_latency_threshold and time_taken > high_latency_threshold:
                self.logger.info(
                    "%(metric_name)s took %(time_taken).3fs (high latency).",
                    metric_name=metric_name,
                    time_taken=time_taken,
                    log_vars=self.log_vars,
                    stacklevel=2,
                )
            else:
                self.logger.info(
                    "%(metric_name)s took %(time_taken).3fs.",
                    metric_name=metric_name,
                    time_taken=time_taken,
                    log_vars=self.log_vars,
                    stacklevel=2,
                )

        if self.should_send_newrelic:
            if status is not None:
                record_newrelic(f"{metric_name}_latency/{status}", time_taken)

            if high_latency_threshold and time_taken > high_latency_threshold:
                record_nr_custom_event(
                    "HighLatencyOperation",
                    {
                        "latency": time_taken,
                        "operation": self.metric_name,
                        **self.log_vars,
                    },
                )
        return time_taken

    def get_time_elapsed(self) -> float:
        assert self._start_time
        return time.time() - self._start_time


class LatencyTracker:
    def __init__(
        self,
        start: float,
        domain: str,
        metric_name_prefix: Optional[str],
    ) -> None:
        self.start = start
        self.domain = domain
        self.metric_name_prefix = metric_name_prefix

        self.events = [("start", 0)]

    def emit_time_to_metric(self, event):
        time_to_value = time.time() - self.start
        self.events.append((event, time_to_value))

        LOGGER.info(
            "time to %(event)s is %(time_to_value).4fs",
            event=event,
            time_to_value=time_to_value,
        )

        event_name = f"time_to_{event}"
        if self.metric_name_prefix:
            event_name = f"{self.metric_name_prefix}/{event_name}"
        emit_metric_for_search("streaming", event_name, time_to_value, self.domain)

    def emit_final_metrics(self):
        self.emit_time_to_metric("end")

        emitted_event_indices = []
        for event_name, _ in self.events:
            if LATENCY_EVENT_NAMES_TO_NR_EVENT_MAP.get(event_name):
                emitted_event_indices.append(
                    LATENCY_EVENT_NAMES_TO_NR_EVENT_MAP.get(event_name)
                )
            else:
                emitted_event_indices.append("_")
                LOGGER.warning(
                    "%(event_name)s not found in LATENCY_EVENT_NAMES_TO_NR_EVENT_MAP",
                    event_name=event_name,
                )

        all_emitted_events = ".".join(emitted_event_indices)

        for event, time_to_event in self.events:
            if event == "start":
                continue

            combined_events_name = f"time_to_{event}_{all_emitted_events}"
            emit_metric_for_search(
                "streaming", combined_events_name, time_to_event, self.domain
            )


LATENCY_EVENT_NAMES_TO_NR_EVENT_MAP = {
    "start": "0",
    "end": "E",
    "get_user_app_preferences_data": "1",
    "reformulate_query_and_predict_is_personalizable_query": "2",
    "search_results_and_app_rankings": "3",
    "app_search": "4",
    "process_and_send_app_data_from_app_futures": "5",
    "add_richer_snippets": "6",
    "retrieve_info_before_youchat_response_generation": "7",
    "first_token": "8",
    "first_token_streamed_ngram": "9",
    "first_token_streamed_self_citing": "10",
    "model_turbo1106_invoked": "T",
    "model_turbo0125_invoked": "TN",
    "model_bedrockclaudeinstant_invoked": "BCI",
    "model_bedrockclaude_invoked": "BC",
    "model_bedrockclaude3haiku_invoked": "BCH",
    "model_bedrockclaude35haiku_invoked": "B35HK",
    "model_bedrockclaude3sonnet_invoked": "BCS",
    "model_bedrockclaude3opus_invoked": "BCOPUS",
    "model_bedrockclaude35sonnet_invoked": "B35SON",
    "model_claudeinstant_invoked": "CI",
    "model_claude_invoked": "C",
    "model_claude3haiku_invoked": "CH",
    "model_claude3sonnet_invoked": "CS",
    "model_claude35sonnet_invoked": "C35S",
    "model_claude3opus_invoked": "COPUS",
    "model_commandrplus_invoked": "COP",
    "model_gpt4o_mini_invoked": "G40M",
    "model_gpt4o_invoked": "G40",
    "model_gpt4turbo_invoked": "G4T",
    "model_gpt4turbonew_invoked": "G4TN",
    "model_gpt4_invoked": "G4",
    "model_gpt4_32k_invoked": "G432",
    "model_openaio1_invoked": "OAIO1",
    "model_openaio1_mini_invoked": "OAIO1M",
    "model_gemini15pro_invoked": "G15P",
    "model_geminiultra_invoked": "GU",
    "model_gemini15flash_invoked": "G15F",
    "model_llama3.1-405b_invoked": "L31405B",
    "model_llama3.2-90b_invoked": "L3290B",
    "model_bedrockllama3-8b_invoked": "BL38B",
    "model_bedrockLlama3.1-70b_invoked": "BL3170B",
    "model_bedrockllama3.1-405b_invoked": "BL31405B",
    "model_solar-1-mini_invoked": "S1M",
    "model_databricksdbrxinstruct_invoked": "DBRX",
    "model_bedrockmistrallarge2_invoked": "BML2",
    "marshall_generator_output": "11",
    "answer_thread_pool_done": "12",
    "chat_history_saved": "13",
}
