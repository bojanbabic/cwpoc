import logging
import re

import pytest

from ydc_services.global_utils.env import Env
from ydc_services.global_utils.instrument.tests.test_data.fake_file import (
    record_via_decorator,
    record_via_decorator_with_error,
    record_via_decorator_with_high_latency,
    record_via_with_context,
    record_via_with_context_with_error,
    record_via_with_context_with_high_latency,
    simple_log_message,
)

env = Env()


@pytest.mark.parametrize(
    "execute_fn, expected_log",
    [
        pytest.param(
            simple_log_message,
            "INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:9 log message",
            id="simple_log_message",
        ),
        pytest.param(
            record_via_decorator,
            """INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:12 fake1 called ctx: {'log_vars': {'log_vars': {}}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:12 fake1 success took *s. ctx: {'log_vars': {'log_vars': {}}}""",
            id="record_via_decorator",
        ),
        pytest.param(
            record_via_with_context,
            """INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:18 fake2 called ctx: {'log_vars': {}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:19 fake2/my_info ctx: {'log_value': 'a', 'log_vars': {}}
ERROR    ydc_services.global_utils.instrument.tests.test_data:fake_file.py:20 fake2/my_error ctx: {'log_value': 'b', 'log_vars': {}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:21 fake2/my_metric ctx: {'log_value': 1, 'log_vars': {}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:22 fake2/my_latency took *s. ctx: {'log_vars': {}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:18 fake2 success took *s. ctx: {'log_vars': {}}""",
            id="record_via_with_context",
        ),
        pytest.param(
            record_via_decorator_with_high_latency,
            """INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:25 fake1 called ctx: {'log_vars': {'log_vars': {}}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:25 fake1 success took *s (high latency). ctx: {'log_vars': {'log_vars': {}}}""",
            id="record_via_decorator_with_high_latency",
        ),
        pytest.param(
            record_via_with_context_with_high_latency,
            """INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:31 fake2 called ctx: {'log_vars': {}}
INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:31 fake2 success took *s (high latency). ctx: {'log_vars': {}}""",
            id="record_via_with_context_with_high_latency",
        ),
        pytest.param(
            record_via_decorator_with_error,
            """INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:35 fake1 called ctx: {'log_vars': {'log_vars': {}}}
ERROR    ydc_services.global_utils.instrument.tests.test_data:fake_file.py:35 fake1 error took *s. ctx: {'log_vars': {'log_vars': {}}}""",
            id="record_via_decorator_with_error",
        ),
        pytest.param(
            record_via_with_context_with_error,
            """INFO     ydc_services.global_utils.instrument.tests.test_data:fake_file.py:41 fake2 called ctx: {'log_vars': {}}
ERROR    ydc_services.global_utils.instrument.tests.test_data:fake_file.py:41 fake2 error took *s. ctx: {'log_vars': {}}""",
            id="record_via_with_context_with_error",
        ),
    ],
)
def test_kwargs_not_mutated_without_tenant(execute_fn, expected_log, caplog):
    try:
        with caplog.at_level(logging.INFO):
            execute_fn()
    except:
        pass

    processed_log = "\n".join(
        [
            re.sub(r"took \d+\.\d+s", "took *s", line)
            for line in caplog.text.strip().split("\n")
            if ".py:" in line
        ]
    )
    print(processed_log)
    assert processed_log == expected_log
