import logging

from ydc_services.global_utils.instrument.new_relic import record

logger = logging.getLogger(__package__)


def simple_log_message():
    logger.info("log message")


@record("fake1")
def record_via_decorator():
    pass


def record_via_with_context():
    with record("fake2", logger=logger) as rec:
        rec.log_info("my_info", "a")
        rec.log_error("my_error", "b")
        rec.log_metric("my_metric", 1)
        rec.log_latency(name="my_latency", value=1.0)


@record("fake1", high_latency_threshold=-1)
def record_via_decorator_with_high_latency():
    pass


def record_via_with_context_with_high_latency():
    with record("fake2", logger=logger, high_latency_threshold=-1):
        pass


@record("fake1")
def record_via_decorator_with_error():
    raise Exception("Some error")


def record_via_with_context_with_error():
    with record("fake2", logger=logger):
        raise Exception("Some error")
