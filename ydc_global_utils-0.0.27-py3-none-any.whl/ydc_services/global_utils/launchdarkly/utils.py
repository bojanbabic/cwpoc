import json
import logging
import os
import time
from typing import Any, Dict, List, Optional, Tuple

import ldclient
from aiohttp import web
from ldclient import Context, LDClient
from ldclient.config import Config

from ydc_services.global_utils.aiohttp.middlewares_and_headers import (
    request_context_var,
)
from ydc_services.global_utils.instrument.new_relic import record_newrelic
from ydc_services.global_utils.launchdarkly.constants import (
    ALLOWED_FLAG_REQUEST_CONTEXT_VAR,
    LD_CONTEXT_KEY,
    UNKNOWN_LD_CONTEXT,
)

logger = logging.getLogger(__package__)


def initialize_launchdarkly_sdk() -> Optional[LDClient]:
    sdk_key = os.environ.get("LAUNCHDARKLY_SDK_KEY", None)
    if not sdk_key:
        logger.error("*** LAUNCHDARKLY_SDK_KEY not set")
        return None

    ldclient.set_config(Config(sdk_key))

    if ldclient.get().is_initialized():
        logger.info("*** SDK successfully initialized!")
        return ldclient  # type: ignore[return-value]
    else:
        logger.error("*** SDK failed to initialize")
        return None


def get_launchdarkly_context(launchdarkly_context) -> Context:
    guest_id = launchdarkly_context.get("key", UNKNOWN_LD_CONTEXT)
    context = Context.builder(guest_id).kind("user")

    for attribute in launchdarkly_context:
        if attribute == "key":
            continue

        value = launchdarkly_context.get(attribute, UNKNOWN_LD_CONTEXT)
        if value is None:
            value = UNKNOWN_LD_CONTEXT
        context.set(attribute, value)

    return context.build()


def get_launchdarkly_state(request_json: dict) -> dict:
    launchdarkly_context = request_json.get("launchDarklyContext", {})
    # TODO: remove after we start passing LD context from FE
    if not launchdarkly_context:
        launchdarkly_context = {
            "key": request_json.get("guest_id", UNKNOWN_LD_CONTEXT),
            "country": request_json.get("ipCountry", UNKNOWN_LD_CONTEXT),
            "userAgent": request_json.get("userAgent", UNKNOWN_LD_CONTEXT),
            "secUserAgent": request_json.get("secUserAgent", UNKNOWN_LD_CONTEXT),
        }
    context = get_launchdarkly_context(launchdarkly_context)
    return ldclient.get().all_flags_state(context).to_json_dict()


def get_launchdarkly_variations(
    request_json: dict, flag_name_default_value_list: List[Tuple[str, Any]]
) -> dict:
    launchdarkly_context = request_json.get("launchDarklyContext", {})
    context = get_launchdarkly_context(launchdarkly_context)
    variations = {}
    for flag_name, default_value in flag_name_default_value_list:
        variation = ldclient.get().variation(flag_name, context, default_value)
        variations[flag_name] = variation
    return variations


def get_launchdarkly_variation(
    request_json: dict, flag_name: str, default_value: Any
) -> dict:
    return get_launchdarkly_variations(request_json, [(flag_name, default_value)])


def get_launchdarkly_variation_from_request_context(flag_name: str, default_value: Any):
    if flag_name not in ALLOWED_FLAG_REQUEST_CONTEXT_VAR:
        logger.warning(
            "Flag is not allowed to use this pattern. Be careful in using this pattern"
        )
        return default_value

    request_json = {
        "launchDarklyContext": request_context_var.get().launchdarkly_context or {}
    }

    return get_launchdarkly_variations(request_json, [(flag_name, default_value)]).get(
        flag_name
    )


def get_launchdarkly_variation_from_request(
    request: web.Request, flag_name: str, default_value: Any
):
    ld_context = request.headers.get(LD_CONTEXT_KEY)
    if not ld_context:
        return default_value

    try:
        ld_context_json = json.loads(ld_context)
    except json.JSONDecodeError:
        logger.error("Invalid LD context", ld_context=ld_context)
        return default_value

    request_json = {
        "launchDarklyContext": ld_context_json,
    }
    return get_launchdarkly_variations(request_json, [(flag_name, default_value)]).get(
        flag_name
    )


def update_request_json_with_launchdarkly_flags(
    request_json: Dict[str, Any],
    launchdarkly_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    # Only update request_json with flags from launchdarkly sdk
    # if launchdarkly_flags is not present in request_json
    if request_json.get("launchdarkly_flags") is not None:
        return request_json

    if launchdarkly_context and "launchDarklyContext" not in request_json:
        request_json["launchDarklyContext"] = launchdarkly_context

    start = time.time()
    ld_state = get_launchdarkly_state(request_json)
    ld_latency = time.time() - start
    record_newrelic(
        metric_name="launchdarkly_get_state_time",
        metric_value=ld_latency,
    )
    if ld_latency > 0.1:
        record_newrelic(
            metric_name="launchdarkly_get_state_time_over_100ms",
            metric_value=1,
        )
    request_json["launchdarkly_flags"] = ld_state
    return request_json
