LD_CONTEXT_KEY = "ld_context"
UNKNOWN_LD_CONTEXT = "UNKNOWN"

# NOTE:
# Use this very carefully and only for very isolated changes that do not change code/class behavior significantly
# Behavior of classes/functions should be understandable from their name and signature
# so if possible, pass flags as configuration options directly to the class constructor or methods
# The reason for not wanting to add more flags here is because it causes flags to be used like global variables.
# This will cause our code to increase in complexity and become difficult to understand.
ALLOWED_FLAG_REQUEST_CONTEXT_VAR = [
    "enableAnthropicTokenizer",
    "enableSharedAnthropicTokenizer",
    "ariRollout",
]
