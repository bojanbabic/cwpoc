import os


class Env:
    LOCAL_ENV = "local"
    STAGING_ENV = "staging"
    PROD_ENV = "prod"
    TESTING_ENV = "testing"

    def get_env(self) -> str:
        return os.getenv("DEPLOY_ENV_TYPE")

    def is_local(self) -> bool:
        return self.get_env() == self.LOCAL_ENV

    def is_staging(self) -> bool:
        return self.get_env() == self.STAGING_ENV

    def is_prod(self) -> bool:
        return self.get_env() == self.PROD_ENV

    def is_testing(self) -> bool:
        return self.get_env() == self.TESTING_ENV

    def is_cloud(self) -> bool:
        return self.is_staging() or self.is_prod()

    def is_incognito(self) -> bool:
        return bool(os.environ.get("INCOGNITO_MODE"))

    def is_docker(self) -> bool:
        # https://stackoverflow.com/questions/23513045/how-to-check-if-a-process-is-running-inside-docker-container
        return os.path.exists("/.dockerenv")

    def is_kubernetes(self) -> bool:
        return os.path.exists("/var/run/secrets/kubernetes.io")

    def is_outside_container(self) -> bool:
        return self.is_local() and not (self.is_docker() or self.is_kubernetes())

    def get_hostname(self) -> str:
        return os.getenv("HOSTNAME")

    def is_api_service(self) -> bool:
        return os.environ.get("EXT_API_MODE") == "on"

    def get_http_protocol(self) -> str:
        proto = os.environ.get("HTTP_PROTOCOL", "http")
        return proto.lower() if proto.lower() in {"http", "https"} else "http"
