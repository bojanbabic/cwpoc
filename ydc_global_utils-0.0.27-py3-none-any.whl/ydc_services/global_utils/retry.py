import logging
import time
import traceback
from typing import Callable, List, Optional, TypeVar

T = TypeVar("T")
U = TypeVar("U")


class FailedAfterRetries(Exception):
    def __init__(
        self,
        exceptions: List[Exception],
        tracebacks: Optional[List[str]] = None,
        message: Optional[str] = None,
    ):
        super().__init__(
            message
            or str([tb for tb in tracebacks or []])
            or str([str(ex) for ex in exceptions])
        )
        self.exceptions = exceptions


class Retry:
    def __init__(
        self, max_tries: Optional[int] = None, max_time_elapsed: Optional[float] = None
    ):
        self.max_tries = max_tries
        self.max_time_elapsed = max_time_elapsed
        self.exceptions: List[Exception] = []
        self.tracebacks: List[str] = []
        self._num_tries = 0
        self._is_cancelled = False
        self._start_time = time.time()

    def reset(self) -> None:
        self.exceptions = []
        self.tracebacks = []
        self._num_tries = 0
        self._is_cancelled = False
        self._start_time = time.time()

    def cancel(self):
        self._is_cancelled = True

    def should_retry(self) -> bool:
        if self._is_cancelled:
            logging.info("Not retrying due to cancellation")
            return False

        if self.max_time_elapsed is not None:
            time_elapsed = time.time() - self._start_time
            if time_elapsed > self.max_time_elapsed:
                logging.info(
                    f"Not retrying as time_elapsed of {time_elapsed:.4f}s > {self.max_time_elapsed:.4f}s"
                )
                return False

        if self.max_tries is not None and self._num_tries >= self.max_tries:
            logging.info(
                f"Not retrying as num_tries of {self._num_tries} >= {self.max_tries}"
            )
            return False
        return True

    def over_options(self, func: Callable[[int, T], U], options: List[T]) -> U:
        for option in options:
            try:
                self._num_tries += 1
                out = func(self._num_tries, option)
                return out
            except Exception as exc:
                logging.error(f"Failed try {self._num_tries}: {exc}", exc_info=True)
                self.exceptions.append(exc)
                self.tracebacks.append(traceback.format_exc())
                if not self.should_retry():
                    logging.info("Ending retry")
                    break
                logging.info("Retrying")

        raise FailedAfterRetries(self.exceptions, self.tracebacks)
