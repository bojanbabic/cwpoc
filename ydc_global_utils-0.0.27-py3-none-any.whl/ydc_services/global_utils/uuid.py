import base64
import hashlib


def short_hash(key: str) -> str:
    # https://stackoverflow.com/a/2510733
    hasher = hashlib.sha1(key.encode("utf-8"))
    return _shorten_uuid(hasher.digest())


def _shorten_uuid(uuid_bytes: bytes) -> str:
    # Total bits = 8 characters × 6 bits/character = 48 bits.
    # Total unique UUIDs is 2^48. ~ 281Trillion. Collisions are extremely unlikely.
    return base64.urlsafe_b64encode(uuid_bytes).decode("ascii").rstrip("=")[:8]
