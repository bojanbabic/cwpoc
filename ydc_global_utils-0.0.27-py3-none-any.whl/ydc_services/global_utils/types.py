class NotGiven:
    """
    Copied from: https://github.com/anthropics/anthropic-sdk-python/blob/bd866a1e837febd05b6f5cea322f1c42e29f2d01/src/anthropic/_types.py
    A sentinel singleton class used to distinguish omitted keyword arguments
    from those passed in with the value None (which may have different behavior).

    For example:

    ```py
    def get(timeout: Union[int, NotGiven, None] = NotGiven()) -> Response:
        ...

    get(timeout=1)  # 1s timeout
    get(timeout=None)  # No timeout
    get()  # Default timeout behavior, which may not be statically known at the method definition.
    ```
    """

    pass


NOT_GIVEN = NotGiven()
