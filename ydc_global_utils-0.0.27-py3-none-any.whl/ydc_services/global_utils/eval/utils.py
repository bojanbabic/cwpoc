import concurrent.futures
import hashlib
import random
import re
from concurrent.futures import ThreadPoolExecutor
from typing import (
    Any,
    Callable,
    Concatenate,
    Dict,
    Iterator,
    List,
    Literal,
    Optional,
    ParamSpec,
    Tuple,
    TypeVar,
    overload,
)

import pandas as pd
from tqdm import tqdm

DEFAULT_NUM_WORKERS = 8

P = ParamSpec("P")
T = TypeVar("T")


def short_hash(text: str, hash_len: Optional[int]) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()[:hash_len]


def hash_to_bucket(text: str, num_buckets: int) -> int:
    """
    Hashes the input text and bins it into one of the specified number of buckets.
    """
    # Generate the MD5 hash
    hash_value = short_hash(text, None)
    # Convert the hash to an integer
    hash_int = int(hash_value, 16)
    # Compute the bucket index
    return hash_int % num_buckets


def get_short_hashes(values: Dict[str, Any], hash_len: int):
    return {f"{k}_hash": short_hash(v, hash_len) for k, v in values.items()}


def sample_from_powerset_with_replacement(
    items: List[T], n: int, min_size: int = 0
) -> Iterator[List[T]]:
    assert len(items) >= min_size
    counter = 0
    while counter <= n:
        sampled_items = [item for item in items if random.randint(0, 1) == 1]
        if len(sampled_items) < min_size:
            continue

        counter += 1
        yield sampled_items


def copy_params_and_add_short_hashes_for_prompt_template_keys(
    params: Dict[str, Any], hash_len: int = 3
):
    params_copy = params.copy()
    params_copy.update(
        get_short_hashes(
            {
                k: v
                for k, v in params.items()
                if (k.endswith("template") or k.endswith("prompt"))
                and isinstance(v, str)
            },
            hash_len=hash_len,
        )
    )
    full_params_hash = short_hash(str(params_copy), hash_len)
    params_copy["params_hash"] = full_params_hash
    return params_copy


def load_freshqa_dataset(
    path: str, header: int = 0, ignore_false_premise: bool = False
) -> pd.DataFrame:
    df = pd.read_csv(path, header=header, keep_default_na=False)

    # The dataset has another DEV split that can be used for prompting
    df = df[df["split"] == "TEST"]

    # The dataset splits each answer into columns such as answer_0, answer_1, etc.
    # We combine them into a single answers column.
    answer_columns = [
        col_name for col_name in df.columns if re.match(r"^answer_(\d+)$", col_name)
    ]
    df["reference_answers"] = df.apply(
        lambda row: [
            row[col_name]
            for col_name in answer_columns
            if str(row[col_name]).strip() != ""
        ],
        axis=1,
    )

    if ignore_false_premise:
        df = df[~df["false_premise"]]

    return df


@overload
def pd_parallel_apply(
    df: pd.DataFrame,
    run_fn: Callable[Concatenate[pd.Series, P], Dict[str, Any]]
    | Callable[Concatenate[pd.Series, P], List[Dict[str, Any]]],
    include_full_dataframe: Literal[False] = False,
    should_explode: bool = False,
    max_workers: int = DEFAULT_NUM_WORKERS,
    save_path: Optional[str] = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> pd.DataFrame:
    ...


@overload
def pd_parallel_apply(
    df: pd.DataFrame,
    run_fn: Callable[Concatenate[pd.DataFrame, int, P], Dict[str, Any]]
    | Callable[Concatenate[pd.DataFrame, int, P], List[Dict[str, Any]]],
    include_full_dataframe: Literal[True],
    should_explode: bool = False,
    max_workers: int = DEFAULT_NUM_WORKERS,
    save_path: Optional[str] = None,
    *args: P.args,
    **kwargs: P.kwargs,
) -> pd.DataFrame:
    ...


def pd_parallel_apply(
    df: pd.DataFrame,
    run_fn: Callable[..., Dict[str, Any]] | Callable[..., List[Dict[str, Any]]],
    include_full_dataframe: bool = False,
    should_explode: bool = False,
    max_workers: int = DEFAULT_NUM_WORKERS,
    save_path: Optional[str] = None,
    *args: Any,
    **kwargs: Any,
) -> pd.DataFrame:
    def _postprocess_data(
        _original_df: pd.DataFrame, _data: List[Tuple[int, Dict | List[Dict]]]
    ) -> pd.DataFrame:
        # Needed because the concurrency changed up the order
        sorted_data = [d for i, d in sorted(_data, key=lambda x: x[0])]
        if should_explode:
            exploded_data: List[Dict] = []
            for item in sorted_data:
                exploded_data.extend(item)
            pred_df = pd.DataFrame(exploded_data)
        else:
            pred_df = pd.DataFrame(sorted_data)

        # Reset pred_df's index
        # Drop overlapping columns in df first
        _original_df = _original_df.drop(columns=pred_df.columns, errors="ignore")

        if should_explode:
            # Determine the counts of how many new rows each original row expands into
            counts = [len(lst) for lst in sorted_data]
            # Repeat the original rows accordingly
            repeated_df = _original_df.loc[
                _original_df.index.repeat(counts)
            ].reset_index(drop=True)

            # Combine the repeated original rows with the new columns
            _combined_df = pd.concat(
                [repeated_df, pred_df.reset_index(drop=True)], axis=1
            )
        else:
            _combined_df = pd.concat(
                [_original_df, pred_df.set_index(_original_df.index)], axis=1
            )
        return _combined_df

    data = []

    with ThreadPoolExecutor(max_workers=max_workers) as tpe:
        if include_full_dataframe:
            future_to_row_map = {
                tpe.submit(run_fn, df, i, *args, **kwargs): (i, row)
                for i, (_, row) in enumerate(df.iterrows())
            }
        else:
            future_to_row_map = {
                tpe.submit(run_fn, row, *args, **kwargs): (i, row)
                for i, (_, row) in enumerate(df.iterrows())
            }
        for future in tqdm(
            concurrent.futures.as_completed(future_to_row_map), total=len(df)
        ):
            i, row = future_to_row_map[future]
            result = future.result()
            if should_explode:
                assert isinstance(result, list), (
                    "When `should_explode=True`, "
                    "your function should return a List[Dict]."
                )
            data.append((i, result))

            if i % 50 == 0 and i > 0:  # type: ignore
                print(f"Completed {len(data)}/{len(df)}", end="\r")
                if save_path:
                    combined_df = _postprocess_data(df, data)
                    combined_df.to_csv(save_path, index=False)

    combined_df = _postprocess_data(df, data)
    if save_path:
        combined_df.to_csv(save_path, index=False)
    return combined_df


if __name__ == "__main__":

    def f(row):
        return [{"new": row["x"]}] * row["x"]

    df = pd.DataFrame([{"x": 1}, {"x": 2}, {"x": 3}])
    print(df)
    df_new = pd_parallel_apply(df, f, should_explode=True)
    print(df_new)
