import json
import logging
import os
import pickle
import time
from io import BytesIO
from typing import Optional, Set, Union

import pandas as pd
from azure.core.exceptions import ResourceExistsError
from azure.storage.blob import (
    BlobClient,
    BlobServiceClient,
    ContainerClient,
    ContentSettings,
    PartialBatchErrorException,
)
from dotenv import load_dotenv

from ydc_services.global_utils.storage.constants import Constants

load_dotenv()

# Set the logging level for all azure-* libraries
azure_logger = logging.getLogger("azure")
if not os.environ.get("INCOGNITO_MODE"):
    azure_logger.setLevel(logging.INFO)

logger = logging.getLogger(__package__)

NUM_RETRIES = 3


def get_storage_account_name_from_connection_string_var(
    connection_string_var: str,
) -> str:
    return (
        os.environ[connection_string_var]
        .split("AccountName=")[1]
        .split(";AccountKey=")[0]
    )


def infer_blob_type_from_name(blob_type, name):
    if Constants().JSON_LINES_NAME in name or Constants().HTML_LINES_NAME in name:
        return "jl"
    return blob_type


def escape_forward_slash(url):
    # azurre blob storage will treat slashes as a path to file which we don't want, thus escape
    return url.replace("/", "_FWDSLASH_")


def upload_file_to_blob(
    fname, blob_name, container_name, to_cdn=False, should_escape_forward_slash=True
):
    for i in range(NUM_RETRIES):
        try:
            logger.info(
                "Upload started for blob",
                blob_name=blob_name,
                container_name=container_name,
            )
            if to_cdn:
                connection_str = os.getenv("CDN_STORAGE_CONNECTION_STRING")
            else:
                connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
            with BlobClient.from_connection_string(
                connection_str,
                container_name=container_name,
                blob_name=escape_forward_slash(blob_name)
                if should_escape_forward_slash
                else blob_name,
                timeout=300,
            ) as client:
                with open(fname, "rb") as f:
                    client.upload_blob(f, overwrite=True, blob_type="BlockBlob")
                logger.info(
                    "Upload succeeded for blob",
                    blob_name=blob_name,
                    container_name=container_name,
                )
            return
        except Exception as e:
            logger.error(
                "Error uploading blob to storage container",
                blob_name=blob_name,
                container_name=container_name,
                retry_count=i,
                exc_info=e,
            )
            time.sleep(10)


def upload_blob(
    data: Union[bytes, dict, str],
    blob_name: str,
    container_name: str,
    blob_type: str = "json",
    to_cdn: bool = False,
    content_type=None,
    to_user_uploads: bool = False,
    to_agent_cdn: bool = False,
) -> None:
    if os.environ.get("INCOGNITO_MODE"):
        # dont upload anything in INCOGNITO MODE
        return
    # Set the logging level for all azure-* libraries
    azure_logger = logging.getLogger("azure")
    if not os.environ.get("INCOGNITO_MODE"):
        azure_logger.setLevel(logging.INFO)

    if to_cdn:
        connection_str = os.getenv("CDN_STORAGE_CONNECTION_STRING")
    elif to_user_uploads:
        connection_str = os.getenv("USER_UPLOADS_BLOB_STORAGE_CONNECTION_STRING")
    elif to_agent_cdn:
        connection_str = os.getenv("AGENT_CDN_STORAGE_CONNECTION_STRING")
    else:
        connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")

    if not connection_str:
        logger.warning("os env variable for blob storage not set")
        raise Exception("os env variable for blob storage not set")

    # Azure SDK has default retry policy so this retry loop is redundant
    # Not fixing as this code path will be deprecated after we migrate to S3
    for i in range(NUM_RETRIES):
        try:
            logger.info(
                "Upload started for blob",
                blob_name=blob_name,
                container_name=container_name,
                retry_count=i,
            )

            with BlobClient.from_connection_string(
                connection_str,
                container_name=container_name,
                blob_name=escape_forward_slash(blob_name),
                timeout=300,
            ) as client:
                data_s: Union[bytes, str, dict] = data
                if blob_type == "json":
                    if not isinstance(data, dict):
                        data = {"data": data}
                    data["upload_time"] = time.time()

                    data_s = json.dumps(data)
                elif blob_type == "pickle":
                    data_s = pickle.dumps(data)
                elif blob_type == "raw":
                    data_s = data
                else:
                    raise ValueError("Illegal type of data upload to blob")

                if content_type:
                    content_settings = ContentSettings(content_type=content_type)
                else:
                    content_settings = None

                client.upload_blob(
                    overwrite=True, data=data_s, content_settings=content_settings
                )

            logger.info(
                "Upload succeeded for blob",
                blob_name=blob_name,
                container_name=container_name,
            )
            return
        except Exception as e:
            logger.error(
                "Error uploading blob to storage container",
                blob_name=blob_name,
                container_name=container_name,
                retry_count=i,
                exc_info=e,
            )
            time.sleep(10)

    # if we get to here, upload has failed; let callers know by raising a generic exception instead of silently failing
    logger.error(
        "Failed to upload file",
        blob_name=blob_name,
        container_name=container_name,
    )
    raise Exception("Failed to upload file")


def download_blob_to_file(fname, blob_name, container_name):
    for i in range(NUM_RETRIES):
        try:
            logger.info(
                "Download started for blob",
                blob_name=blob_name,
                container_name=container_name,
            )
            connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
            with BlobClient.from_connection_string(
                connection_str,
                container_name=container_name,
                blob_name=escape_forward_slash(blob_name),
                timeout=300,
            ) as client:
                with open(fname, "wb") as my_blob:
                    blob_data = client.download_blob()
                    blob_data.readinto(my_blob)
                logger.info(
                    "Download succeeded for blob",
                    blob_name=blob_name,
                    container_name=container_name,
                )
            return
        except Exception as e:
            logger.error(
                "Error downloading blob to storage container",
                blob_name=blob_name,
                container_name=container_name,
                retry_count=i,
                exc_info=e,
            )
            time.sleep(10)


def download_blob(
    blob_name,
    container_name,
    blob_type="json",
    do_escape_forward_slash=True,
    from_user_uploads=False,
    from_agent_cdn=False,
):
    start = time.time()
    if from_user_uploads:
        connection_str = os.getenv("USER_UPLOADS_BLOB_STORAGE_CONNECTION_STRING")
    elif from_agent_cdn:
        connection_str = os.getenv("AGENT_CDN_STORAGE_CONNECTION_STRING")
    else:
        connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not connection_str:
        logger.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
    try:
        client = BlobClient.from_connection_string(
            connection_str,
            container_name=container_name,
            blob_name=escape_forward_slash(blob_name)
            if do_escape_forward_slash
            else blob_name,
        )
    except Exception as e:
        logger.error(
            "blob client could not be created",
            exc_info=e,
        )
        return None

    return_value = None
    try:
        with client:
            download_stream = client.download_blob()
            if blob_type == "json":
                return_value = json.loads(download_stream.readall())
            elif blob_type == "jl":
                return_value = [
                    json.loads(line) for line in download_stream.readall().splitlines()
                ]
            elif blob_type == "pickle":
                return_value = pickle.loads(download_stream.readall())
            elif blob_type == "parquet":
                stream = BytesIO()
                download_stream.readinto(stream)
                return_value = pd.read_parquet(stream)
            elif blob_type == "file":
                with open(blob_name, "wb") as f:
                    f.write(download_stream.readall())
                return_value = blob_name
            elif blob_type == "raw":
                return_value = download_stream.readall()
            else:
                raise ValueError("Illegal type of data download from blob")
    except Exception as e:
        logger.error(
            "Error downloading blob from container",
            blob_name=blob_name,
            container_name=container_name,
            exc_info=e,
        )
        return None
    else:
        logger.info(
            "Downloading blob",
            blob_name=blob_name,
            container_name=container_name,
            time_taken=time.time() - start,
        )
        return return_value


def get_all_blob_names_with_prefix(container_name, name_starts_with=None):
    connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not connection_str:
        logger.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
    try:
        with BlobServiceClient.from_connection_string(
            connection_str
        ) as blob_service_client:
            with blob_service_client.get_container_client(
                container_name
            ) as container_client:
                source_blob_list = list(container_client.list_blobs(name_starts_with))
                source_blob_list = sorted(
                    source_blob_list, key=lambda x: x["last_modified"]
                )
                blob_name_list = [blob["name"] for blob in source_blob_list]
                return blob_name_list, blob_service_client
    except Exception as e:
        logger.error(
            "Error getting latest blob from container",
            container_name=container_name,
            exc_info=e,
        )
        return None, None


def get_container_names_with_prefix(prefix, to_cdn=False):
    if to_cdn:
        connection_str = os.getenv("CDN_STORAGE_CONNECTION_STRING")
    else:
        connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not connection_str:
        logger.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
    try:
        with BlobServiceClient.from_connection_string(
            connection_str
        ) as blob_service_client:
            container_info_list = list(
                blob_service_client.list_containers(name_starts_with=prefix)
            )
            container_name_list = [
                container_info["name"] for container_info in container_info_list
            ]
            return container_name_list
    except Exception as e:
        logger.error(
            "Error getting container names with prefix",
            prefix=prefix,
            exc_info=e,
        )
        return None


def create_container(
    name: str,
    to_cdn: bool = False,
    public_access: Optional[str] = None,
    to_user_uploads: bool = False,
    to_agent_cdn: bool = False,
) -> None:
    if to_cdn:
        connection_str = os.getenv("CDN_STORAGE_CONNECTION_STRING")
    elif to_user_uploads:
        connection_str = os.getenv("USER_UPLOADS_BLOB_STORAGE_CONNECTION_STRING")
    elif to_agent_cdn:
        connection_str = os.getenv("AGENT_CDN_STORAGE_CONNECTION_STRING")
    else:
        connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not connection_str:
        logger.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
        raise Exception("No storage connection string found")

    container_client = None
    try:
        # this uses the default retry configs from Azure
        # https://learn.microsoft.com/en-us/azure/storage/blobs/storage-retry-policy-python
        with BlobServiceClient.from_connection_string(
            connection_str
        ) as blob_service_client:
            with blob_service_client.get_container_client(name) as container_client:
                if not container_client.exists():
                    container_client.create_container(public_access=public_access)
    except ResourceExistsError as e:
        # Azure for some reason will throw exception of container exists even though
        # the code above does check for container exists before calling create
        # Do not re-raise as we did successfully "create" the container
        logger.info(
            "Container exists",
            container_name=name,
            public_access=public_access,
            cdn=to_cdn,
            user_uploads=to_user_uploads,
            agent_cdn=to_agent_cdn,
            exc_info=e,
        )
    except Exception as e:
        logger.error(
            "Error creating container",
            container_name=name,
            public_access=public_access,
            cdn=to_cdn,
            user_uploads=to_user_uploads,
            agent_cdn=to_agent_cdn,
            exc_info=e,
        )
        raise e


# Remember to close the client; otherwise, we leak socket connections
# Either call close explicitly or use it in a context:
# https://learn.microsoft.com/en-us/python/api/azure-storage-blob/azure.storage.blob.containerclient?view=azure-python#azure-storage-blob-containerclient-close
def get_container_client(container_name, to_user_uploads=False):
    if to_user_uploads:
        connection_str = os.getenv("USER_UPLOADS_BLOB_STORAGE_CONNECTION_STRING")
    else:
        connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not isinstance(connection_str, str):
        logging.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
        return None
    try:
        print(connection_str)
        print(container_name)
        blob_service_client = BlobServiceClient.from_connection_string(connection_str)
        container_client = blob_service_client.get_container_client(container_name)
        return container_client
    except Exception as e:
        logging.error(
            f"Error getting container_client for container {container_name}: {e}"
        )
        return None


def download_all_blobs(
    container_name, name_starts_with=None, blob_type="json", max_blobs=None
):
    connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not connection_str:
        logger.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
    try:
        with BlobServiceClient.from_connection_string(
            connection_str
        ) as blob_service_client:
            with blob_service_client.get_container_client(
                container_name
            ) as container_client:
                source_blob_list = list(container_client.list_blobs(name_starts_with))
                data = {}
                max_blobs = len(source_blob_list) if max_blobs is None else max_blobs
                for blob in source_blob_list[:max_blobs]:
                    if blob_type == "parquet":
                        data.update(
                            {
                                blob["name"]: download_blob(
                                    blob["name"], container_name, blob_type
                                )
                            }
                        )
                    else:
                        data.update(
                            download_blob(blob["name"], container_name, blob_type)
                        )
                return data
    except Exception as e:
        logger.error(
            "Error downloading latest blob",
            container_name=container_name,
            exc_info=e,
        )
        return None


def delete(
    container_name: str,
    blobs: Set[str],
    to_user_uploads: bool = True,
    to_cdn: bool = False,
    to_agent_cdn: bool = False,
) -> int:
    """
    Returns:
        int: Number of blobs successfully deleted
    """

    num_blobs_to_delete = len(blobs)
    if num_blobs_to_delete <= 0:
        raise ValueError("Must specify at least 1 blob to delete")

    if to_cdn:
        connection_str = os.getenv("CDN_STORAGE_CONNECTION_STRING")
    elif to_user_uploads:
        connection_str = os.getenv("USER_UPLOADS_BLOB_STORAGE_CONNECTION_STRING")
    elif to_agent_cdn:
        connection_str = os.getenv("AGENT_CDN_STORAGE_CONNECTION_STRING")
    else:
        connection_str = os.getenv("BLOB_STORAGE_CONNECTION_STRING")
    if not connection_str:
        logger.warning("os env variable BLOB_STORAGE_CONNECTION_STRING not set")
        raise Exception("No storage connection string found")

    try:
        with ContainerClient.from_connection_string(
            connection_str, container_name=container_name
        ) as client:
            client.delete_blobs(*blobs)
        return num_blobs_to_delete
    except PartialBatchErrorException as e:
        failed_count = 0
        for part in e.parts:
            if part.status_code >= 400:
                failed_count += 1
        logger.error(
            "Failed to delete resources",
            container_name=container_name,
            blob_name=blobs,
            failed_count=failed_count,
            exc_info=e,
        )
        return num_blobs_to_delete - failed_count
    except Exception as e:
        logger.error(
            "Failed to delete resources",
            container_name=container_name,
            blob_name=blobs,
            failed_count=num_blobs_to_delete,
            exc_info=e,
        )
        return num_blobs_to_delete
