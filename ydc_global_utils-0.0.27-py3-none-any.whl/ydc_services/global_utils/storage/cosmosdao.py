import os

import mongomock
import pymongo

from ydc_services.global_utils.env import Env
from ydc_services.global_utils.storage.constants import Constants

env = Env()


class CosmosDao:
    """
    it is preferable to initialize CosmosDao with a collection or else you will have to specify it
    as "source" in every database function below...
    """

    def __init__(
        self,
        name="api_cache",
        collection="",
        connection_string=None,
        filter=None,
    ):
        # Define constants
        self.db_name = name
        self.constants = Constants()
        if filter is None:
            self.filter = {}
        else:
            self.filter = filter

        if connection_string:
            self.connection_string = connection_string
        elif env.is_prod():
            self.connection_string = os.environ.get("PROD_DB_CONNECTION_STR")
        else:
            self.connection_string = os.environ.get("STAGING_DB_CONNECTION_STR")

        if not any([name in n for n in self.constants.MONGO_DATABASES]):
            exit("invalid database name")

        client = pymongo.MongoClient(self.connection_string)
        self.db = client[self.db_name]
        self.collection = collection  ### if this is set, iterator will use this

        self.sources = (
            self.constants.USER_REVIEWS_SOURCES
            + self.constants.PRODUCT_SOURCES
            + self.constants.EDITORIAL_REVIEWS_DB
            + self.constants.USER_DBS
        )


class CosmosDaoV2:
    def __init__(
        self,
        prod_db_name: str,
        staging_db_name: str,
        connection_string: str = None,
        is_testing: bool = False,
    ):
        if is_testing:
            self.db = mongomock.MongoClient().db.collection
            return

        if env.is_prod():
            self.connection_string = os.environ.get("PROD_DB_CONNECTION_STR")
            self.db_name = prod_db_name
        else:
            self.connection_string = os.environ.get("STAGING_DB_CONNECTION_STR")
            self.db_name = staging_db_name

        if connection_string:
            self.connection_string = connection_string

        client = pymongo.MongoClient(self.connection_string)
        self.db = client[self.db_name]

    def get_collection(self, collection: str):
        return self.db[collection]
