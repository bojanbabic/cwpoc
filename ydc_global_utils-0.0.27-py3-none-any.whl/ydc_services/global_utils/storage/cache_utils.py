import copy
import inspect
import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor

from ydc_services.global_utils.env import Env
from ydc_services.global_utils.storage.constants import Constants
from ydc_services.global_utils.storage.pymongo import CosmosDao
from ydc_services.global_utils.storage.redis_client import MockRedisClient, RedisClient

logger = logging.getLogger(__name__)
env = Env()


def get_real_redis_client_or_mock(
    db_name,
    cache_expires,
    use_real=False,
    host=None,
    password=None,
    socket_timeout=None,
    ssl=None,
):
    if env.is_cloud() or use_real:
        return RedisClient(
            db=db_name,
            cache_expires=cache_expires,
            host=host,
            password=password,
            socket_timeout=socket_timeout,
            ssl=ssl,
        )
    else:
        logger.info("Using mock redis cache for TESTING")
        return MockRedisClient()


class DecoratorCachableDBAPICall:
    def __init__(
        self,
        collection_name,
        cacheable_keys,
        num_workers=3,
        cache_expires=Constants().REDIS_KEY_EXPIRES_1WEEK,
    ):
        self.db_name = Constants().CACHE_DB
        self.collection_name = collection_name
        self.db_handle = CosmosDao(self.db_name, self.collection_name)
        self.cache_expires = cache_expires
        self.thread_pool = ThreadPoolExecutor(
            thread_name_prefix=f"{self.db_name}_{self.collection_name}_db_cache",
            max_workers=num_workers,
        )
        self.cacheable_keys = cacheable_keys

    ##get a mapping from arg name to value, so we use this as our key in the DB
    ##only appropriate of course if the same args should yield the same results
    def construct_arg_mapping(self, args, defaults, kwargs, arg_names):
        name2args = copy.deepcopy(kwargs)
        for idx, arg in enumerate(args):
            name2args[arg_names[idx]] = arg

        ##handle default arguments only if they haven't been set by
        ##user passed in args
        if defaults:
            for idx, arg in enumerate(defaults[::-1]):
                def_name = arg_names[-1 * (idx + 1)]
                if def_name not in name2args:
                    name2args[def_name] = arg

        ##only keep the args that the user says matter for the caching
        return dict(
            [
                argitem
                for argitem in name2args.items()
                if argitem[0] in self.cacheable_keys
            ]
        )

    def upload(self, name2args, results):
        self.db_handle.db[self.collection_name].update_one(
            name2args, {"$set": {"result": results, "time": time.time()}}, upsert=True
        )

    ##this call will be used as a decorator,
    ##first, we check if the args are cached in the DB and within the cache expiration date
    ##if so, return the cache, else, go call the decorated function, cache it in background, and return
    def cache_api_call(self, cb):
        ##check db --
        args_names = inspect.getfullargspec(cb).args
        defaults = inspect.getfullargspec(cb).defaults

        def return_func(*args, **kwargs):
            name2args = self.construct_arg_mapping(args, defaults, kwargs, args_names)
            result = self.db_handle.db[self.collection_name].find_one(name2args)
            if result and time.time() - result.get("time") < self.cache_expires:
                logger.info("cache hit for api", collection_name=self.collection_name)
                result = result.get("result")
            else:
                logger.info("cache miss for api", collection_name=self.collection_name)
                result = cb(*args, **kwargs)
                self.thread_pool.submit(self.upload, name2args, result)

            return result

        return return_func


class DecoratorCachableRedisAPICall:
    def __init__(
        self,
        cacheable_keys,
        cache_name,
        num_workers=3,
        cache_expires=Constants().REDIS_KEY_EXPIRES_1WEEK,
        use_real=True,
    ):
        self.cache_client = get_real_redis_client_or_mock(
            cache_name, cache_expires, use_real
        )
        self.cache_expires = cache_expires
        self.thread_pool = ThreadPoolExecutor(
            thread_name_prefix=f"{cache_name}_cache", max_workers=num_workers
        )
        self.cacheable_keys = cacheable_keys

    ##get a mapping from arg name to value, so we use this as our key in the DB
    ##only appropriate of course if the same args should yield the same results
    def construct_arg_mapping(self, args, defaults, kwargs, arg_names):
        ##only keep the args that the user says matter for the caching
        name2args = copy.deepcopy(
            {k: v for k, v in kwargs.items() if k in self.cacheable_keys}
        )
        for idx, arg in enumerate(args):
            if arg_names[idx] in self.cacheable_keys:
                name2args[arg_names[idx]] = arg

        ##handle default arguments only if they haven't been set by
        ##user passed in args
        if defaults:
            for idx, arg in enumerate(defaults[::-1]):
                def_name = arg_names[-1 * (idx + 1)]
                if def_name not in name2args and def_name in self.cacheable_keys:
                    name2args[def_name] = arg

        return name2args

    def upload(self, name2args_bytes, result_bytes):
        self.cache_client.set(
            name2args_bytes,
            result_bytes,
        )

    ##this call will be used as a decorator,
    ##first, we check if the args are cached in the DB and within the cache expiration date
    ##if so, return the cache, else, go call the decorated function, cache it in background, and return
    def cache_get_set_api_call(self, cb):
        ##check db --
        args_names = inspect.getfullargspec(cb).args
        defaults = inspect.getfullargspec(cb).defaults

        def return_func(*args, **kwargs):
            name2args = self.construct_arg_mapping(args, defaults, kwargs, args_names)
            name2args_bytes = json.dumps(name2args).encode("utf-8")
            result_bytes = self.cache_client.get(name2args_bytes)
            if result_bytes:
                result = json.loads(result_bytes)
            else:  # Graceful failing, just return function
                result = cb(*args, **kwargs)
                result_bytes = json.dumps(result).encode("utf-8")
                self.upload(name2args_bytes, result_bytes)

            return result

        return return_func

    ##this call will be used as a decorator,
    ##go call the decorated function, cache it in background, and return
    def cache_set_api_call(self, cb):
        ##check db --
        args_names = inspect.getfullargspec(cb).args
        defaults = inspect.getfullargspec(cb).defaults

        def return_func(*args, **kwargs):
            name2args = self.construct_arg_mapping(args, defaults, kwargs, args_names)
            name2args_bytes = json.dumps(name2args).encode("utf-8")
            result = cb(*args, **kwargs)
            result_bytes = json.dumps(result).encode("utf-8")
            self.thread_pool.submit(self.upload, name2args_bytes, result_bytes)

            return result

        return return_func

    ##this call will be used as a decorator,
    ##first, we check if the args are cached in the DB and within the cache expiration date
    ##if so, return the cache, else, go call the decorated function. Don't cache results from decorated function
    def cache_get_api_call(self, cb):
        ##check db --
        args_names = inspect.getfullargspec(cb).args
        defaults = inspect.getfullargspec(cb).defaults

        def return_func(*args, **kwargs):
            name2args = self.construct_arg_mapping(args, defaults, kwargs, args_names)
            name2args_bytes = json.dumps(name2args).encode("utf-8")
            result_bytes = self.cache_client.get(name2args_bytes)
            if result_bytes:
                result = json.loads(result_bytes)
                logger.info("cache hit for redis")
            else:
                logger.info("cache miss for redis")
                result = cb(*args, **kwargs)
                result_bytes = json.dumps(result).encode("utf-8")

            return result

        return return_func


##what we give to developers for testing, simply makes sure we can serialize
##what would get cached
class MockCachableAPICall(DecoratorCachableDBAPICall):
    def cache_api_call(self, cb):
        args_names = inspect.getfullargspec(cb).args
        defaults = inspect.getfullargspec(cb).defaults

        def return_func(*args, **kwargs):
            name2args = self.construct_arg_mapping(args, defaults, kwargs, args_names)
            assert json.dumps(name2args) is not None
            return cb(*args, **kwargs)

        return return_func
