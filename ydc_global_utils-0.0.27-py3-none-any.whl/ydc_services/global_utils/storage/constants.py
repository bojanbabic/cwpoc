"""
    Treat this like a "config" file for this instance of the search engine:
        - the IP addresses of indices
        - the names of elastic search and mongo collections you want to consider
        - maybe some other flags or A/B logic can be added later
"""
import os

from ydc_services.global_utils.env import Env

env = Env()


class Constants:
    @property
    def JSON_LINES_NAME(self):
        return "json-lines-data"

    @property
    def HTML_LINES_NAME(self):
        return "html-lines-data"

    @property
    def USER_DB(self):
        return "users"

    @property
    def TEST_USER_DB(self):
        return "test_users"

    @property
    def PROD_CODE_INTERPRETER_AZURE_FUNCTION_NAME(self):
        return "https://youagent-azure-fn.azurewebsites.net/api/codeinterpreter"

    @property
    def TEST_CODE_INTERPRETER_AZURE_FUNCTION_NAME(self):
        return "https://stg-youagent-azure-fn.azurewebsites.net/api/codeinterpreter"

    @property
    def PROD_WEB_SCRAPER_AZURE_FUNCTION_URL(self):
        return "https://prod-livescraper-azure-fn.azurewebsites.net/api"

    @property
    def TEST_WEB_SCRAPER_AZURE_FUNCTION_URL(self):
        return "https://stg-livescraper-azure-fn.azurewebsites.net/api"

    @property
    def TEST_LINK_SHARING_DB(self):
        return "test_shareable_links"

    @property
    def LINK_SHARING_DB(self):
        return "shareable_links"

    @property
    def TEST_CHAT_HISTORY_DB(self):
        return "test_chat_history"

    @property
    def CHAT_HISTORY_DB(self):
        return "chat_history"

    @property
    def TEST_CUSTOM_ASSISTANTS_DB(self):
        return "test_user_chat_modes"

    @property
    def CUSTOM_ASSISTANTS_DB(self):
        return "user_chat_modes"

    @property
    def TEST_EXPLORE_PAGE_DB(self):
        return "test_explore_page"

    @property
    def EXPLORE_PAGE_DB(self):
        return "explore_page"

    @property
    def ORGANZATION_TEAMS_DB(self):
        return "organzation_teams"

    @property
    def TEST_ORGANIZATION_DB(self):
        return "test_organization"

    @property
    def ORGANIZATION_DB(self):
        return "organization"

    @property
    def AUTHORIZATION_DB(self):
        return "authorization"

    @property
    def QUERY_ANNOTATION_DB(self):
        return "query_annotation_dataset"

    @property
    def STYTCH_DFB_DB(self):
        return "stytch_dfp"

    @property
    def WHATSAPP_PROMOTIONAL_MESSAGE_USERS_PHONE_NUMBER_DB(
        self,
    ):
        return "whatapp_promotional_message_users_phone_number"

    @property
    def MONGO_DATABASES(self):
        return [
            "categories",
            "metrics",
            "events",
            "stores",
            "data_extraction_analytics",
            "search_service_data_dumps",
            "synthetic_dataset",
            self.ONTOLOGY_DB,
            self.USER_DB,
            self.TEST_USER_DB,
            self.CACHE_DB,
            self.TEST_LINK_SHARING_DB,
            self.LINK_SHARING_DB,
            self.QUERY_ANNOTATION_DB,
            self.RATE_LIMIT_DB,
            self.TEST_CHAT_HISTORY_DB,
            self.CHAT_HISTORY_DB,
            self.TEST_CUSTOM_ASSISTANTS_DB,
            self.CUSTOM_ASSISTANTS_DB,
            self.TEST_EXPLORE_PAGE_DB,
            self.EXPLORE_PAGE_DB,
            self.STYTCH_DFB_DB,
        ]

    @property
    def CACHE_DB(self):
        return "api_cache"

    @property
    def RATE_LIMIT_DB(self):
        return "rate_limit"

    @property
    def METRICS_DB(self):
        return "metrics"

    @property
    def PRODUCT_GRAPH_METRICS_COLLECTION(self):
        return "product_graph"

    @property
    def SEARCH_CRAWLS_DB(self):
        """
        Names of both Mongo > Reviews collections
        """
        return "crawl_search"

    @property
    def SEARCH_CRAWLS_HREF_COLLECTION(self):
        """
        Names of both Mongo > Reviews collections
        """
        return "href_links_prod"

    @property
    def SEARCH_CRAWLS_GOOGLE_COLLECTION(self):
        """
        Names of both Mongo > Reviews collections
        """
        return "google_search_prod"

    @property
    def LINKS_COLLECTION(self):
        """
        Names of both Mongo > Reviews collections
        """
        return "links"

    @property
    def SEARCH_CRAWLS_SHOPIFY_COLLECTION(self):
        """
        Names of both Mongo > Reviews collections
        """
        return "shopify_search_prod"

    @property
    def APP_ELASTIC_SEARCH_IP_ADDRESS(self):
        return os.getenv("ES_HOST")

    @property
    def PRODUCTS_COLLECTIONS(self):
        """
        Names of both Mongo > Reviews collections
        """
        return [
            "amazon_prod",
            "walmart_prod2",
            "bestbuy_prod",
            "target_prod",
            "ikea_prod",
            "home_depot_prod",
            "shopify_prod",
        ]

    @property
    def USER_DBS(self):
        return ["users"]

    @property
    def EDITORIAL_REVIEWS_DB(self):
        """
        Names of editorial sources used to map to CosmosSources -- mongo collections
        """
        return [
            "theverge",
            "gearlab",
            "wirecutter",
            "tomsguide",
            "bestreviews",
            "cnet2",
            "pcmag",
        ]

    @property
    def USER_REVIEWS_DB(self):
        return [
            "amazon_prod",
            "target_prod",
            "walmart_prod2",
            "ikea_prod",
            "home_depot_prod2",
        ]

    @property  # TODO: delete this later once we fix normalizeType and normalizeSource
    def USER_REVIEWS_SOURCES(self):
        return [
            "amazon_review",
            "target_review",
            "walmart_review",
            "ikea_review",
            "home_depot_review",
        ]

    @property
    def EDITORIAL_REVIEWS_ES(self):
        """
        Names of editorial reviews indices in elastic search
        """
        return [
            "thevergereviews",
            "gearlabreviews",
            "wirecutterreviews",
            "tomsguide",
            "bestreviews",
            "cnetreviews2",
            "pcmagreviews",
        ]

    @property
    def PRODUCT_SOURCES(self):
        """
        Collection names in the products databases
        """
        return [
            "amazon_prod",
            "walmart_prod2",
            "target_prod",
            "bestbuy_prod",
            "besthomeoffice_prod",
            "ikea_prod",
            "home_depot_prod",
            "shopify_prod",
        ]

    @property
    def ETHICS_REVEWS_ES(self):
        return [
            "good_shopping_prod",
            "ethical_guide_prod",
            "ethical_consumer_prod",
            "csr_hub",
        ]

    @property
    def CNET_ES_INDEX(self):
        """
        Names of amazon ES
        """
        return "cnetreviews2"

    @property
    def AMAZON_ES_INDEX(self):
        """
        Names of amazon ES
        """
        return "amazonproducts6"

    @property
    def BESTBUY_ES_INDEX(self):
        """
        Names of bestbuy ES
        """
        return "bestbuyproducts6"

    @property
    def SHOPIFY_ES_INDEX(self):
        return "shopifyproducts3"

    @property
    def TARGET_ES_INDEX(self):
        """
        Names of target ES
        """
        return "targetproducts6"

    @property
    def IKEA_ES_INDEX(self):
        """
        Names of target ES
        """
        return "ikeaproducts6"

    @property
    def HOME_DEPOT_ES_INDEX(self):
        """
        Names of target ES
        """
        return "homedepotproducts6"

    @property
    def WALMART_ES_INDEX(self):
        """
        Names of target ES
        """
        return "walmartproducts7"

    @property
    def BESTHOMEOFFICE_ES_INDEX(self):
        """
        Names of target ES
        """
        return "besthomeoffice_prod1"

    @property
    def ES_INDEX_NAMES(self):
        """
        Names of elastic search product indices
        """
        return [
            self.WALMART_ES_INDEX,
            self.IKEA_ES_INDEX,
            self.TARGET_ES_INDEX,
            self.AMAZON_ES_INDEX,
            self.BESTBUY_ES_INDEX,
            self.HOME_DEPOT_ES_INDEX,
            self.BESTHOMEOFFICE_ES_INDEX,
        ]

    @property
    def ONTOLOGY_DB(self):
        return "ontologies"

    @property
    def QUERY_TO_ONTOLOGY(self):
        return "query_to_ontology"

    @property
    def REDIS_TOOL_CALL_DB(self):
        return 0

    @property
    def REDIS_SEARCH_RESULTS_DB(self):
        return 1

    @property
    def REDIS_USER_PREFERENCES_DB(self):
        return 2

    @property
    def REDIS_YOUCHAT_STORAGE_DB(self):
        return 4

    @property
    def REDIS_USER_APP_PREFERENCES_DB(self):
        return 5

    @property
    def REDIS_USER_SUBSCRIPTIONS_DB(self):
        return 6

    @property
    def TEST_REDIS_YOUCHAT_STORAGE_DB(self):
        return 7

    @property
    def REDIS_PREVIEW_LINK(self):
        return 8

    @property
    def REDIS_USER_API_REQUEST_DB(self):
        return 9

    @property
    def REDIS_EMBEDDING_DB(self):
        return 10

    @property
    def REDIS_MODEL_ACTION_SERVICE(self):
        return 13

    @property
    def REDIS_RANKING_DEGRADATION_DB(self):
        return 14

    @property
    def REDIS_QUICK_ANSWER_DB(self):
        return 15

    # Redis key expires after 30 seconds
    @property
    def REDIS_KEY_EXPIRES_30SECONDS(self):
        return 30

    # Redis key expires after 5 minutes
    @property
    def REDIS_KEY_EXPIRES_5MINUTES(self):
        return 60 * 5

    # Redis key expires after 15 min
    @property
    def REDIS_KEY_EXPIRES_15MINUTES(self):
        return 60 * 15

    # Redis key expires after 1 hour
    @property
    def REDIS_KEY_EXPIRES_1HOUR(self):
        return 60 * 60

    # Redis key expires after 3 hours
    @property
    def REDIS_KEY_EXPIRES_3HOURS(self):
        return 60 * 60 * 3

    # Redis key expires after 1 day
    @property
    def REDIS_KEY_EXPIRES_1DAY(self):
        return 60 * 60 * 24

    # Redis key expires after 1 week
    @property
    def REDIS_KEY_EXPIRES_1WEEK(self):
        return 60 * 60 * 24 * 7

    # Redis key expires after 1 month
    @property
    def REDIS_KEY_EXPIRES_1MONTH(self):
        return 60 * 60 * 24 * 30

    # Redis key expires after 3 months
    @property
    def REDIS_KEY_EXPIRES_3MONTHS(self):
        return 60 * 60 * 24 * 30 * 3

    # Redis key expires after 1 year
    @property
    def REDIS_KEY_EXPIRES_1YEAR(self):
        return 60 * 60 * 24 * 365

    @property
    def RETRIEVAL_DIVERSITY(self):
        """
        arguments used in construction of an Search.Aggregators.Diversification.BasicProductDiversifier() instances
        Basically means that (if RETRIEVAL_DIVERSITY=0.75) that no product can have a title that has 75% of the words that have already been added to a list of kept candidate products,
        or else it will be removed.
        """
        return 0.6

    @property
    def RANKING_DIVERSITY(self):
        """
        arguments used in construction of an Search.Aggregators.Diversification.BasicProductDiversifier() instances
        Basically means that (if RANKING_DIVERSITY=0.75) that no product can have a title that has 75% of the words that have already been added to a list of post-ranked products,
        or else it will be removed.
        """
        return 0.6

    @property
    def YOU_ID(self):
        """
        you_id database
        """
        return "you_id"

    @property
    def SAMPLE_PROJECTS_USER_IDS(self):
        # sample projects are under <user_name>+projects@you.com account
        # following are the descope user ids on staging and production

        shiv_user_id = (
            "U2pSE56F78ZQc6WIgiWzFUtcqaro"
            if env.is_prod()
            else "U2pSCys7KXAvPn1lNLYpv0RJyaP9"
        )

        charles_user_id = "U2pj4BpSkr6LApP8Y9LQ7JXXB2T6" if env.is_prod() else None

        nana_user_id = None

        return [
            item
            for item in [shiv_user_id, charles_user_id, nana_user_id]
            if item is not None
        ]

    @property
    def UID_TO_WTB_COLLECTION(self):
        return "uid_to_wtb2"

    @property
    def PID_TO_UID_COLLECTION(self):
        return "pidsource_to_uid2"

    @property
    def HOST_FOR_EMBEDDINGS(self):
        return "http://40.91.120.172:6001/embed"
