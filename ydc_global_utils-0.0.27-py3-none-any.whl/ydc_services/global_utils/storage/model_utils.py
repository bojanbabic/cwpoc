from datetime import datetime, timezone
from typing import Optional

import inflection
from bson import ObjectId
from pydantic import BaseModel, model_validator


class PydanticMongoDocument(BaseModel):
    id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def to_mongo(
        self,
        is_update_call=True,
        include: Optional[list[str]] = None,
        exclude: Optional[list[str]] = None,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        exclude_none: bool = False,
    ):
        current_time = datetime.now(timezone.utc)
        if not is_update_call:
            self.created_at = current_time
        self.updated_at = current_time

        return self.model_dump(
            include=set(include) if isinstance(include, list) else include,
            exclude=set(exclude) if isinstance(exclude, list) else exclude,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            exclude_none=exclude_none,
        )

    @model_validator(mode="before")
    @classmethod
    def parse_mongo_object_id(cls, data):
        if isinstance(data, dict):
            if "_id" in data and isinstance(data["_id"], ObjectId):
                data["id"] = str(data.get("_id"))
        return data


class GenericJsonApiMixin:
    def to_json_api_data(
        self,
        type: Optional[str] = None,
        primary_key: str = "id",
        attributes: Optional[list[str]] = None,
    ):
        primary_key_value = self.__getattribute__(primary_key)

        response_datum = {}
        response_datum["id"] = primary_key_value
        response_datum["type"] = (
            type
            if type
            else inflection.pluralize(inflection.underscore(self.__class__.__name__))
        )

        instance_attributes = {}
        if attributes:
            instance_attributes = dict(
                [(field, self.__getattribute__(field)) for field in attributes]
            )
        else:
            instance_attributes = self.__dict__

        for k, v in instance_attributes.items():
            if isinstance(v, datetime):
                instance_attributes[k] = v.isoformat(timespec="seconds")

        response_datum["attributes"] = instance_attributes

        return response_datum
