import logging
from abc import ABC, abstractmethod

import redis

from config.config import redis as redis_config
from ydc_services.global_utils.env import Env

logger = logging.getLogger(__name__)
env = Env()


class RedisUnavailableError(Exception):
    """
    Thrown when Redis cannot be reached
    """


class IRedisClient(ABC):
    @abstractmethod
    def get(self, key: str):
        ...

    @abstractmethod
    def set(self, key: str, value: str) -> bool:
        ...

    @abstractmethod
    def delete(self, keys: list[str]) -> bool:
        ...

    @abstractmethod
    def incr(self, key: str, amount: int) -> int:
        ...


class MockRedisClient(IRedisClient):
    """
    A Mock RedisClient Class for unittest usage
    with only four basic methods of Redis that we are using (get, set, delete, incr)
    """

    def __init__(self):
        self.cache = {}
        self.expire_times = {}

    def get(self, key: str):
        value = self.cache.get(key)
        # Redis only returns strings, so we simulate that behavior
        if value and not isinstance(value, str):
            value = str(value)
        return value

    def set(self, key: str, value: str, expire_time: int = None) -> bool:
        # allow key-specific expiration (different than general cache)
        if expire_time:
            self.expire_times[key] = expire_time
        self.cache[key] = value
        return True

    def delete(self, keys: list[str]) -> int:
        deleted_count = 0
        for key in keys:
            if key in self.cache:
                del self.cache[key]
                deleted_count += 1
        return deleted_count

    def incr(self, key: str, amount: int) -> int:
        if key in self.cache:
            self.cache[key] += amount
        else:
            self.cache[key] = amount
        return self.cache[key]


class RedisClient(IRedisClient):
    def __init__(
        self,
        db,
        cache_expires=None,
        host=None,
        password=None,
        socket_timeout=None,
        ssl=None,
    ):
        assert isinstance(db, int) and db >= 0 and db < 16, "Invalid Redis DB"

        host = host if isinstance(host, str) else redis_config.main.host
        loaded_password = (
            password if isinstance(password, str) else redis_config.main.password
        )
        password = (
            loaded_password
            if loaded_password is not None and len(loaded_password) > 3
            else None
        )
        port = redis_config.main.port
        ssl = ssl if isinstance(ssl, bool) else redis_config.main.ssl
        self.cache_expires = cache_expires
        self.redis = redis.StrictRedis(
            host=host,
            port=port,
            password=password,
            ssl=ssl,
            # If we set timeout on redis, we should not retry on timeout to avoid long wait
            retry_on_timeout=True if socket_timeout is None else False,
            decode_responses=True,
            db=db,
            socket_timeout=socket_timeout,
        )
        self.ENCODING = "utf-8"

    @staticmethod
    def handle_error(action):
        """
        Catch and reraise any error thrown by Redis. redis-py will attempt to retry
        connections on timeout so errors thrown here are likely very fatal.
        """
        try:
            return action()
        except Exception as e:
            logger.error("Redis error", exc_info=e)
            raise RedisUnavailableError(e) from e

    def zadd(self, key: str, values: list) -> bool:
        def zadd_impl() -> bool:
            result = self.redis.zadd(key, {k: v for v, k in enumerate(values)})
            if self.cache_expires:
                self.redis.expire(key, self.cache_expires)
            return result

        return RedisClient.handle_error(zadd_impl)

    def get(self, key: str) -> str:
        def get_impl():
            result = self.redis.get(key)
            return result

        return RedisClient.handle_error(get_impl)

    def set(self, key: str, values: str, expire_time: int = None) -> bool:
        def set_impl():
            result = self.redis.set(key, values)
            # allow key-specific expiration (different than general cache)
            if expire_time:
                self.redis.expire(key, expire_time)
            elif self.cache_expires:
                self.redis.expire(key, self.cache_expires)
            return result

        return RedisClient.handle_error(set_impl)

    def delete(self, keys: list[str]) -> int:
        def delete_impl():
            return self.redis.delete(*keys)

        return RedisClient.handle_error(delete_impl)

    def incr(self, key: str, amount: int) -> int:
        def incr_impl():
            result = self.redis.incr(key, amount)
            if self.cache_expires:
                self.redis.expire(key, self.cache_expires)
            return result

        return RedisClient.handle_error(incr_impl)

    def zrange(self, key: str, offset: int, width: int) -> list:
        start = max(offset, 0)
        # redis range is inclusive
        end = max(start + max(width, 0) - 1, 0)

        def zrange_impl() -> list:
            return [str(v, self.ENCODING) for v in self.redis.zrange(key, start, end)]

        return RedisClient.handle_error(zrange_impl)

    def has(self, key: str) -> bool:
        return RedisClient.handle_error(lambda: self.redis.exists(key))

    def mget(self, keys: list) -> list:
        return RedisClient.handle_error(lambda: [str(x) for x in self.redis.mget(keys)])

    def mset(self, keys: list, expire_time: float = None) -> bool:
        def mset_impl() -> list:
            self.redis.mset(keys)
            if expire_time:
                for k in keys:  ### this is very slow if you have a lot of keys
                    self.redis.expire(k, expire_time)
            return True

        return RedisClient.handle_error(mset_impl)

    def sadd(self, key: str, set_values: set) -> bool:
        def sadd_impl() -> bool:
            self.redis.sadd(key, *set_values)
            if self.cache_expires:
                self.redis.expire(key, self.cache_expires)
            return True

        return RedisClient.handle_error(sadd_impl)

    def smembers(self, key: str) -> list:
        def smembers_impl() -> list:
            return self.redis.smembers(key)

        return RedisClient.handle_error(smembers_impl)

    def srem(self, key: str, set_values: set) -> bool:
        def srem_impl() -> bool:
            return self.redis.srem(key, *set_values)

        return RedisClient.handle_error(srem_impl)

    def scard(self, key: str) -> int:
        def scard_impl() -> int:
            return self.redis.scard(key)

        return RedisClient.handle_error(scard_impl)
