class cls_inst_method:
    """
    A decorator that allows a method to be called as either a class method or an instance method
    while preserving self and cls values.
    """

    def __init__(self, func):
        self.func = func

    def __get__(self, instance, owner):
        def wrapper(*args, **kwargs):
            return self.func(instance, owner, *args, **kwargs)

        return wrapper
