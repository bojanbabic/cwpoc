import datetime

from mongoengine import BooleanField, DateTimeField


class HiddenMixin:
    hidden = BooleanField(default=False)
    hidden_at = DateTimeField()

    def hide(self):
        self.hidden = True
        self.hidden_at = datetime.datetime.now(datetime.timezone.utc)
        self.save()
