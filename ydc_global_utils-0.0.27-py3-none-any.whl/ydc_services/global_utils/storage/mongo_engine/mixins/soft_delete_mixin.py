import datetime

from mongoengine import BooleanField, DateTimeField


class SoftDeleteMixin:
    soft_deleted = BooleanField(default=False)
    soft_deleted_at = DateTimeField()

    def soft_delete(self):
        self.soft_deleted = True
        self.soft_deleted_at = datetime.datetime.now(datetime.timezone.utc)
        self.save()
