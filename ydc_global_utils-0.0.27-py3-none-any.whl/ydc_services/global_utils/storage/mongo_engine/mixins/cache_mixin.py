import logging
import pickle
from typing import Any, Callable, Optional

import redis  # type: ignore

from config.config import redis as redis_config
from ydc_services.global_utils.storage.constants import Constants
from ydc_services.global_utils.storage.mongo_engine.mixins.decorators import (
    cls_inst_method,
)

logger = logging.getLogger(__package__)

REDIS_TIMEOUT = 1

cache_store = redis.StrictRedis(
    host=redis_config.main.host or "localhost",
    port=redis_config.main.port or 6380,
    password=redis_config.main.password
    if redis_config.main.password and len(redis_config.main.password) >= 3
    else None,
    ssl=True,
    retry_on_timeout=False,
    decode_responses=False,
    db=Constants().REDIS_YOUCHAT_STORAGE_DB,
    socket_timeout=REDIS_TIMEOUT,
)


class CacheMixin:
    @cls_inst_method
    def _compute_cache_key(self, cls, cache_key: Optional[str] = None) -> str:
        prefix = cls.__name__.lower()
        if self and not cache_key:
            if (
                hasattr(cls, "_meta")
                and getattr(cls, "_meta").get("cache_key")
                and hasattr(cls, getattr(cls, "_meta").get("cache_key"))
            ):
                cache_key = getattr(self, getattr(self, "_meta").get("cache_key"))
            else:
                cache_key = str(self.id)  # type: ignore

        if not cache_key:
            raise ValueError(
                "`cache_key` computes to None, check if the object being cached has a valid value for `cache_key`"
            )

        # `me` stands for mongoengine
        logger.debug("cache_key", cache_key=f"me:{prefix}:{cache_key}")
        return f"me:{prefix}:{cache_key}"

    @classmethod
    def _get_cache_key(cls, self, cache_key: Optional[str] = None) -> str:
        return (
            self._compute_cache_key(cache_key)
            if self
            else cls._compute_cache_key(cache_key)
        )

    @cls_inst_method
    def get_cache(
        self,
        cls,
        cache_key: Optional[str] = None,
        set_cache_fn: Optional[Callable] = None,
        cache_ttl: int = 5 * 60,
    ) -> Any:
        _cache_key = cls._get_cache_key(self, cache_key)
        cached_value = cache_store.get(_cache_key)

        if cached_value:
            value = pickle.loads(cached_value)
            logger.debug("get_cache", cache_key=_cache_key, value=value)
            return value
        elif set_cache_fn:
            value = set_cache_fn()
            logger.debug("get_cache", cache_key=_cache_key, value=value)
            cls.set_cache(value, cache_key, cache_ttl)
            return value
        else:
            return None

    @cls_inst_method
    def set_cache(
        self,
        cls,
        value: Any,
        cache_key: Optional[str] = None,
        cache_ttl: int = 5 * 60,
    ) -> None:
        _cache_key = cls._get_cache_key(self, cache_key)
        logger.debug("set_cache", cache_key=_cache_key, value=value)
        cache_store.set(_cache_key, pickle.dumps(value), ex=cache_ttl)

    @cls_inst_method
    def clear_cache(self, cls, cache_key: Optional[str] = None) -> None:
        _cache_key = cls._get_cache_key(self, cache_key)
        logger.debug("clear_cache", cache_key=_cache_key)
        cache_store.delete(_cache_key)
