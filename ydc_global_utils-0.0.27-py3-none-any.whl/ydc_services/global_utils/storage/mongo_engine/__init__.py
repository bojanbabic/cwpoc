from mongoengine import connect

from config.config import mongodb
from ydc_services.global_utils.env import Env

from .base_document import BaseDocument
from .legacy_document import LegacyDocument

DEFAULT_TIMEOUT_MS = 5000

env = Env()

if env.is_testing():
    connect(
        alias="mongodb-atlas-chat-history",
        db="test_chat_history",
        host=mongodb.main.connection_string,
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="cosmosdb-chat-history",
        db="test_chat_history",
        host=mongodb.main_legacy.connection_string,
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-users",
        db="test_users",
        host=mongodb.main.connection_string,
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-rag-files",
        db="test_files",
        host=mongodb.main.connection_string,
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )

elif env.is_local():
    connect(
        alias="mongodb-atlas-chat-history",
        host=mongodb.main.connection_string,
        db="test_chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="cosmosdb-chat-history",
        host=mongodb.main_legacy.connection_string,
        db="test_chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-users",
        host=mongodb.main.connection_string,
        db="test_users",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-rag-files",
        host=mongodb.main.connection_string,
        db="test_files",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )

elif env.is_staging():
    connect(
        alias="mongodb-atlas-chat-history",
        host=mongodb.main.connection_string,
        db="test_chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="cosmosdb-chat-history",
        host=mongodb.main_legacy.connection_string,
        db="test_chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-users",
        host=mongodb.main.connection_string,
        db="test_users",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-rag-files",
        host=mongodb.main.connection_string,
        db="test_files",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )

elif env.is_prod():
    connect(
        alias="mongodb-atlas-chat-history",
        host=mongodb.main.connection_string,
        db="chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="cosmosdb-chat-history",
        host=mongodb.main_legacy.connection_string,
        db="chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-users",
        host=mongodb.main.connection_string,
        db="users",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-rag-files",
        host=mongodb.main.connection_string,
        db="files",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )

else:
    raise ValueError(f"Invalid environment: {env.get_env()}")

__all__ = ["BaseDocument", "LegacyDocument"]
