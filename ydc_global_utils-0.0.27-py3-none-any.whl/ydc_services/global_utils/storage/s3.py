import logging
import os
from typing import NoReturn, Optional, Set

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


S3_CLIENT_CONFIG = Config(retries={"max_attempts": 5, "mode": "standard"})

# Type aliases to give callers more information on the errors if they need it
BadDigestError = ValueError
BucketNotFoundError = ValueError
ObjectNotFoundError = ValueError
AccessDeniedError = ValueError


def upload(
    bucket: str,
    content: bytes,
    object_key: str,
    content_type: str,
    region: str = "us-east-1",
    checksum: Optional[str] = None,
) -> Optional[str]:
    """
    Upload object to S3. Caller is responsible for creating the object key in the format/path that suits their needs.

    Args:
        bucket: Bucket where the content should go; client is responsible for ensuring bucket exists
        content: Content to upload; for example, encrypted file content
        object_key: Name of the object to store in S3
        content_type: MIME type of the content
        region: AWS region the bucket is in; defaults to us-east-1
        checksum: Optional base64 SHA256 checksum if caller wants S3 to perform integrity check

    Returns:
        Optional[str]: SHA256 checksum of uploaded content if checksum was specified; None otherwise

    Raises:
        BucketNotFoundError: Specified bucket does not exist
        BadDigestError: If checksum specified and there's a mismatch
        Exception: Bubbles up any other exceptions from AWS
    """
    try:
        # S3 document recommends creating a new client each time as it isn't thread safe
        # https://boto3.amazonaws.com/v1/documentation/api/latest/guide/resources.html#multithreading-or-multiprocessing-with-resources
        s3_client = boto3.client(
            "s3",
            aws_access_key_id=os.getenv("S3_ACCESS_KEY"),
            aws_secret_access_key=os.getenv("S3_SECRET_KEY"),
            region_name=region,
            config=S3_CLIENT_CONFIG,
        )

        if checksum:
            response = s3_client.put_object(
                Bucket=bucket,
                Key=object_key,
                Body=content,
                ContentType=content_type,
                ChecksumAlgorithm="SHA256",
                ChecksumSHA256=checksum,
            )
        else:
            response = s3_client.put_object(
                Bucket=bucket,
                Key=object_key,
                Body=content,
                ContentType=content_type,
            )

        logger.info(
            "Successfully uploaded to S3",
            object_key=object_key,
            bucket=bucket,
            content_type=content_type,
        )

        return response.get("ChecksumSHA256")
    except ClientError as e:
        _handle_client_error(e, bucket, object_key=object_key, checksum=checksum)
    except Exception as e:
        logger.error(
            "Unexpected error uploading to S3",
            bucket=bucket,
            object_key=object_key,
            content_type=content_type,
            exc_info=e,
        )
        raise
    finally:
        s3_client.close()


def bucket_exists(bucket: str) -> bool:
    """
    Check the bucket exists and is accessible in S3.

    Args:
        bucket: Name of the S3 bucket

    Returns:
        bool: True if bucket exists

    Raises:
        AccessDeniedError: Bucket either does not exist or no permission to access
        Exception: Bubbles up any other exceptions from AWS
    """
    try:
        s3_client = boto3.client(
            "s3",
            aws_access_key_id=os.getenv("S3_ACCESS_KEY"),
            aws_secret_access_key=os.getenv("S3_SECRET_KEY"),
            config=S3_CLIENT_CONFIG,
        )

        # Check if bucket exists
        logger.info("Checking if bucket exists", bucket=bucket)
        s3_client.head_bucket(Bucket=bucket)
        return True
    except ClientError as e:
        _handle_client_error(e, bucket=bucket)
    except Exception as e:
        logger.error("Unexpected error checking for bucket", bucket=bucket, exc_info=e)
        raise e
    finally:
        s3_client.close()


def download(
    bucket: str,
    object_key: str,
) -> bytes:
    """
    Download specified object from S3

    Args:
        bucket: Name of the S3 bucket
        object_key: Name of the object to download

    Returns:
        bytes: Object content

    Raises:
        AccessDeniedError: Specified bucket does not exist or no permission to access
        ObjectNotFoundError: Specified object_key not found
        Exception: Bubbles up any other exceptions from AWS

    """
    try:
        s3_client = boto3.client(
            "s3",
            aws_access_key_id=os.getenv("S3_ACCESS_KEY"),
            aws_secret_access_key=os.getenv("S3_SECRET_KEY"),
            config=S3_CLIENT_CONFIG,
        )

        # Download the object
        response = s3_client.get_object(Bucket=bucket, Key=object_key)
        content = response["Body"].read()

        logger.info(
            "Successfully downloaded from S3",
            bucket=bucket,
            object_key=object_key,
        )
        return content
    except ClientError as e:
        _handle_client_error(e, bucket, object_key=object_key)
    except Exception as e:
        logger.error(
            "Unexpected error downloading from S3",
            bucket=bucket,
            object_key=object_key,
            exc_info=e,
        )
        raise
    finally:
        s3_client.close()


def delete(bucket: str, object_keys: Set[str]) -> int:
    """
    Delete specified object_keys from S3

    Args:
        bucket: Name of the S3 bucket
        object_keys: Keys of the objects to delete

    Returns:
        int: Number of successfully deleted object

    Raises:
        Exception: Bubbles up any exception from AWS

    """
    num_objects_to_delete = len(object_keys)
    if num_objects_to_delete <= 0:
        raise ValueError("Must specify at least 1 object to delete")
    try:
        s3_client = boto3.client(
            "s3",
            aws_access_key_id=os.getenv("S3_ACCESS_KEY"),
            aws_secret_access_key=os.getenv("S3_SECRET_KEY"),
            config=S3_CLIENT_CONFIG,
        )

        response = s3_client.delete_objects(
            Bucket=bucket,
            Delete={"Objects": [{"Key": obj_key} for obj_key in object_keys]},
        )
        deleted_objs = {obj.get("Key", "") for obj in response.get("Deleted", [])}
        logger.info(
            "Successfully deleted from S3",
            bucket=bucket,
            object_keys=deleted_objs,
        )

        # boto's delete_objects do not throw exception but instead return the Errors property as part of the response
        failed_objs = [
            {"Key": obj.get("Key"), "Message": obj.get("Message")}
            for obj in response.get("Errors", [])
        ]
        if failed_objs:
            logger.error("Failed to delete from S3", bucket=bucket, objects=failed_objs)

        return len(deleted_objs)
    except Exception as e:
        logger.error(
            "Unexpected error deleting from S3",
            bucket=bucket,
            object_keys=object_keys,
            exc_info=e,
        )
        raise
    finally:
        s3_client.close()


def _handle_client_error(
    e: ClientError,
    bucket: str,
    object_key: Optional[str] = None,
    checksum: Optional[str] = None,
) -> NoReturn:
    error_obj = e.response.get("Error", {})
    match error_obj.get("Code"):
        case "NoSuchKey":
            logger.error(
                "Object not found in S3",
                bucket=bucket,
                object_key=object_key,
                exc_info=e,
            )
            raise ObjectNotFoundError(
                error_obj.get(
                    "Message", "Invalid object_key. Not found in provided bucket"
                )
            )
        case "NoSuchBucket" | "403":
            logger.error(
                "Bucket not found in S3",
                bucket=bucket,
                aws_bucket=error_obj.get("BucketName"),
                exc_info=e,
            )
            raise BucketNotFoundError(
                error_obj.get("Message", "Bucket not found in S3")
            )
        case "BadDigest":
            logger.error(
                "Checksum mismatched",
                bucket=bucket,
                object_key=object_key,
                checksum=checksum,
                exc_info=e,
            )
            raise BadDigestError(error_obj.get("Message", "Checksum mismatched"))
        case "AccessDenied" | "404":
            logger.error(
                "Access denied", bucket=bucket, object_key=object_key, exc_info=e
            )
            raise AccessDeniedError(
                "Access denied to resource or resource does not exist"
            )
        case _:
            logger.error(
                "Unexpected ClientError from S3",
                bucket=bucket,
                object_key=object_key,
                exc_info=e,
            )
            raise e
