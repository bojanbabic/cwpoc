import boto3

# This assumes the default profile can access s3 without access keys
# Currently using the GhaInfraEC2Role
# (https://us-east-1.console.aws.amazon.com/iam/home?region=us-east-1#/roles/details/GhaInfraEC2Role)


def download_object_to_file(fname, key, bucket_name):
    s3_client = boto3.client("s3")
    try:
        r = s3_client.get_object(Bucket=bucket_name, Key=key)
        if "ResponseMetadata" in r and r.get("ResponseMetadata").get(
            "HTTPStatusCode"
        ) in [200]:
            body = r.get("Body")
            with open(fname, "wb") as output:
                output.write(body.read())
            return
        raise Exception(f"Failed to download the file: {r}")
    except Exception as e:
        raise e
