import warnings
from typing import Literal, Optional

import mongomock
import pymongo
import pymongo.database

from config.config import mongodb
from ydc_services.global_utils.env import Env
from ydc_services.global_utils.storage.constants import Constants

env = Env()
warnings.filterwarnings(
    "ignore",
    category=UserWarning,
    message="You appear to be connected to a CosmosDB cluster. For more information regarding feature compatibility and support please visit https://www.mongodb.com/supportability/cosmosdb",
)


class MongoClientPool:
    client_pool: dict[str, pymongo.MongoClient] = {}

    @classmethod
    def get_client(cls, connection_string: str) -> pymongo.MongoClient:
        if connection_string not in cls.client_pool:
            cls.client_pool[connection_string] = pymongo.MongoClient(connection_string)
        return cls.client_pool[connection_string]


class CosmosDao:
    """
    it is preferable to initialize CosmosDao with a collection or else you will have to specify it
    as "source" in every database function below...
    """

    def __init__(
        self,
        name="api_cache",
        collection="",
        connection_string=None,
        filter=None,
    ):
        # Define constants
        self.db_name = name
        self.constants = Constants()
        if filter is None:
            self.filter = {}
        else:
            self.filter = filter

        if connection_string:
            self.connection_string = connection_string
        elif hasattr(mongodb, "main_legacy") and hasattr(
            mongodb.main_legacy, "connection_string"
        ):
            self.connection_string = mongodb.main_legacy.connection_string
        else:
            raise ValueError("MongoDB connection string not found in the environment")

        if not any([name in n for n in self.constants.MONGO_DATABASES]):
            exit("invalid database name")

        client = MongoClientPool.get_client(self.connection_string)
        self.db = client[self.db_name]
        self.collection = collection  ### if this is set, iterator will use this

        self.sources = (
            self.constants.USER_REVIEWS_SOURCES
            + self.constants.PRODUCT_SOURCES
            + self.constants.EDITORIAL_REVIEWS_DB
            + self.constants.USER_DBS
        )


class PyMongoClient:
    def __init__(
        self,
        db_name: str,
        staging_db_name: Optional[str] = None,
        connection_string: Optional[str] = None,
        platform: Literal["cosmos", "atlas"] = "atlas",
        is_testing: bool = False,
    ):
        if is_testing:
            self.db = mongomock.MongoClient().db.collection  # type: ignore
            return

        if connection_string:
            self.connection_string = connection_string
        elif platform == "atlas":
            self.connection_string = mongodb.main.connection_string
        elif hasattr(mongodb, "main_legacy") and hasattr(
            mongodb.main_legacy, "connection_string"
        ):
            self.connection_string = mongodb.main_legacy.connection_string
        else:
            raise ValueError("MongoDB connection string not found in the environment")

        if env.is_prod():
            self.db_name = db_name
        else:
            self.db_name = staging_db_name or db_name

        client = MongoClientPool.get_client(self.connection_string)
        self.db = client[self.db_name]  # type: ignore

    def get_collection(self, collection: str):
        return self.db[collection]

    def test(self):
        self.db["collection"].find
