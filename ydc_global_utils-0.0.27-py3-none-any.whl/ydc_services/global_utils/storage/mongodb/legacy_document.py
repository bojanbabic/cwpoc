from mongoengine import Document

from ydc_services.global_utils.storage.mongodb.mixins.json_api_mixin import (
    JsonApiMixin,
)


class LegacyDocument(Document, JsonApiMixin):
    """A base class for all legacy documents.

    This class is used to create an ORM class for existing MongoDB collections.

    If you are creating a whole new collection, you should inherit from BaseDocument.
    """

    meta = {"abstract": True}
