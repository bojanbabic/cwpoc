import os

from mongoengine import connect

from ydc_services.global_utils.env import Env

from .base_document import BaseDocument
from .legacy_document import LegacyDocument

MONGODB_ATLAS_CONNECTION_STRING = os.environ.get("MONGODB_ATLAS_CONNECTION_STRING", "")
STAGING_COSMOS_DB_CONNECTION_STR = os.environ.get("STAGING_DB_CONNECTION_STR", "")
PROD_COSMOS_DB_CONNECTION_STR = os.environ.get("PROD_DB_CONNECTION_STR", "")
DEFAULT_TIMEOUT_MS = 5000

env = Env()

# testing
if env.is_testing():
    import mongomock

    defaults = {
        "host": "mongodb://localhost",
        "mongo_client_class": mongomock.MongoClient,
        "timeoutMS": DEFAULT_TIMEOUT_MS,
    }

    connect(
        alias="mongodb-atlas-chat-history",
        db="test_chat_history",
        **defaults,
    )
    connect(
        alias="cosmosdb-chat-history",
        db="test_chat_history",
        **defaults,
    )
    connect(
        alias="mongodb-atlas-users",
        db="test_users",
        **defaults,
    )

# local, staging
elif env.is_local() or env.is_staging():
    connect(
        alias="mongodb-atlas-chat-history",
        host=MONGODB_ATLAS_CONNECTION_STRING,
        db="test_chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="cosmosdb-chat-history",
        host=STAGING_COSMOS_DB_CONNECTION_STR,
        db="test_chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-users",
        host=MONGODB_ATLAS_CONNECTION_STRING,
        db="test_users",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )

# production
elif env.is_prod():
    connect(
        alias="mongodb-atlas-chat-history",
        host=MONGODB_ATLAS_CONNECTION_STRING,
        db="chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="cosmosdb-chat-history",
        host=PROD_COSMOS_DB_CONNECTION_STR,
        db="chat_history",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )
    connect(
        alias="mongodb-atlas-users",
        host=MONGODB_ATLAS_CONNECTION_STRING,
        db="users",
        timeoutMS=DEFAULT_TIMEOUT_MS,
    )

else:
    raise ValueError(f"Invalid environment: {env.get_env()}")

__all__ = ["BaseDocument", "LegacyDocument"]
