import datetime

from mongoengine import DateTimeField, Document

from ydc_services.global_utils.storage.mongodb.mixins.json_api_mixin import (
    JsonApiMixin,
)


class BaseDocument(Document, JsonApiMixin):
    """A base class for all new documents.

    This class is used to create an ORM class for new MongoDB collections.

    If you are using an existing collection, you should inherit from LegacyDocument.
    """

    meta = {"abstract": True}
    created_at = DateTimeField(
        default=lambda: datetime.datetime.now(datetime.timezone.utc)
    )
    updated_at = DateTimeField()

    def save(self, *args, **kwargs):
        self.updated_at = datetime.datetime.now(datetime.timezone.utc)
        return super(BaseDocument, self).save(*args, **kwargs)
