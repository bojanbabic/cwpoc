import logging
import os
import pickle
from typing import Any, Callable, Optional

import redis

from ydc_services.global_utils.storage.constants import Constants
from ydc_services.global_utils.storage.mongodb.mixins.decorators import cls_inst_method

REDIS_TIMEOUT = 1
REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD", "").strip()
if len(REDIS_PASSWORD) < 3:
    REDIS_PASSWORD = None


cache_store = redis.StrictRedis(
    host=os.environ.get("REDIS_HOST", "localhost"),
    port=int(os.environ.get("REDIS_PORT", "6380")),
    password=REDIS_PASSWORD,
    ssl=True,
    retry_on_timeout=False,
    decode_responses=False,
    db=Constants().REDIS_YOUCHAT_STORAGE_DB,
    socket_timeout=REDIS_TIMEOUT,
)


class CacheMixin:
    @cls_inst_method
    def _compute_cache_key(self, cls, cache_key: Optional[str] = None) -> str:
        prefix = cls.__name__.lower()
        if self and not cache_key:
            if (
                hasattr(cls, "_meta")
                and getattr(cls, "_meta").get("cache_key")
                and hasattr(cls, getattr(cls, "_meta").get("cache_key"))
            ):
                cache_key = getattr(self, getattr(self, "_meta").get("cache_key"))
            else:
                cache_key = str(self.id)  # type: ignore

        if not cache_key:
            raise ValueError(
                "`cache_key` computes to None, check if the object being cached has a valid value for `cache_key`"
            )

        # `me` stands for mongoengine
        logging.info(f"cache_key: me:{prefix}:{cache_key}")
        return f"me:{prefix}:{cache_key}"

    @classmethod
    def _get_cache_key(cls, self, cache_key: Optional[str] = None) -> str:
        return (
            self._compute_cache_key(cache_key)
            if self
            else cls._compute_cache_key(cache_key)
        )

    @cls_inst_method
    def get_cache(
        self,
        cls,
        cache_key: Optional[str] = None,
        set_cache_fn: Optional[Callable] = None,
        cache_ttl: int = 5 * 60,
    ) -> Any:
        _cache_key = cls._get_cache_key(self, cache_key)
        cached_value = cache_store.get(_cache_key)

        if cached_value:
            value = pickle.loads(cached_value)
            logging.info(f"get_cache: {_cache_key} -> {value}")
            return value
        elif set_cache_fn:
            value = set_cache_fn()
            logging.info(f"get_cache: {_cache_key} -> {value}")
            cls.set_cache(value, cache_key, cache_ttl)
            return value
        else:
            return None

    @cls_inst_method
    def set_cache(
        self,
        cls,
        value: Any,
        cache_key: Optional[str] = None,
        cache_ttl: int = 5 * 60,
    ) -> None:
        _cache_key = cls._get_cache_key(self, cache_key)
        logging.info(f"set_cache: {_cache_key} -> {value}")
        cache_store.set(_cache_key, pickle.dumps(value), ex=cache_ttl)

    @cls_inst_method
    def clear_cache(self, cls, cache_key: Optional[str] = None) -> None:
        _cache_key = cls._get_cache_key(self, cache_key)
        logging.info(f"clear_cache: {_cache_key}")
        cache_store.delete(_cache_key)
