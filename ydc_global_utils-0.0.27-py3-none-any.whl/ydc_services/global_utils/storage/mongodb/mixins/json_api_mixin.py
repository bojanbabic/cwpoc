import datetime
from typing import Optional

import inflection
from bson import ObjectId

from ydc_services.global_utils.storage.mongodb.mixins.decorators import cls_inst_method


class JsonApiMixin:
    json_api_visible_fields: Optional[list[str]] = None

    @cls_inst_method
    def get_json_api_attributes(
        self, cls, obj: Optional[dict] = None, fields: Optional[list[str]] = None
    ):
        if obj is None:
            obj = self.to_mongo()

        if fields is None:
            fields = cls.json_api_visible_fields

        attributes = {}
        for field in obj.keys():
            if fields and field not in fields:
                continue

            if isinstance(obj[field], ObjectId):
                attributes[field] = str(obj[field])
            elif isinstance(obj[field], datetime.datetime):
                attributes[field] = obj[field].isoformat()
            else:
                attributes[field] = obj[field]

        return attributes

    @cls_inst_method
    def to_json_api_data(self, cls, obj: Optional[dict] = None):
        if obj is None:
            obj = self.to_mongo()

        primary_key = cls._meta.get("json_api_primary_key", "_id")
        primary_key_value = None

        if isinstance(primary_key, list):
            for key in primary_key:
                if key in obj:
                    primary_key_value = obj.pop(key)
                    break
        else:
            primary_key_value = obj.pop(primary_key)

        response_datum = {}
        response_datum["id"] = (
            str(primary_key_value) if primary_key == "_id" else primary_key_value
        )
        response_datum["type"] = inflection.pluralize(
            inflection.underscore(cls.__name__)
        )
        response_datum["attributes"] = cls.get_json_api_attributes(obj)

        return response_datum
