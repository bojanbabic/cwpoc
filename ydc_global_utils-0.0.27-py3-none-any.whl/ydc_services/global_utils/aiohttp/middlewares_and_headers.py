import json
import logging
import os
import re
import time
import uuid
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Callable, Optional, Tuple

from aiohttp import hdrs, web
from aiohttp_sse import EventSourceResponse
from pydantic import BaseModel, Field, field_validator

from ydc_services.global_utils.env import Env
from ydc_services.global_utils.instrument.cost_data import CostData
from ydc_services.global_utils.instrument.new_relic import record_newrelic
from ydc_services.global_utils.launchdarkly.constants import LD_CONTEXT_KEY
from ydc_services.global_utils.user_events.schemas import UserEventsData

logger = logging.getLogger(__package__)

BACKEND_GENERATED_TRACE_ID_PATTERN = re.compile(
    r"^(backend_generated\|[a-f0-9\-]+\|[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:[0-9]{2}))$"
)
SAFE_TRACE_ID_PATTERN = re.compile(
    r"^([a-f0-9\-]+\|[a-f0-9\-]+\|[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:[0-9]{2}))$"
)
X_REQUEST_CONTEXT = "X-Request-Context"
X_TRACE_ID_HRDS = "X-Trace-Id"
X_DESCOPE_SESSION = "X-Descope-Session"

DEFAULT_TRACE_ID = "notset"
SUSPICIOUS_TRACE_ID = "suspicious-id-"
TRACE_ID_MAX_LENGTH = 150

env = Env()


class RequestContext(BaseModel):
    trace_id: Optional[str] = None
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    descope_session_token: Optional[str] = None
    launchdarkly_context: Optional[dict] = None
    ## Mutable fields.
    # NOTE: Make sure to update `immutable_model_dump_json` if you add/remove mutable fields.
    # Else the fields will be sent and be updated on the microservice.
    cost_data: Optional[CostData] = Field(default_factory=CostData)
    user_events_data: Optional[UserEventsData] = Field(default_factory=UserEventsData)

    def get(self, field, default_value=None):
        return self.model_dump().get(field, default_value)

    def immutable_model_dump_json(self):
        return self.model_dump_json(exclude={"cost_data", "user_events_data"})

    @field_validator("trace_id")
    def validate_trace_id(cls, trace_id: Optional[str]):
        # If the request is from external (e.g. frontend, whatsapp, local script, etc.), the X-Trace-Id won't be present and will be generated here.
        # If the request comes from internal microservices, the X-Trace-Id will be already present and reused.
        if not trace_id:
            timestamp = datetime.now(timezone.utc).isoformat()
            trace_id = f"backend_generated|{uuid.uuid4()}|{timestamp}"

        # Sanitize the trace_id
        if not (
            isinstance(trace_id, str)
            and (
                SAFE_TRACE_ID_PATTERN.match(trace_id)
                or BACKEND_GENERATED_TRACE_ID_PATTERN.match(trace_id)
            )
            and len(trace_id) < TRACE_ID_MAX_LENGTH
        ):
            # If the trace_id is suspicious, we append a prefix 'suspicious-*' to it to make it easier to identify in logs.
            trace_id = str(trace_id)[:TRACE_ID_MAX_LENGTH].replace(" ", "-")
            if not trace_id.startswith(SUSPICIOUS_TRACE_ID):
                trace_id = f"{SUSPICIOUS_TRACE_ID}{trace_id}"

        if env.is_local():
            # We a truncating the trace_id to 6 characters in local environment
            # for better readability.
            if trace_id.startswith(SUSPICIOUS_TRACE_ID):
                trace_id = str(uuid.uuid4().hex)[:6]
            elif trace_id.startswith("backend_generated"):
                trace_id = trace_id.split("|")[1][:6]
            else:
                trace_id = trace_id[:6]

        return trace_id


request_context_var: ContextVar[RequestContext] = ContextVar(
    "request_context_var", default=RequestContext()
)


def update_request_context_var(update_dict: RequestContext):
    request_context_var.set(
        RequestContext(
            **{
                # always fetch the latest value
                **request_context_var.get().model_dump(),
                **update_dict.model_dump(exclude_unset=True),
            }
        )
    )


def get_request_context_request_id():
    return request_context_var.get().trace_id


def auth_middleware_factory(auth_key):
    """Handle authorization for frontend or callers"""

    @web.middleware
    async def auth_middleware(request, handler):
        auth_header = request.headers.get(hdrs.AUTHORIZATION)
        if auth_header and auth_header == auth_key:
            return await handler(request)
        else:
            return web.HTTPUnauthorized(body="Unauthorized")

    return auth_middleware


def request_context_middleware_factory(
    get_user_id_and_tenant_id_fn: Callable[[str], Tuple[Optional[str], Optional[str]]],
):
    @web.middleware
    async def request_context_middleware(request, handler):
        request_context = None

        if request.headers.get(X_REQUEST_CONTEXT):
            # If an existing request context is present (e.g. from the parent request),
            # we use it to update the request context.
            try:
                existing_request_context_str = request.headers.get(X_REQUEST_CONTEXT)
                existing_request_context = RequestContext(
                    **json.loads(existing_request_context_str)
                )
                if any([x for x in existing_request_context.model_dump().values()]):
                    request_context = existing_request_context

            except Exception:
                logging.error(
                    f"Failed to parse X-Request-Context: {existing_request_context_str}"
                )

        trace_id = None
        if not request_context:
            # Check for existing X-Trace-Id header.
            trace_id = request.headers.get(X_TRACE_ID_HRDS)
            descope_session_token = request.headers.get(X_DESCOPE_SESSION)
            user_id, tenant_id = get_user_id_and_tenant_id_fn(descope_session_token)

            try:
                launchdarkly_context_str = request.headers.get(LD_CONTEXT_KEY, "{}")
                launchdarkly_context = json.loads(launchdarkly_context_str)
            except Exception:
                launchdarkly_context = None

            request_context = RequestContext(
                trace_id=trace_id,
                user_id=user_id,
                tenant_id=tenant_id,
                descope_session_token=descope_session_token,
                launchdarkly_context=launchdarkly_context,
                cost_data=CostData(),
                user_events_data=UserEventsData(),
            )

        if request_context:
            update_request_context_var(request_context)

        logger.debug(
            "request",
            {
                "method": request.method,
                "path": request.path,
                "content_type": request.content_type,
                "content_length": request.content_length,
            },
        )
        req_start_time = time.time()

        # Call the next handler
        try:
            response = await handler(request)
        except Exception as e:
            # This is a very useful pattern for any consumer which runs into a 500 error.
            # Usually 500 errors are catch all errors. If the client run into such an error,
            # it can log it, and later a developer can figure out what the trace_id is and
            # based on that figure out why an error happened by looking into sumo logic logs.

            # currently we are relying on timestamps, and using trace_id is so much better than
            # relying on timestamp. So a quality of life is important for debuggability.

            # I have seen several notable web applications use this pattern. Google is a very
            # good example.

            logger.error("unhandled exception", exc_info=e)
            response = web.json_response(
                {
                    "errors": [
                        {
                            "status": "500",
                            "title": "Internal Server Error",
                            "detail": f"trace_id: {trace_id}",
                        }
                    ]
                },
                status=500,
            )

        if (not isinstance(response, web.Response)) and (
            not isinstance(response, EventSourceResponse)
        ):
            response = web.Response(body=response)

        logger.info(
            "response",
            {
                "method": request.method,
                "path": request.path,
                "status": response.status,
                "request_content_type": request.content_type,
                "request_content_length": request.content_length,
                "response_content_length": response.content_length,
                "response_content_type": response.content_type,
                "response_time_ms": "{:.3f}".format(
                    (time.time() - req_start_time) * 1000
                ),
            },
        )
        return response

    return request_context_middleware


@web.middleware
async def request_endpoint_logging_middleware(request: web.Request, handler):
    path = request.path.lstrip("/")

    # Remove segments that are likely IDs to reduce cardinality on New Relic.
    path_str = "/".join(
        [chunk for chunk in path.split("/") if not re.search(r"\d", chunk)]
    )

    if path_str:
        record_newrelic(f"endpoint_calls/{path_str}", 1)

    start = time.time()
    try:
        response = await handler(request)
        if path_str:
            record_newrelic(f"endpoint_latency/success/{path_str}", time.time() - start)
    except Exception:
        if path_str:
            record_newrelic(f"endpoint_latency/error/{path_str}", time.time() - start)
        raise

    return response


def get_header_generator_for_service(
    environment_api_key_name, auth_key_header_name: str = str(hdrs.AUTHORIZATION)
):
    def generate_headers():
        auth_key = os.environ.get(environment_api_key_name)
        request_context = request_context_var.get()
        trace_id = request_context.get("trace_id", DEFAULT_TRACE_ID)

        _headers = {
            auth_key_header_name: auth_key,
            X_TRACE_ID_HRDS: trace_id,
        }

        descope_session_token = request_context.get("descope_session_token", None)

        if descope_session_token:
            _headers[X_DESCOPE_SESSION] = descope_session_token

        if request_context:
            _headers[X_REQUEST_CONTEXT] = request_context.immutable_model_dump_json()

        return _headers

    return generate_headers


ml_service_header_generator = get_header_generator_for_service("ML_SERVICE_AUTH_KEY")
monolith_auth_header_generator = get_header_generator_for_service("MONOLITH_AUTH_KEY")
file_upload_service_auth_header_generator = get_header_generator_for_service(
    "FILE_UPLOAD_SERVICE_AUTH_KEY"
)
