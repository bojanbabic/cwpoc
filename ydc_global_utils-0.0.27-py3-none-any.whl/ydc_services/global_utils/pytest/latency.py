import time
from contextlib import contextmanager
from typing import Optional


@contextmanager
def assert_latency(
    *,
    less_than: Optional[float] = None,
    more_than: Optional[float] = None,
    equals: Optional[float] = None,
    tol: float = 0.1,  # Tolerate 100ms difference
):
    start = time.time()
    last_checked_time = time.time()

    overall_less_than = less_than
    overall_more_than = more_than

    def _check_latency(
        *,
        less_than: Optional[float] = None,
        more_than: Optional[float] = None,
        equals: Optional[float] = None,
        tol: float = 0.1,
        since_start: bool = False,
    ):
        curr_time = time.time()
        if since_start:
            prev_time = start
        else:
            prev_time = last_checked_time

        time_taken = curr_time - prev_time
        if less_than is not None and time_taken > less_than:
            raise AssertionError(
                f"Time taken should be less than {less_than}s but is: {time_taken:.4f}s"
            )

        if more_than is not None and time_taken < more_than:
            raise AssertionError(
                f"Time taken should be more than {more_than}s but is: {time_taken:.4f}s"
            )

        if equals is not None and abs(time_taken - equals) > tol:
            raise AssertionError(
                f"Time taken should be equal to {equals} ± {tol}s but is: {time_taken:.4f}s"
            )

    try:
        yield _check_latency
    finally:
        _check_latency(
            less_than=overall_less_than,
            more_than=overall_more_than,
            equals=equals,
            tol=tol,
        )
