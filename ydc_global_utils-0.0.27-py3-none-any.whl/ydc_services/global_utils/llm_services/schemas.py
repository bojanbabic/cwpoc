import dataclasses
from enum import Enum
from typing import Dict, List, Optional, TypeAlias

PersonalizationTraits: TypeAlias = List[str]


class PersonalizableQueryClsCategory(str, Enum):
    RETRIEVE_FROM_PROFILE = "retrieve_from_profile"
    PERSONALIZED = "personalized"
    NOT_PERSONALIZED = "not_personalized"


class PersonalizableQueryClsSymbol(str, Enum):
    A = "A"
    B = "B"
    C = "C"


class PersonalizableQueryClassifierOutput:
    CATEGORY_TO_SYMBOL_MAPPING: Dict[
        PersonalizableQueryClsCategory, PersonalizableQueryClsSymbol
    ] = {
        PersonalizableQueryClsCategory.RETRIEVE_FROM_PROFILE: PersonalizableQueryClsSymbol.A,
        PersonalizableQueryClsCategory.PERSONALIZED: PersonalizableQueryClsSymbol.B,
        PersonalizableQueryClsCategory.NOT_PERSONALIZED: PersonalizableQueryClsSymbol.C,
    }
    SYMBOL_TO_CATEGORY_MAPPING: Dict[
        PersonalizableQueryClsSymbol, PersonalizableQueryClsCategory
    ] = {symbol: category for category, symbol in CATEGORY_TO_SYMBOL_MAPPING.items()}

    def __init__(
        self,
        symbol: PersonalizableQueryClsSymbol,
        category: PersonalizableQueryClsCategory,
    ):
        self.symbol = symbol
        self.category = category

    @classmethod
    def from_symbol(cls, symbol: str) -> "PersonalizableQueryClassifierOutput":
        symbol_enum = PersonalizableQueryClsSymbol(symbol)
        category = cls.SYMBOL_TO_CATEGORY_MAPPING[symbol_enum]
        return cls(symbol_enum, category)

    @classmethod
    def from_category(cls, category: str) -> "PersonalizableQueryClassifierOutput":
        category_enum = PersonalizableQueryClsCategory(category)
        symbol = cls.CATEGORY_TO_SYMBOL_MAPPING[category_enum]
        return cls(symbol, category_enum)

    @classmethod
    def from_requires_personal_information(
        cls, requires_personal_information: bool
    ) -> "PersonalizableQueryClassifierOutput":
        category = (
            PersonalizableQueryClsCategory.PERSONALIZED
            if requires_personal_information
            else PersonalizableQueryClsCategory.NOT_PERSONALIZED
        )
        symbol_enum = cls.CATEGORY_TO_SYMBOL_MAPPING[category]
        return cls(symbol_enum, category)

    def requires_personal_information(self) -> bool:
        return self.category in [
            PersonalizableQueryClsCategory.RETRIEVE_FROM_PROFILE,
            PersonalizableQueryClsCategory.PERSONALIZED,
        ]


@dataclasses.dataclass
class MultiTaskLlmOutput:
    intent: Optional[str]
    is_search_required_intent: Optional[bool]
    app_list: Optional[List[str]]
    intent_prob_map: Optional[Dict[str, float]]
    rewritten_query: Optional[str]


@dataclasses.dataclass
class GisL1ClassifierOutput:
    gis_l1_intent: Optional[str]
    gis_l1_intent_prob_map: Optional[Dict[str, float]]
