import logging
import re
from typing import Dict, List, Optional

from ydc_services.global_utils.llm_services.constants import (
    MAX_NUM_CHARS_CURRENT_QUERY_FOR_QUERY_REWRITING,
    MAX_NUM_WORDS_CURRENT_QUERY_FOR_QUERY_REWRITING,
)

logger = logging.getLogger(__package__)


def get_past_queries_from_chat_history(chat_history: List[Dict[str, str]]) -> List[str]:
    return [chat_turn["question"] for chat_turn in chat_history]


def get_ft_model_prompt(past_queries, query):
    stop_token = " END"
    prompt = f"Past queries: {str(past_queries)}\nCurrent query: {query}\n\n###\n\n("
    return prompt, stop_token


def is_current_query_too_long(current_query: str) -> bool:
    if (
        len(current_query) > MAX_NUM_CHARS_CURRENT_QUERY_FOR_QUERY_REWRITING
        or len(current_query.split()) > MAX_NUM_WORDS_CURRENT_QUERY_FOR_QUERY_REWRITING
    ):
        logger.warning(
            "Current query is too long, skipping query rewriting task",
            current_query=current_query,
        )
        return True
    return False


def parse_rewritten_query_from_completion(completion: str) -> Optional[str]:
    """Get the rewritten query from the completion
    Args:
        Input:
            - completion (str): the completion from the LLM, in the format of
            "$mc_letter) <$rewritten_query>"
        Output:
            - rewritten_query (str): the rewritten query
    """
    rewritten_query = None
    pattern = r"(?s)<(.*)>"
    re_matches = re.findall(pattern, completion)
    if re_matches:
        rewritten_query = re_matches[0].strip()
    else:
        logger.warning(
            "Could not find rewritten query for response, using None instead",
            completion=completion,
        )
    return rewritten_query


def is_openai_chat_model(model_name: str) -> bool:
    return not any(
        [
            completion_model in model_name
            for completion_model in ["babbage", "davinci", "ada"]
        ]
    )


def escape_openai_finetune_invalid_tokens(text: str) -> str:
    # Finetune will fail if there are sensitive tokens
    # e.g. "Invalid file format. Example 692 prompt contains invalid tokens."
    return text.replace("<|assistant|>", "<\|assistant\|>").replace(
        "<|endoftext|>", "<\|endoftext\|>"
    )
