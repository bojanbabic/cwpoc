import json
import logging
import os

from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm_services.constants import (
    TIMEOUT_LLM_TRAITS_EXTRACTION_CHAT,
    TIMEOUT_LLM_TRAITS_EXTRACTION_COMPLETION,
    TRAITS_EXTRACTION_CHAT_FINETUNE_SYS_PROMPT,
    TRAITS_EXTRACTION_FINETUNE_TEMPLATE,
    TRAITS_EXTRACTION_INCONTEXT_CHAT_TEMPLATE,
    TRAITS_EXTRACTION_INCONTEXT_TEMPLATE,
)
from ydc_services.global_utils.llm_services.schemas import PersonalizationTraits
from ydc_services.global_utils.llm_services.TraitsExtraction.base import TraitsExtractor
from ydc_services.global_utils.llm_services.utils import (
    escape_openai_finetune_invalid_tokens,
    is_openai_chat_model,
)

logger = logging.getLogger(__package__)


class OpenAITraitsExtractor(TraitsExtractor):
    QUERY_CHAR_LIMIT = 4000

    def __init__(self, model_name: str):
        self.model_name = model_name

        self.is_finetuned_model = model_name.startswith("ft:")
        self.is_chat_model = is_openai_chat_model(model_name)

    @record("personalization/traits_extraction/openai/extract")
    def extract(self, query: str) -> PersonalizationTraits:
        logger.info("Traits extraction called")
        llm_output = self._call_llm(query)
        traits = preprocess_string_into_traits(llm_output)
        logger.info(
            "Extracted traits from query",
            traits=traits,
            query=query,
        )
        return traits

    @classmethod
    def preprocess_query(cls, query: str) -> str:
        return escape_openai_finetune_invalid_tokens(query[: cls.QUERY_CHAR_LIMIT])

    @record("personalization/traits_extraction/openai/call_llm")
    def _call_llm(self, query: str) -> str:
        shared_params = {
            "model_name": self.model_name,
            "max_output_tokens": 100,
            "temperature": 0,
        }
        if self.is_chat_model:
            return self._call_llm_chat(query, shared_params)
        else:
            return self._call_llm_completion(query, shared_params)

    @record("personalization/traits_extraction/openai/call_llm/chat")
    def _call_llm_chat(self, query, shared_params):
        from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat

        sys_prompt = (
            TRAITS_EXTRACTION_CHAT_FINETUNE_SYS_PROMPT
            if self.is_finetuned_model
            else TRAITS_EXTRACTION_INCONTEXT_CHAT_TEMPLATE
        )
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": f"User query: {query}"},
        ]
        llm_client = OpenAIChat(
            request_timeout=TIMEOUT_LLM_TRAITS_EXTRACTION_CHAT,
            **shared_params,
        )
        content = llm_client.get_response_text(messages=messages)
        return (
            content if self.is_finetuned_model else self._parse_llm_chat_output(content)
        )

    @record("personalization/traits_extraction/openai/call_llm/completion")
    def _call_llm_completion(self, query, shared_params):
        from ydc_services.global_utils.llm.clients.legacy_openai_completion import (
            OpenAICompletion,
        )

        prompt_template = (
            TRAITS_EXTRACTION_FINETUNE_TEMPLATE
            if self.is_finetuned_model
            else TRAITS_EXTRACTION_INCONTEXT_TEMPLATE
        )
        shared_params["stop"] = "\n"
        prompt = prompt_template.format(query=self.preprocess_query(query))
        llm_client = OpenAICompletion(
            request_timeout=TIMEOUT_LLM_TRAITS_EXTRACTION_COMPLETION,
            api_key=os.environ.get("OPENAI_B2C_PROD_API_KEY"),
            organization=os.environ.get("OPENAI_B2C_PROD_ORGANIZATION_ID"),
            **shared_params,
        )
        return llm_client.get_response_text(prompt)

    @staticmethod
    def _parse_llm_chat_output(content):
        start_idx = content.find("{")
        end_idx = content.rfind("}")
        if end_idx < 0:
            return ""
        try:
            json_content = content[start_idx : end_idx + 1]
            return json.loads(json_content)["user_traits"]
        except Exception as e:
            logger.error(
                "TraitsExtractorLlm failed to parse json, returning None.",
                content=content,
                exc_info=e,
            )
            return ""


def preprocess_string_into_traits(text: str) -> PersonalizationTraits:
    return [
        token.strip()
        for token in text.split("|")
        if token.strip().lower() not in ["", "none"]
    ]
