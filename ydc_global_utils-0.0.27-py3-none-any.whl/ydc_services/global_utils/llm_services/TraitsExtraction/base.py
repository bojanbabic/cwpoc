from abc import ABC, abstractmethod

from ydc_services.global_utils.llm_services.schemas import PersonalizationTraits


class TraitsExtractor(ABC):
    @abstractmethod
    def extract(self, query: str) -> PersonalizationTraits:
        ...
