import json
import os

import requests

from ydc_services.global_utils.aiohttp.middlewares_and_headers import (
    ml_service_header_generator,
)
from ydc_services.global_utils.env import Env
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm_services.constants import (
    TIMEOUT_LLM_TRAITS_EXTRACTION_ML_SERVICE,
)
from ydc_services.global_utils.llm_services.schemas import PersonalizationTraits
from ydc_services.global_utils.llm_services.TraitsExtraction.base import TraitsExtractor


class MlServiceTraitsExtractor(TraitsExtractor):
    @record("personalization/traits_extraction/ml_service/extract")
    def extract(self, query: str) -> PersonalizationTraits:
        pod_name = os.environ.get("ML_NAME_PORT")
        host = f"{Env().get_http_protocol()}://{pod_name}"
        resp = requests.post(
            f"{host}/extract_traits",
            json={
                "query": query,
            },
            headers=ml_service_header_generator(),
            timeout=TIMEOUT_LLM_TRAITS_EXTRACTION_ML_SERVICE,
        )
        response_json = resp.json()
        cost_tracker_metrics = response_json.pop("cost_tracker_metrics", {})
        CostTracker.update_metrics(cost_tracker_metrics)
        traits = response_json["traits"]
        if isinstance(traits, str):
            return json.loads(traits)
        else:
            return traits
