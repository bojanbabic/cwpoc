from typing import Optional

from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline

from ydc_services.global_utils.llm_services.PersonalizableQueryClassifier.base import (
    PersonalizableQueryClassifier,
)
from ydc_services.global_utils.llm_services.schemas import (
    PersonalizableQueryClassifierOutput,
    PersonalizableQueryClsCategory,
)

id2label = {
    0: PersonalizableQueryClsCategory.RETRIEVE_FROM_PROFILE.value,
    1: PersonalizableQueryClsCategory.PERSONALIZED.value,
    2: PersonalizableQueryClsCategory.NOT_PERSONALIZED.value,
}
label2id = {v: k for k, v in id2label.items()}


class PersonalizableQueryClassifierHfPipelineCls(PersonalizableQueryClassifier):
    def __init__(self, model_name: str, device: Optional[str] = "cuda"):
        super().__init__(model_name)
        tokenizer = AutoTokenizer.from_pretrained(model_name)

        model = AutoModelForSequenceClassification.from_pretrained(
            model_name, num_labels=len(id2label), id2label=id2label, label2id=label2id
        )
        self.pipeline = pipeline(
            task="text-classification",
            model=model,
            tokenizer=tokenizer,
            device=device,
            max_length=2048,
            truncation=True,
            padding="longest",
        )

    def predict(
        self, user_profile: str, query: str
    ) -> PersonalizableQueryClassifierOutput:
        pipeline_results = self.pipeline({"text": user_profile, "text_pair": query})
        return PersonalizableQueryClassifierOutput.from_category(
            pipeline_results["label"]
        )
