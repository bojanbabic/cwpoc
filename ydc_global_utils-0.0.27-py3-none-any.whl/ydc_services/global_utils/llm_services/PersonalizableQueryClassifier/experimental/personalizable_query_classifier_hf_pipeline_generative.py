from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline

from ydc_services.global_utils.llm_services.PersonalizableQueryClassifier.base import (
    PersonalizableQueryClassifier,
)
from ydc_services.global_utils.llm_services.schemas import (
    PersonalizableQueryClassifierOutput,
    PersonalizableQueryClsCategory,
)

id2label = {
    0: PersonalizableQueryClsCategory.RETRIEVE_FROM_PROFILE.value,
    1: PersonalizableQueryClsCategory.PERSONALIZED.value,
    2: PersonalizableQueryClsCategory.NOT_PERSONALIZED.value,
}
label2id = {v: k for k, v in id2label.items()}

FINETUNE_RESPONSE_TEMPLATE = "### Assistant:"


class PersonalizableQueryClassifierHfPipelineGenerative(PersonalizableQueryClassifier):
    def __init__(self, model_name: str, device: str = "cuda"):
        super().__init__(model_name)
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(model_name)
        self.pipeline = pipeline(
            task="text-generation",
            model=model,
            tokenizer=tokenizer,
            device=device,
        )

    def predict(
        self, user_profile: str, query: str
    ) -> PersonalizableQueryClassifierOutput:
        prompt = f"User profile: {user_profile}\nUser query: {query}"
        text = f"{prompt} \n{FINETUNE_RESPONSE_TEMPLATE}"
        pipeline_results = self.pipeline(
            text,
            do_sample=False,
            return_full_text=False,
            temperature=0.0,
            max_new_tokens=1,
        )[0]
        predicted_label = pipeline_results["generated_text"].strip()
        try:
            return PersonalizableQueryClassifierOutput.from_symbol(predicted_label)
        except Exception:
            print(f"Failed to parse predicted label: '{predicted_label}'")
            return PersonalizableQueryClassifierOutput.from_category(
                PersonalizableQueryClsCategory.NOT_PERSONALIZED
            )
