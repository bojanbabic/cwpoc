import json
import logging
import os
from typing import Union

from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm_services.constants import (
    PERSONALIZABLE_QUERY_CLASSIFICATION_CHAT_FINETUNE_SYS_PROMPT,
    PERSONALIZABLE_QUERY_CLASSIFICATION_FINETUNE_TEMPLATE,
    PERSONALIZABLE_QUERY_CLASSIFICATION_INCONTEXT_CHAT_TEMPLATE,
    TIMEOUT_LLM_PQC_CLASSIFIER,
)
from ydc_services.global_utils.llm_services.PersonalizableQueryClassifier.base import (
    PersonalizableQueryClassifier,
)
from ydc_services.global_utils.llm_services.schemas import (
    PersonalizableQueryClassifierOutput,
)

logger = logging.getLogger(__package__)


class OpenAIPersonalizableQueryClassifier(PersonalizableQueryClassifier):
    QUERY_CHAR_LIMIT = 4000
    USER_PROFILE_CHAR_LIMIT = 2000

    def __init__(self, model_name: str):
        super().__init__(model_name)
        self.is_finetuned_model = model_name.startswith("ft:")
        is_chat_model = not any(
            [
                completion_model in self.model_name
                for completion_model in ["babbage", "davinci", "ada"]
            ]
        )
        if not is_chat_model:
            raise ValueError("OpenAI Completion model is not supported")

    @record("personalization/personalizable_query_classifier/openai/predict")
    def predict(
        self, user_profile: str, query: str
    ) -> PersonalizableQueryClassifierOutput:
        context = f"Classifying profile ({user_profile}) and query ({query}) as personalizable or not"
        llm_output = self._call_llm(user_profile, query)
        output = (
            PersonalizableQueryClassifierOutput.from_symbol(llm_output.strip())
            if self.is_finetuned_model
            else PersonalizableQueryClassifierOutput.from_requires_personal_information(
                llm_output
            )
        )
        logger.info(
            "%(context_query)s: %(category)s",
            context_query=context,
            category=output.category,
        )
        return output

    @record("personalization/personalizable_query_classifier/openai/call_llm")
    def _call_llm(self, user_profile: str, query: str) -> Union[str, bool]:
        shared_params = {
            "model_name": self.model_name,
            "temperature": 0,
            "request_timeout": TIMEOUT_LLM_PQC_CLASSIFIER,
        }
        return self._call_llm_chat(query, user_profile, shared_params)

    @record("personalization/personalizable_query_classifier/openai/call_llm/chat")
    def _call_llm_chat(self, query, user_profile, shared_params) -> Union[str, bool]:
        from ydc_services.global_utils.llm.clients.openai_chat import OpenAIChat

        sys_prompt = (
            PERSONALIZABLE_QUERY_CLASSIFICATION_CHAT_FINETUNE_SYS_PROMPT
            if self.is_finetuned_model
            else PERSONALIZABLE_QUERY_CLASSIFICATION_INCONTEXT_CHAT_TEMPLATE
        )
        messages = [
            {"role": "system", "content": sys_prompt},
            {
                "role": "user",
                "content": f"user_profile: {user_profile[: self.USER_PROFILE_CHAR_LIMIT]}",
            },
            {"role": "user", "content": f"query: {query[: self.QUERY_CHAR_LIMIT]}"},
        ]
        llm_client = OpenAIChat(
            max_output_tokens=20,
            **shared_params,
        )
        content = llm_client.get_response_text(messages=messages)
        return (
            content if self.is_finetuned_model else self._parse_llm_chat_output(content)
        )

    @record(
        "personalization/personalizable_query_classifier/openai/call_llm/completion"
    )
    def _call_llm_completion(
        self, query, user_profile, shared_params
    ) -> Union[str, bool]:
        from ydc_services.global_utils.llm.clients.legacy_openai_completion import (
            OpenAICompletion,
        )

        prompt = PERSONALIZABLE_QUERY_CLASSIFICATION_FINETUNE_TEMPLATE.format(
            user_profile=user_profile, query=query[: self.QUERY_CHAR_LIMIT]
        )
        # Model id only exists on prod/foundry org, need to override here to point at that environment
        llm_client = OpenAICompletion(
            max_output_tokens=1,
            stop="\n",
            **shared_params,
            api_key=os.environ.get("OPENAI_B2C_PROD_API_KEY"),
            organization=os.environ.get("OPENAI_B2C_PROD_ORGANIZATION_ID"),
        )
        return llm_client.get_response_text(prompt)

    @staticmethod
    def _parse_llm_chat_output(content) -> bool:
        start_idx = content.find("{")
        end_idx = content.rfind("}")
        if end_idx < 0:
            return False
        try:
            json_content = content[start_idx : end_idx + 1]
            return json.loads(json_content)["is_personalizable_query"]
        except Exception as e:
            logger.error(
                "PersonalizableQueryClassifier failed to parse json, returning None",
                content=content,
                exc_info=e,
            )
            return False
