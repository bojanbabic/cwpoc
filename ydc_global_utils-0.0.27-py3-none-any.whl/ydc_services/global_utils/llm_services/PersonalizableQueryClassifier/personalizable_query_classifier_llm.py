import logging
from typing import Optional, Union

from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm.clients.base import LLM
from ydc_services.global_utils.llm_services.PersonalizableQueryClassifier.base import (
    PersonalizableQueryClassifier,
)
from ydc_services.global_utils.llm_services.schemas import (
    PersonalizableQueryClassifierOutput,
)

logger = logging.getLogger(__package__)
# This variable is used to ensure consistency with the Fine-Tuning pipeline's response template
FINETUNE_RESPONSE_TEMPLATE = "### Assistant:"


class LLMClientPersonalizableQueryClassifier(PersonalizableQueryClassifier):
    QUERY_CHAR_LIMIT = 4000
    USER_PROFILE_CHAR_LIMIT = 2000

    def __init__(
        self,
        llm_client: LLM,
        model_name: Optional[str] = None,
    ):
        super().__init__(model_name)
        self.client = llm_client

    @record("personalization/personalizable_query_classifier/llm_client/predict")
    def predict(
        self, user_profile: str, query: str
    ) -> PersonalizableQueryClassifierOutput:
        context = f"Classifying profile ({user_profile}) and query ({query}) as personalizable or not"
        llm_output = self._call_llm(user_profile, query)
        output = PersonalizableQueryClassifierOutput.from_symbol(llm_output.strip())
        logger.info(
            "%(context_query)s: %(category)s",
            context_query=context,
            category=output.category,
        )
        return output

    @record("personalization/personalizable_query_classifier/llm_client/call_llm")
    def _call_llm(self, user_profile: str, query: str) -> Union[str, bool]:
        prompt = f"User profile: {user_profile}\nUser query: {query}"
        text = f"{prompt} \n{FINETUNE_RESPONSE_TEMPLATE}"
        content = self.client.get_response_text(text)
        return content.strip()
