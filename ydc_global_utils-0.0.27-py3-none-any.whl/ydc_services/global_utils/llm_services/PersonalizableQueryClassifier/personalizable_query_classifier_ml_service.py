import os

import requests

from ydc_services.global_utils.aiohttp.middlewares_and_headers import (
    ml_service_header_generator,
)
from ydc_services.global_utils.env import Env
from ydc_services.global_utils.instrument.cost_tracker import CostTracker
from ydc_services.global_utils.instrument.new_relic import record
from ydc_services.global_utils.llm_services.constants import (
    TIMEOUT_LLM_PQC_CLASSIFIER_ML_SERVICE,
)
from ydc_services.global_utils.llm_services.PersonalizableQueryClassifier.base import (
    PersonalizableQueryClassifier,
)
from ydc_services.global_utils.llm_services.schemas import (
    PersonalizableQueryClassifierOutput,
)


class MlServicePersonalizableQueryClassifier(PersonalizableQueryClassifier):
    @record("personalization/personalizable_query_classifier/ml_service/predict")
    def predict(
        self,
        user_profile: str,
        query: str,
    ) -> PersonalizableQueryClassifierOutput:
        pod_name = os.environ.get("ML_NAME_PORT")
        host = f"{Env().get_http_protocol()}://{pod_name}"
        resp = requests.post(
            f"{host}/predict_personalizable_query",
            json={
                "user_profile": user_profile,
                "query": query,
            },
            headers=ml_service_header_generator(),
            timeout=TIMEOUT_LLM_PQC_CLASSIFIER_ML_SERVICE,
        )
        response_json = resp.json()
        cost_tracker_metrics = response_json.pop("cost_tracker_metrics", {})
        CostTracker.update_metrics(cost_tracker_metrics)
        return PersonalizableQueryClassifierOutput.from_category(
            response_json["category_output"]
        )
