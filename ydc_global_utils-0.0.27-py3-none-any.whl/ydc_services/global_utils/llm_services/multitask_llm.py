import logging
import os
import time
from typing import Dict, List

import newrelic.agent

from ydc_services.global_utils.llm.clients.legacy_openai_completion import (
    OpenAICompletion,
)
from ydc_services.global_utils.llm_services.constants import (
    TIMEOUT_LLM_REWRITING,
)
from ydc_services.global_utils.llm_services.schemas import MultiTaskLlmOutput
from ydc_services.global_utils.llm_services.utils import (
    get_ft_model_prompt,
    get_intent_prob_map_from_logprob_map,
    get_past_queries_from_chat_history,
    is_current_query_too_long,
    parse_intent_info_from_completion,
    parse_rewritten_query_from_completion,
    validate_engine_name,
)

application = newrelic.agent.application()


def emit_metric_for_multitask_llm(metric_name, metric_value):
    newrelic.agent.record_custom_metric(
        f'Custom/{os.environ.get("NEW_RELIC_EVENT_APP_NAME", "default")}/{os.environ.get("REGION", "none")}/multitask_llm/{metric_name}',
        metric_value,
        application,
    )


def get_results_from_multitask_llm(
    current_query: str,
    chat_history: List[Dict],
    engine_name="",
) -> MultiTaskLlmOutput:
    llm_multitasker = MultitaskLlm(engine_name)
    return llm_multitasker.get_tasks_output(chat_history, current_query)


class MultitaskLlm:
    def __init__(self, engine_name: str = ""):
        """This class is responsible for executing the multitask LLM model
        and returning the output of the model. The tasks supported are:
        1. Query Rewriting
        2. Intent Retrieval
        """
        self.engine_name = validate_engine_name(engine_name)

    def get_tasks_output(
        self,
        chat_history: List[Dict],
        current_query: str,
    ) -> MultiTaskLlmOutput:
        start = time.time()
        output = MultiTaskLlmOutput(
            intent=None,
            is_search_required_intent=True,
            app_list=[],
            intent_prob_map={},
            rewritten_query=None,
        )
        try:
            logging.info("Multitask LLM called")
            output = self.get_llm_results(chat_history, current_query)
        except Exception as e:
            logging.warning(f"Multitask LLM failed with exception: {e}")
            emit_metric_for_multitask_llm("multitask_llm_exception", 1)
            return output

        latency = time.time() - start
        self._log_llm_latency(latency, current_query, chat_history)
        return output

    @classmethod
    def _log_llm_latency(cls, latency, current_query, chat_history):
        logging.info(f"Multitask LLM finished in {latency:4f}s")
        emit_metric_for_multitask_llm("llm_response_time", latency)
        if latency > 2:
            logging.warning(
                f"Multitask LLM response time is too long: {latency}. With query: {current_query} and chat_history: {chat_history}"
            )
            emit_metric_for_multitask_llm("multitask_llm_exception", 1)

    def get_llm_results(
        self, chat_history: List[Dict], current_query: str
    ) -> MultiTaskLlmOutput:
        past_queries = get_past_queries_from_chat_history(chat_history)
        # We skip the query rewriting task if the current query is too long
        # or if the current chat is the first turn of the conversation
        should_skip_query_rewriting = (
            is_current_query_too_long(current_query) or len(past_queries) == 0
        )
        return self._get_llm_results(
            current_query, past_queries, should_skip_query_rewriting
        )

    def _get_llm_results(
        self, current_query, past_queries, should_skip_query_rewriting
    ) -> MultiTaskLlmOutput:
        (
            multitask_prompt,
            stop_token,
        ) = get_ft_model_prompt(past_queries, current_query)
        llm_client = OpenAICompletion(
            model_name=self.engine_name,
            temperature=0,
            max_output_tokens=2 if should_skip_query_rewriting else 150,
            logprobs=10,
            stop=stop_token,
            request_timeout=TIMEOUT_LLM_REWRITING,
        )
        response = llm_client.get_response(multitask_prompt)
        return self._parse_response(response)

    @staticmethod
    def _parse_response(response) -> MultiTaskLlmOutput:
        text = OpenAICompletion.get_text_from_response(response).strip()
        intent_token_logprobs_map = OpenAICompletion.get_token_to_logprob_sequence(
            response
        )[0]
        intent, is_search_required_intent, app_list = parse_intent_info_from_completion(
            text
        )
        return MultiTaskLlmOutput(
            intent,
            is_search_required_intent,
            app_list,
            get_intent_prob_map_from_logprob_map(intent_token_logprobs_map),
            parse_rewritten_query_from_completion(text),
        )
