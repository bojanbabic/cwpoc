import ast
from collections import defaultdict
from enum import Enum

# App description for LLM Ranker
wikipedia_desc = "Wikipedia and Facts"
finance_desc = "Finance and Crypto"
coding_desc = "Stackoverflow and Coding"
recipes_desc = "Recipes and Cooking"
linkedin_desc = "LinkedIn and People"
social_desc = "Social Media"
reddit_desc = "Reddit or Advice, Opinion, Reviews"
places_desc = "Places and Businesses"
yelp_desc = "Yelp and Business Reviews"
entertainment_desc = "Where to Watch Movies and TV Shows"
imagegen_desc = "Generating AI Art and Images"
image_search_desc = "Image Search"
live_sports_desc = "Live Sports Updates"
weather_desc = "Weather"
video_desc = "Video Search"
news_desc = "News and Current Events"
computation_desc = "Computation, Conversions, and Calculations"
creativity_desc = "Creative Writing"
rewriting_request_desc = "Request For Rewriting"
code_request_desc = "Request For Code"
continue_request_desc = "Request To Continue"
rate_response_desc = "Rate Previous Response"
chitchat_desc = "Casual Chitchat"
correct_response_desc = "Correct Previous Response"
linguistic_quiz_desc = "Linguistic Quiz"
other_search_desc = "General Information Search"


class IntentChoice:
    def __init__(
        self,
        letter: str,
        description: str,
        app_list: list,
        intent_label: str,
        app_label_list: list | None = None,
    ):
        self.letter = letter
        self.description = description
        self.app_list = app_list
        self.intent_label = intent_label
        self.app_label_list = app_label_list
        if app_label_list:
            assert len(app_list) == len(
                app_label_list
            ), "app_list and app_label_list must be the same length"

    def __str__(self):
        return f"({self.letter})"


class RankerMultiChoice:
    """Enum for the different choices for the LLM Ranker
    - Each choice has a multiple-choice letter, description, list of apps, and intent label
    - The letter(s) is used to identify the choice, in which:
        - The first letter denotes the intent use case: 'A' and 'S' for search intents, and 'N' for non-search intents.
        - The second letter is a random letter that is assigned to a specific intent.
    """

    WIKIPEDIA = IntentChoice("AA", wikipedia_desc, ["wikipedia"], "Wikipedia")
    FINANCE = IntentChoice(
        "AB",
        finance_desc,
        ["finance", "crypto"],
        "Finance (Finance, Crypto apps)",
        ["finance", "crypto"],
    )
    CODING = IntentChoice(
        "AC",
        coding_desc,
        [
            "stackoverflow",
            "geeksforgeeks",
            "w3 schools",
            "mozilla developer network",
            "tutorialspoint",
        ],
        "Code Snippet (Stackoverflow, Geeksforgeeks, W3 Schools, MDN, Tutorials Point apps)",
    )
    LIVE_SPORTS = IntentChoice(
        "AD", live_sports_desc, ["livesports"], "Live Sports (ESPN live app priming)"
    )
    RECIPES = IntentChoice(
        "AE",
        recipes_desc,
        [
            "allrecipes",
            "bonappetit",
            "cookingnytimes",
            "epicurious",
            "foodnetwork",
            "foodandwine",
            "myrecipes",
            "onceuponachef",
            "seriouseats",
            "simplyrecipes",
            "thekitchn",
            "americastestkitchen",
            "bbcgoodfood",
            "cookinglight",
            "foodcom",
            "delish",
            "draxe",
            "eatthis",
            "instantpot",
            "liquor",
            "marthastewart",
            "mashed",
            "pillsbury",
            "pressurecookrecipes",
            "realsimple",
            "tasteofhome",
            "tasty",
            "thespruceeats",
            "thrillist",
        ],
        "Recipes",
    )
    LINKEDIN = IntentChoice(
        "AF",
        linkedin_desc,
        ["linkedin"],
        "People (Instagram, LinkedIn, etc. apps)",
        ["linkedin"],
    )
    REDDIT = IntentChoice("AG", reddit_desc, ["reddit"], "Reddit")
    PLACES = IntentChoice(
        "AH",
        places_desc,
        ["places"],
        "Places Information (Places, Yelp, etc. apps)",
        ["places"],
    )
    ENTERTAINMENT = IntentChoice(
        "AI", entertainment_desc, ["whatToWatch"], "Entertainment (What To Watch app)"
    )
    IMAGEGEN = IntentChoice(
        "AJ",
        imagegen_desc,
        ["stable_diffusion"],
        "Image Related",
        ["stable_diffusion"],
    )
    WEATHER = IntentChoice("AK", weather_desc, ["weather"], "Weather")
    YELP = IntentChoice(
        "AL",
        yelp_desc,
        ["yelp"],
        "Places Information (Places, Yelp, etc. apps)",
        ["yelp"],
    )
    SOCIAL_INSTAGRAM = IntentChoice(
        "AM",
        social_desc + ": Instagram",
        ["instagram"],
        "People (Instagram, LinkedIn, etc. apps)",
        ["instagram"],
    )
    IMAGE_SEARCH = IntentChoice(
        "AN",
        image_search_desc,
        ["images"],
        "Image Related",
        ["images"],
    )
    SOCIAL_TWITTER = IntentChoice(
        "AO",
        social_desc + ": Twitter",
        ["twitter"],
        "People (Instagram, LinkedIn, etc. apps)",
        ["twitter"],
    )
    SOCIAL_FACEBOOK = IntentChoice(
        "AP",
        social_desc + ": Facebook",
        ["facebook"],
        "People (Instagram, LinkedIn, etc. apps)",
        ["facebook"],
    )
    SOCIAL_TIKTOK = IntentChoice(
        "AQ",
        social_desc + ": TikTok",
        ["tiktok"],
        "People (Instagram, LinkedIn, etc. apps)",
        ["tiktok"],
    )
    VIDEO_SEARCH = IntentChoice(
        "AR",
        video_desc,
        ["videos"],
        "Videos",
    )
    NEWS = IntentChoice(
        "SA",
        news_desc,
        ["news"],
        "News",
        ["news"],
    )
    CREATIVE_WRITING = IntentChoice("NA", creativity_desc, [], "Creative writing")
    REWRITING_REQUEST = IntentChoice(
        "NB", rewriting_request_desc, [], "Request for rewriting"
    )
    CODE_REQUEST = IntentChoice("NC", code_request_desc, [], "Request for code")
    CONTINUE_REQUEST = IntentChoice(
        "ND", continue_request_desc, [], "Request to continue"
    )
    RATE_RESPONSE = IntentChoice("NE", rate_response_desc, [], "Rate previous response")
    COMPUTATION = IntentChoice(
        "NF",
        computation_desc,
        ["op_Math"],
        "Computation",
        # NOTE: This is a list of all the sub-computation intents.
        # [
        #     "Math question",
        #     "Unit conversion",
        #     "Graphing calculator",
        #     "Currency conversion",
        #     "Temperature conversion",
        # ]
    )
    CORRECT_RESPONSE = IntentChoice(
        "NH", correct_response_desc, [], "Correct previous response"
    )
    CHITCHAT = IntentChoice("NG", chitchat_desc, [], "Casual chitchat")
    LINGUISTIC_QUIZ = IntentChoice("NI", linguistic_quiz_desc, [], "Linguistic quiz")
    OTHER = IntentChoice("SX", other_search_desc, [], "Other")

    letter_to_mc = {
        WIKIPEDIA.letter: WIKIPEDIA,
        FINANCE.letter: FINANCE,
        CODING.letter: CODING,
        LIVE_SPORTS.letter: LIVE_SPORTS,
        RECIPES.letter: RECIPES,
        LINKEDIN.letter: LINKEDIN,
        REDDIT.letter: REDDIT,
        PLACES.letter: PLACES,
        ENTERTAINMENT.letter: ENTERTAINMENT,
        IMAGEGEN.letter: IMAGEGEN,
        WEATHER.letter: WEATHER,
        YELP.letter: YELP,
        SOCIAL_INSTAGRAM.letter: SOCIAL_INSTAGRAM,
        IMAGE_SEARCH.letter: IMAGE_SEARCH,
        SOCIAL_TWITTER.letter: SOCIAL_TWITTER,
        SOCIAL_FACEBOOK.letter: SOCIAL_FACEBOOK,
        SOCIAL_TIKTOK.letter: SOCIAL_TIKTOK,
        VIDEO_SEARCH.letter: VIDEO_SEARCH,
        NEWS.letter: NEWS,
        CREATIVE_WRITING.letter: CREATIVE_WRITING,
        REWRITING_REQUEST.letter: REWRITING_REQUEST,
        CODE_REQUEST.letter: CODE_REQUEST,
        CONTINUE_REQUEST.letter: CONTINUE_REQUEST,
        RATE_RESPONSE.letter: RATE_RESPONSE,
        COMPUTATION.letter: COMPUTATION,
        CORRECT_RESPONSE.letter: CORRECT_RESPONSE,
        CHITCHAT.letter: CHITCHAT,
        LINGUISTIC_QUIZ.letter: LINGUISTIC_QUIZ,
        OTHER.letter: OTHER,
    }

    intent_label_to_mc_list = defaultdict(
        list
    )  # Intent label to list of IntentChoice (1:many mapping)
    for _, mc in letter_to_mc.items():
        intent_label_to_mc_list[mc.intent_label].append(mc)

    @classmethod
    def get_intent_info_from_letter(cls, letter):
        is_search_required_intent = letter[0] != "N"
        return (
            cls.letter_to_mc[letter].description,
            is_search_required_intent,
            cls.letter_to_mc[letter].app_list,
        )

    @classmethod
    def is_app_search_intent(cls, letter):
        # An app search intent is defined as a search intent
        # that includes at least one app in the app list.
        return letter[0] != "N" and len(cls.letter_to_mc[letter].app_list) > 0

    @classmethod
    def get_intent_description_from_letter(cls, letter):
        if letter not in cls.letter_to_mc:
            return None
        return cls.letter_to_mc[letter].description

    @classmethod
    def get_all_letters(cls):
        return cls.letter_to_mc.keys()

    @classmethod
    def get_mc_letter_from_label(cls, airtable_row):
        intent_label, positive_label, sub_intent_labels = (
            airtable_row["assigned_intent"],
            airtable_row["positive_label"],
            ast.literal_eval(airtable_row["sub_intents"])
            if isinstance(airtable_row["sub_intents"], str)
            else [],
        )
        if positive_label == "No":
            return cls.OTHER.letter

        if intent_label not in cls.intent_label_to_mc_list:
            raise ValueError(f"Intent label '{intent_label}' is not supported yet")

        intent_mc_list = cls.intent_label_to_mc_list[intent_label]
        if len(intent_mc_list) == 1:
            return intent_mc_list[0].letter

        # If there are multiple choices for the same intent, it means the app-level label is needed
        # To distinguish between them, then we need to check the field named $app_label_list[0]
        # in the airtable row

        for mc in intent_mc_list:
            if mc.app_label_list and all(
                app_label in sub_intent_labels for app_label in mc.app_label_list
            ):
                return mc.letter

        return cls.OTHER.letter

    @classmethod
    def get_description_from_label(cls, airtable_row):
        return str(cls.letter_to_mc[cls.get_mc_letter_from_label(airtable_row)])

    @classmethod
    def get_choices_str(cls):
        return "\n".join([str(choice) for _, choice in cls.letter_to_mc.items()])


# GPT 3.5 Turbo
class T3(str, Enum):
    GENERATION_STOP_TOKEN = "<||im_end||>"
    PERSONALIZATION_USER_TAG = "<||im_start||>user\n"
    PERSONALIZATION_USER_END_TAG = "<||im_end||>"
    PERSONALIZATION_BOT_TAG = "<||im_start||>assistant\n"
    PERSONALIZATION_BOT_END_TAG = "<||im_end||>"


# Claude3 prompt
class C3(str, Enum):
    HISTORY_BOT_TAG = "<||im_start||>assistant"
    # No end token is needed for LLM Chat/Messages API
    HISTORY_USER_TAG = "<||im_start||>user"
    USER_QUESTION_PLACEHOLDER = "[QUESTION_MISSING]"
    BOT_ANSWER_PLACEHOLDER = "[ANSWER_MISSING]"
    PERSONALIZATION_USER_TAG = "<||im_start||>user\n"
    PERSONALIZATION_USER_END_TAG = "<||im_end||>"
    PERSONALIZATION_BOT_TAG = "<||im_start||>assistant\n"
    PERSONALIZATION_BOT_END_TAG = "<||im_end||>"


# simple-openai like prompt
class D1(str, Enum):
    HISTORY_USER_TAG = "<||im_start||>user"
    HISTORY_BOT_TAG = "<||im_start||>assistant"
    END_TAG = "<||im_end||>"
    GENERATION_STOP_TOKEN = "<||im_end||>"
    USER_QUESTION_PLACEHOLDER = "[QUESTION_MISSING]"
    BOT_ANSWER_PLACEHOLDER = "[ANSWER_MISSING]"
    PERSONALIZATION_USER_TAG = "<||im_start||>user\n"
    PERSONALIZATION_USER_END_TAG = "<||im_end||>"
    PERSONALIZATION_BOT_TAG = "<||im_start||>assistant\n"
    PERSONALIZATION_BOT_END_TAG = "<||im_end||>"


# Cohere
class CH(str, Enum):
    HISTORY_USER_TAG = "<||im_start||>USER"
    HISTORY_BOT_TAG = "<||im_start||>CHATBOT"
    END_TAG = "<||im_end||>"
    USER_QUESTION_PLACEHOLDER = "[QUESTION_MISSING]"
    BOT_ANSWER_PLACEHOLDER = "[ANSWER_MISSING]"
