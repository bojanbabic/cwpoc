from abc import ABC, abstractmethod
from typing import Tuple, TypeAlias

from ydc_services.global_utils.llm_services.schemas import PersonalizationTraits

UserProfile: TypeAlias = str


class PersonalizationProfileRefiner(ABC):
    @abstractmethod
    def extract_traits_from_query(
        self,
        query: str,
    ) -> PersonalizationTraits:
        ...

    @abstractmethod
    def extract_traits_from_query_and_refine_profile(
        self, profile: UserProfile, query: str
    ) -> Tuple[PersonalizationTraits, UserProfile]:
        ...
