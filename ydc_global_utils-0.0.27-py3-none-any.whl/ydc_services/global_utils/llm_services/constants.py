from ydc_services.global_utils.env import Env

env = Env()

# The number of characters that are used to represent a multiple choice
NUM_CHARS_PER_SHORT_MC = 2

# Too long context gonna blow up the prompt length
MAX_NUM_CHARS_CURRENT_QUERY_FOR_QUERY_REWRITING = 400
# As the max number tokens OpenAI will generate is 50,
# we rely on fallback to rewrite query has longer than 100 words (~ 150 tokens)
MAX_NUM_WORDS_CURRENT_QUERY_FOR_QUERY_REWRITING = 100

QUERY_REWRITER_MODEL_NAME = "Qwen/Qwen2-1.5B-Instruct"
QUERY_REWRITER_ENDPOINT_NAME = "Qwen2-1_5B-Instruct"

TRAITS_EXTRACTION_MODEL_NAME_V2 = (
    "ft:gpt-4o-mini-2024-07-18:you:personalization-traits-extraction-cv-0:AGtmtaRN"
)

PERSONALIZATION_PROFILE_MODEL_NAME_V1 = "davinci-002"
PERSONALIZATION_PROFILE_MODEL_NAME_V2 = "gpt-4o-mini"

PQC_MODEL_NAME_V2 = "Qwen2_5-0_5b-ft-pqc"
PQC_ENDPOINT_NAME = "Qwen2_5-0_5b-ft-pqc"

QUERY_REWRITER_TEMPERATURE = 0.0
# We truncate past queries to a reasonably small number of tokens to ensure we can obtain a result within the timeout limit
QUERY_REWRITER_MAX_TOKENS_PAST_QUERIES = 500
# Given that we only run query rewriter when there are < 150 tokens, we reserve 500+150=650 for the total num of input tokens
QUERY_REWRITER_MAX_TOKENS_INPUT = 650
# input speed ~= 4000tps and output speed ~= 100tps, hence we should have roughly < 200 output tokens.
QUERY_REWRITER_MAX_TOKENS_OUTPUT = 200

TIMEOUT_LLM_REWRITING = 2.0
TIMEOUT_LLM_REWRITING_REQUEST = 2.1
TIMEOUT_LLM_REWRITING_FUTURES = 2.1
TIMEOUT_LLM_PQC_CLASSIFIER = 2.0
TIMEOUT_LLM_PQC_CLASSIFIER_ML_SERVICE = 2.1
TIMEOUT_LLM_TRAITS_EXTRACTION_COMPLETION = 2.0
TIMEOUT_LLM_TRAITS_EXTRACTION_CHAT = 3.0
TIMEOUT_LLM_PROFILE_REFINEMENT_COMPLETION = 2.0
TIMEOUT_LLM_PROFILE_REFINEMENT_CHAT = 3.0


RELATED_SEARCHES_SYSTEM_TEMPLATE = """Generate 5 follow-up statements to the provided query that one may ask a knowledge bank in conversation.
Make them unique, and be creative. Do NOT rephrase the query.
Keep each statement less than 7 words, in the same language as the query, and on separate lines."""
RELATED_SEARCHES_USER_TEMPLATE = """Query:
{query}"""

RELATED_SEARCHES_CA_SYSTEM_TEMPLATE = """Based on the following context and query:

CONTEXT:
{instructions}

QUERY:
{query}

Generate 5 follow-up statements based on the context and the query below that a user may input directly into a knowledge bank in conversation.
Ensure that each statement:
- Is unique and creative
- Is not a question
- Is an actionable directive or specific input
- Serves as a next step or variation
- Is not a rephrasing of the query
- Is less than 7 words
- Is in the same language as the query
- Is on a separate line

**EXAMPLE 1 (Single-step Context):**

Instruction: 'Assist with press release'
Query: 'Draft a neutral press release announcing the opening of a new community library.'
**Output:**
Use a casual tone
Use a professional tone
Provide a fact in the intro
Include a personal anecdote
Highlight environmental impact

---

**EXAMPLE 2 (Multi-Step Context):**

Instruction:
'''
You are an AI writing assistant called YouWrite. Your purpose is to help users write various types of content in different tones for specific target audiences. Go through these steps one chat at a time:

1. **Writing Task:** Ask the user what kind of writing task they have and present options. Examples include: Email, Paragraph, Essay Title, Blog, Essay.

2. **Tone Selection:** Ask the user for the tone and present options. Examples include: Neutral, Friendly, Professional, Witty, Persuasive.

3. **Audience Details:** Ask the user for details on who the audience is.

4. **Message Content:** Ask the user for the general message they want to share.

When the user provides a writing task, tone, audience, and message, generate the requested content accordingly. Tailor the writing style, word choice, and content to match the specified tone and resonate with the target audience. Ensure the output effectively communicates the key points from the provided message. Use proper grammar, punctuation, and formatting. Adapt to the user's needs and preferences.

If the user asks what your role is, share: "I'm here to help you craft excellent written content! Let me know if you need any clarification or have additional instructions."
'''

Query: 'Draft a neutral press release announcing the opening of a new community library.'
Response: 'What kind of writing task do you have? Here are some options to choose from: Email, Paragraph, Essay Title, Blog, or Essay.'
**Output:**
Email
Paragraph
Essay Title
Blog
Three Paragraph Essay

---
NOTE: Never include: 'Output:' in the response and ALWAYS include some suggestions. NEVER include 'No related searches found' as output.
"""
RELATED_SEARCHES_CA_USER_TEMPLATE = """Query:
{query}"""

RAW_GREETINGS = [
    "hi",
    "hello",
    "hey",
    "hey you",
    "hi there",
    "hello there",
    "hey there",
    "howdy",
    "greetings",
    "salutations",
    "youchat",
    "you chat",
    "you",
    "chat",
    "test",
    "testing",
]
GREETINGS = set(RAW_GREETINGS + [query + "!" for query in RAW_GREETINGS])
GREETINGS_RELATED_SEARCHES = [
    "Plan a trip to explore Madagascar on a budget",
    "Recommend a dish to impress a date who is a picky eater",
    "Tell me a fun fact about the Roman Empire",
    "Help me pick a gift for my dad who loves fishing",
    "Write a Python script to automate sending email reports",
    "Plan a trip to see New York City in 3 days",
    "Create a workout plan for resistance training",
]
MAX_NUM_OF_RELATED_SEARCHES = 3
RELATED_SEARCHES_TIMEOUT = 5
MAX_RELATED_SEARCHES_CHARS = 60

# Note that the empty profiles below should have a space after the ":" or we might see
# a worsened performance. So it should be "Profile: \n" instead of "Profile:\n".
PERSONALIZATION_PROFILE_REFINER_INCONTEXT_TEMPLATE = """Each user has a Profile that contains knowledge that we know about them. There are new Traits that we have extracted and would like to use to update their current Profile into a single coherent Profile. If the new Trait has already been covered within the current Profile, then there should be no change. We want to preserve the bullet, numbered, newline formatting of the current Profile.
Examples below are separated by "###":
Profile: 
Traits: My name is Rajesh Kumar | My age is 41
Updated profile: My name is Rajesh Kumar and my age is 41.
###
Profile: I went on a trip to Nepal and really enjoyed mountain sightseeing.
Traits: I am a full stack computer programmer | I do web development working with JavaScript, React.js, Next.js | I am AWS and Microsoft certified
Updated profile: I went on a trip to Nepal and really enjoyed mountain sightseeing. I am a full stack computer programmer and I do web development working with JavaScript, React.js, Next.js. I am AWS and Microsoft certified.
###
Profile: 
Traits: I have 2 young kids
Updated profile: I have 2 young kids.
###
Profile: I write code using Javascript. I also write songs. I use automated testing tools.
Traits: I use Python
Updated profile: I write code using Javascript and Python. I also write songs. I use automated testing tools.
###
Profile: My name is James Tod and I am 41 years old this year.

Here are some things about me:
1. I am a Visual Designer specializing in brand and product design, currently pursuing a masters in Graphic Design
2. hobbies are reading fiction/non-fiction, biking, video games and outdoor adventures
3. My interests are traveling, discovering new technology, food and wine, films and movies, architecture and design, and cooking 
4. I want to write some code for an AR app in swift UI
Traits: I am starting a vegetarian diet
Updated profile: My name is James Tod and I am 41 years old this year.
 
Here are some things about me:
1. I am a Visual Designer specializing in brand and product design, currently pursuing a masters in Graphic Design
2. hobbies are reading fiction/non-fiction, biking, video games and outdoor adventures
3. My interests are traveling, discovering new technology, food and wine, films and movies, architecture and design, and cooking 
4. I want to write some code for an AR app in swift UI
5. I am starting a vegetarian diet
###
Profile: I like to watch movies, write, garden, and eat apples. I also like the beach and the mountains. I like to collect baseball cards and pokemon. I breed horses. I am 6 feet tall and I like shorts, sweaters, hats, and hoodies.
Traits: I like to read books
Updated profile: I like to watch movies, read books, write, garden, and eat apples. I also like the beach and the mountains. I like to collect baseball cards and pokemon. I breed horses. I am 6 feet tall and I like shorts, sweaters, hats, and hoodies.
###
Profile: 
Traits: I am a Star Wars fan | I use Python
Updated profile: I am a Star Wars fan and I use Python.
###
Profile: I am an avid reader with a penchant for classic literature and contemporary fiction. My hobbies include photography, trekking, bird watching, hunting, and camping. I am a meat eater, with a keen interest in exploring various cuisines and cooking experimental dishes. I am a sport enthusiast, particularly fond of tennis, soccer, and basketball. My favorite travel destinations include Europe and Asia, with a special love for historical sites. I am an environmentalist, always looking for ways to reduce my carbon footprint. My professional interests lie in the field of Data Science and Artificial Intelligence. I enjoy listening to jazz, classical music, and opera. I am a dog lover, and I have a Golden Retriever named Max and a cat named Bella.
Traits: I like dogs
Updated profile: I am an avid reader with a penchant for classic literature and contemporary fiction. My hobbies include photography, trekking, bird watching, hunting, and camping. I am a meat eater, with a keen interest in exploring various cuisines and cooking experimental dishes. I am a sport enthusiast, particularly fond of tennis, soccer, and basketball. My favorite travel destinations include Europe and Asia, with a special love for historical sites. I am an environmentalist, always looking for ways to reduce my carbon footprint. My professional interests lie in the field of Data Science and Artificial Intelligence. I enjoy listening to jazz, classical music, and opera. I am a dog lover, and I have a Golden Retriever named Max and a cat named Bella.
###
Profile: I like to bike and I am 70 years old. I want to do things in New York. hello. I use Python and SSH.
Traits: I will be 72 this year
Updated profile: I like to bike and I am 72 years old. I want to do things in New York. hello. I use Python and SSH.
###
Profile: I am interested in best practices for data analysis funnels. I use the Stripe app marketplace, Chargebee, and I am interested in onboarding people to products and gifting subscriptions. I use the Opera browser, Chromium browsers, Vivaldi, and Arc browser, as well as Chrome. I use Figma, SVG and PNG. I am interested in FTMs in computing. I use Jira for software teams. I use Python. I use Mac OS Sierra. I am interested in running shoes. I also use Asana.
Traits: I use Vivaldi
Updated profile: I am interested in best practices for data analysis funnels. I use the Stripe app marketplace, Chargebee, and I am interested in onboarding people to products and gifting subscriptions. I use the Opera browser, Chromium browsers, Vivaldi, and Arc browser, as well as Chrome. I use Figma, SVG and PNG. I am interested in FTMs in computing. I use Jira for software teams. I use Python. I use Mac OS Sierra. I am interested in running shoes. I also use Asana.
###
Profile: 
Traits: I like running in the mountains
Updated profile: I like running in the mountains.
###
Profile: I am interested in cost-effective vacations and artificial intelligence conferences. I use Python and I like to ski, cook, watch horror movies, and read books during winters. I love to cook, including cooking cakes.
Traits: I love skiing
Updated profile: I am interested in cost-effective vacations and artificial intelligence conferences. I use Python and I like to ski, cook, watch horror movies, and read books during winters. I love to cook, including cooking cakes.
###
Profile: I am a creative Project Manager who is passionate about helping designers and developers ship their very best work. I led projects from initial briefing to launch day and beyond, with direct responsibility for day-to-day management of process and workflow. I have overseen dot coms, digital experiences and a home screen’s worth of apps.
Traits: I like running around the lake beside my house | I like to play golf
Updated profile: I am a creative Project Manager who is passionate about helping designers and developers ship their very best work. I led projects from initial briefing to launch day and beyond, with direct responsibility for day-to-day management of process and workflow. I have overseen dot coms, digital experiences and a home screen’s worth of apps. I like running around the lake beside my house and playing golf.
###
Profile: {user_profile}
Traits: {traits}
Updated profile:"""

PERSONALIZATION_PROFILE_REFINER_INCONTEXT_CHAT_TEMPLATE = """<|im_start|>system
You are a helpful assistant that helps me to update my Profile using the new Traits that I provide you with into a new and updated Profile.

You are to follow the following criteria at all times:
1. Preserve as much of the wording of the current Profile and provided Traits as possible.
2. We want to preserve the bullet, numbered, newline formatting and sentence structures of the current Profile.
3. If the new Trait has already been covered within the current Profile, then there should be no change.
4. Tell me the updated profile directly, do not start your sentence with a prefix like "Updated profile:".

Your results should be in this json format (properly formatted with quotes and special characters escaped):
{
    "updated_profile": "The updated profile" 
}

Examples:
###
Profile: 
Traits: My name is Rajesh Kumar | My age is 41
Output: {
    "updated_profile": "My name is Rajesh Kumar and my age is 41."
}

###
Profile: My name is James Tod and I am 41 years old this year.

Here are some things about me:
1. I am a Visual Designer specializing in brand and product design, currently pursuing a masters in Graphic Design
2. hobbies are reading fiction/non-fiction, biking, video games and outdoor adventures
3. My interests are traveling, discovering new technology, food and wine, films and movies, architecture and design, and cooking 
4. I want to write some code for an AR app in swift UI
Traits: I am starting a vegetarian diet
Output: {
    "updated_profile": "My name is James Tod and I am 41 years old this year.
Here are some things about me:
1. I am a Visual Designer specializing in brand and product design, currently pursuing a masters in Graphic Design
2. hobbies are reading fiction/non-fiction, biking, video games and outdoor adventures
3. My interests are traveling, discovering new technology, food and wine, films and movies, architecture and design, and cooking 
4. I want to write some code for an AR app in swift UI
5. I am starting a vegetarian diet"
}

###
Profile: I like to bike and I am 70 years old. I want to do things in New York. hello. I use Python and SSH. 
Traits: I will be 72 this year 
Output: { 
    "updated_profile": "I like to bike and I am 72 years old. I want to do things in New York. hello. I use Python and SSH." 
}

###
Profile: I am a creative Project Manager who is passionate about helping designers and developers ship their very best work. I led projects from initial briefing to launch day and beyond, with direct responsibility for day-to-day management of process and workflow. I have overseen dot coms, digital experiences and a home screen's worth of apps. 
Traits: I like running around the lake beside my house | I like to play golf 
Output: { 
    "updated_profile": "I am a creative Project Manager who is passionate about helping designers and developers ship their very best work. I led projects from initial briefing to launch day and beyond, with direct responsibility for day-to-day management of process and workflow. I have overseen dot coms, digital experiences and a home screen's worth of apps. I like running around the lake beside my house and playing golf." 
}
"""

TRAITS_EXTRACTION_INCONTEXT_TEMPLATE = """Extract different knowledge about a user from their queries. Do not assume things that they do not explicitly say themselves. Separate different facts with a |.

User query: Can I provide you with some of the work I did as a college chemistry tutor so that you can help create a resume entry to apply for a chemistry tutor position?
Properties: past work as college chemistry tutor | wants to work as chemistry tutor

User query: What apps that can convert 2D images to 3D images in iPhone for free?
Properties: None

User query: I am a coffee shop owner in saudi arabia, specifically in riyadh, and I need a study for the market, put it in a pullet points, and make it helpful for me
Properties: coffee shop owner in riyadh, saudi arabia

User query: Write a tweet where i can ask a funny question to my followers
Properties: None

User query: can you go from a associates degree to a master degree
Properties: None

User query: can you write code create a website by using Flutter, Dart for me ?
Properties: None

User query: I want to go on a diet, what food is good?
Properties: wants to go on a diet

User query: List of low carb vegan foods
Properties: None

User query: Give me example for architecture design
Properties: None

User query: Write a story about my life
Properties: None

User query: I want a description of a supermarket app
Properties: None

User query: I am an America evaluating if migrating to China. Can you tell me the social problems of China?
Properties: is American | evaluating migration to China

User query: {query}
Properties:"""

TRAITS_EXTRACTION_INCONTEXT_CHAT_TEMPLATE = """Extract different user traits from their queries. Do not assume things that they do not explicitly say themselves. Separate different facts with a |.

Your results should be in this json format (properly formatted with quotes and special characters escaped):
{
    "user_traits": "User properties or information derived from the query" 
}

Examples:
###
User query:: Can I provide you with some of the work I did as a college chemistry tutor so that you can help create a resume entry to apply for a chemistry tutor position?
Output: {
    "user_traits": "past work as college chemistry tutor | wants to work as chemistry tutor"
}

User query:: What apps that can convert 2D images to 3D images in iPhone for free?
Output: {
    "user_traits": ""
}

User query:: I am a coffee shop owner in saudi arabia, specifically in riyadh, and I need a study for the market, put it in a pullet points, and make it helpful for me
Output: {
    "user_traits": "coffee shop owner in riyadh, saudi arabia"
}

User query:: Write a tweet where i can ask a funny question to my followers
Output: {
    "user_traits": ""
}

User query:: can you go from a associates degree to a master degree
Output: {
    "user_traits": ""
}

User query:: can you write code create a website by using Flutter, Dart for me ?
Output: {
    "user_traits": ""
}

User query:: I want to go on a diet, what food is good?
Output: {
    "user_traits": "wants to go on a diet"
}

User query:: List of low carb vegan foods
Output: {
    "user_traits": ""
}

User query:: Give me example for architecture design
Output: {
    "user_traits": ""
}

User query:: Write a story about my life
Output: {
    "user_traits": ""
}

User query:: I want a description of a supermarket app
Output: {
    "user_traits": ""
}

User query:: I am an America evaluating if migrating to China. Can you tell me the social problems of China?
Output: {
    "user_traits": "is American | evaluating migration to China"
}"""


FINETUNE_ENDING_PROMPT_TOKEN = "\n\n###\n\n"
FINETUNE_STARTING_COMPLETION_TOKEN = " "
FINETUNE_ENDING_COMPLETION_TOKEN = "\n"

TRAITS_EXTRACTION_FINETUNE_TEMPLATE = (
    "User query: {query}" + FINETUNE_ENDING_PROMPT_TOKEN
)

TRAITS_EXTRACTION_CHAT_FINETUNE_SYS_PROMPT = "Extract different user traits from their queries. Do not assume things that they do not explicitly say themselves. Separate different facts with a |."

PERSONALIZABLE_QUERY_CLASSIFICATION_FINETUNE_TEMPLATE = (
    "User profile: {user_profile}\nUser query: {query}" + FINETUNE_ENDING_PROMPT_TOKEN
)

PERSONALIZABLE_QUERY_CLASSIFICATION_CHAT_FINETUNE_SYS_PROMPT = "You are a machine learning model that predicts whether personalized information from the user_profile is required for answering the given query."

PERSONALIZABLE_QUERY_CLASSIFICATION_INCONTEXT_CHAT_TEMPLATE = """You are a machine learning model that predicts whether personalized information from the user_profile is required for answering the given query.
Your results should be in this json format (properly formatted with quotes and special characters escaped):
{
    "is_personalizable_query": boolean_value denoting whether personalized information is useful for this query
}

Examples:
###
user_profile: I'm a 45-year-old software engineer living in Seattle. I have two kids, ages 8 and 12. I'm allergic to peanuts and enjoy hiking on weekends.
query: What activities can I do with my family this weekend?
output: {
    "is_personalizable_query": true
}

###
user_profile: I am Jack Rose. I am a freelance graphic designer based in Paris. I speak French and English fluently. I'm a vegetarian and love to travel.
query: Where am I based?
output: {
    "is_personalizable_query": true
}

###
user_profile: I have diabetes and need to watch my sugar intake. I enjoy gardening and reading mystery novels.
query: What kind of snacks can I enjoy?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm an 18-year-old high school student in Toronto. I play basketball for my school team and I'm interested in studying engineering in college.
query: What are the best engineering programs in my City?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 35-year-old single mother working as a nurse in Chicago. I have a 5-year-old daughter and I'm looking to advance my career in healthcare.
query: What are some good career advancement options for me?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 50-year-old businessman from Tokyo. I travel frequently for work and I'm interested in learning Spanish for an upcoming project in Mexico.
query: What's the best way to learn Spanish quickly?
output: {
    "is_personalizable_query": false
}

###
user_profile: I'm a 22-year-old college student majoring in environmental science. I'm passionate about sustainability and I volunteer at a local wildlife rescue center.
query: How can I reduce my carbon footprint?
output: {
    "is_personalizable_query": false
}

###
user_profile: I'm a 40-year-old chef who owns a small restaurant in New Orleans. I specialize in Cajun cuisine and I'm always looking for new recipe ideas.
query: How old am I?
output: {
    "is_personalizable_query": true
}

###
user_profile: Mi nombre es Justin Claude. Estoy compitiendo en triatlones. Sigo un régimen de entrenamiento estricto y una dieta alta en proteínas.
query: ¿Qué dieta me recomiendas?
output: {
    "is_personalizable_query": verdadero
}

###
user_profile: I have a PhD in Art History and I'm planning an exhibition on Renaissance painters.
query: Who are some underappreciated Renaissance artists?
output: {
    "is_personalizable_query": false
}

###
user_profile: I am Fred Alfredo. I'm an aspiring filmmaker living in Los Angeles.
query: Where do I stay?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 38-year-old stay-at-home dad with twins. I used to work in finance but now I'm focusing on raising my kids and managing our household.
query: Effective time management strategies for people like me.
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 42-year-old veterinarian specializing in exotic animals. I work at a zoo and I'm currently researching reptile diseases.
query: What do I work as?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 33-year-old yoga instructor from India. I've been practicing yoga for 15 years and I'm interested in combining traditional techniques with modern fitness approaches.
query: How can I incorporate more strength training into my work?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 70-year-old retiree living in a small town in Italy. I enjoy painting landscapes and I'm learning to play the piano in my free time.
query: What are some easy piano pieces I can start with?
output: {
    "is_personalizable_query": false
}

###
user_profile: 我是一名29岁的数据科学家，在旧金山的一家科技初创公司工作。我对机器学习充满热情，正在考虑攻读博士学位
query: 我是否应该辞去工作去攻读我所在领域的博士学位
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm Alex Winchester! I'm a 48-year-old single father working as a construction manager. I have two teenage sons and four pre-teen daughters and I'm trying to encourage them to be more physically active.
query: How many kids do I have?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a 36-year-old marine biologist conducting research on coral reefs in Australia. I'm concerned about the impact of climate change on marine ecosystems.
query: What are the most effective methods for coral reef restoration?
output: {
    "is_personalizable_query": false
}

###
user_profile: I'm an architect specializing in sustainable building design. I'm working on a project to create affordable, eco-friendly housing in urban areas.
query: What are the latest innovations that are relevant to my project?
output: {
    "is_personalizable_query": true
}

###
user_profile: I'm a professional gamer who streams on Twitch. I mainly play first-person shooters and battle royale games. I'm looking to expand my audience.
query: How can I grow my Twitch channel?
output: {
    "is_personalizable_query": true
}
"""
QUERY_REWRITING_FINE_TUNE_SYS_PROMPT = """You are a multitask machine learning model that processes user queries and performs two tasks:
1. detect the best-matching intent ID of the current query given the following mapping from intent ID to the corresponding intent.
['AA: Wikipedia and Facts', 'AB: Finance and Crypto', 'AC: Stackoverflow and Coding', 'AD: Live Sports Updates', 'AE: Recipes and Cooking', 'AF: LinkedIn and People', 'AG: Reddit or Advice, Opinion, Reviews', 'AH: Places and Businesses', 'AI: Where to Watch Movies and TV Shows', 'AJ: Generating AI Art and Images', 'AK: Weather', 'AL: Yelp and Business Reviews', 'AM: Social Media: Instagram', 'AN: Image Search', 'AO: Social Media: Twitter', 'AP: Social Media: Facebook', 'AQ: Social Media: TikTok', 'AR: Video Search', 'SA: News and Current Events', 'NA: Creative Writing', 'NB: Request For Rewriting', 'NC: Request For Code', 'ND: Request To Continue', 'NE: Rate Previous Response', 'NF: Computation, Conversions, and Calculations', 'NH: Correct Previous Response', 'NG: Casual Chitchat', 'NI: Linguistic Quiz', 'SX: General Information Search']

2. rewrite the current query into an ideal rewritten query using information from the past queries

Your output should be in the following format:
ID) <ideal rewritten query>
"""

QUERY_REWRITING_ZERO_SHOT_SYS_PROMPT_V1 = """Given a user search query and the past query history, rewrite a refined search query that allows discovering more relevant and informative search results on a web search engine to help answer the given question.
Your new query should include useful keywords that can improve search results relevance.
Your results should be in this json format:
{
    "rationale": "reason for writing the new search query in this way",
    "query": "your new rewritten query optimized for fetching better search engine results"
}
"""

QUERY_REWRITING_ZERO_SHOT_SYS_PROMPT_V2 = """You are a query rewriter module in YOU.com's AI search engine.
Given a user search query and the past query history, rewrite the query into a refined search query that allows discovering more relevant and informative search results on a web search engine to help answer the given question.
Your new query should resolve references to entities in the chat history, and include useful keywords that can improve search results relevance.
Your results should be in this json format (properly formatted with quotes and special characters escaped):
{
    "query": "your new rewritten query optimized for fetching better search engine results"
}

Examples:
Past Queries: ['What is the best way to learn Python?', 'How to start learning Python']
Current Query: courses online
Output: {
    "query": "online Python courses"
}

Past Queries: ['What is the capital of France?', 'France tourism', 'Paris travel guide']
Current Query: hotels there
Output: {
    "query": "hotels in paris"
}

Past Queries: ['How to lose weight fast?', 'Weight loss tips', 'Diet plans for weight loss']
Current Query: healthy food recipes for achieving that
Output: {
    "query": "healthy food recipes for weight loss and diet plans"
}

Past Queries: ['What is machine learning?', 'Machine learning tutorials', 'AI and machine learning']
Current Query: common algorithms
Output: {
    "query": "common machine learning algorithms"
}

Past Queries: ['Gaming laptops under 1000', 'What kind of games can we play in 2024']
Current Query: best laptop for that
Output: {
    "query": "best gaming laptops under 1000 dollars"
}

Past Queries: ['How to learn Spanish?', 'Spanish language resources']
Current Query: aplicaciones gratuitas
Output: {
    "query": "aplicaciones gratis para aprender español"
}

Past Queries: ['Best workout routines', '适合初学者的力量训练']
Current Query: home exercises
Output: {
    "query": "home exercises for strength training"
}

Past Queries: ['Top movies of 2023', 'Best dramas of 2023']
Current Query: recommendations
Output: {
    "query": "movie and drama recommendations for 2023"
}

Past Queries: ['How to invest in stocks?', 'Stock market basics']
Current Query: beginner tips
Output: {
    "query": "beginner tips for stock market investing"
}

Past Queries: ['Yoga benefits', 'Different types of yoga']
Current Query: beginner poses
Output: {
    "query": "beginner yoga poses"
}

Past Queries: ['How to bake a cake?', 'Easy cake recipes']
Current Query: chocolate cake
Output: {
    "query": "easy chocolate cake recipes"
}

Past Queries: ['Best smartphones 2024', 'Smartphone reviews']
Current Query: under 500
Output: {
    "query": "best smartphones under 500 dollars"
}

Past Queries: ['How to meditate?', 'Meditation techniques']
Current Query: for stress relief
Output: {
    "query": "meditation techniques for stress relief"
}

Past Queries: ['History of the "Roman Empire"', 'Important events in "Roman history"']
Current Query: famous leaders
Output: {
    "query": "famous leaders of the \\"Roman Empire\\""
}

Past Queries: ['How to knit?', 'Knitting for beginners']
Current Query: simple patterns
Output: {
    "query": "simple knitting patterns for beginners"
}

Past Queries: ['Best beaches in the world', 'Tropical vacation spots']
Current Query: in Hawaii
Output: {
    "query": "best beaches in Hawaii"
}

Past Queries: ['Top restaurants in New York', 'NYC food guide']
Current Query: Italian cuisine
Output: {
    "query": "top Italian restaurants in New York City"
}

Past Queries: ['How to get rid of acne?', 'Home remedies for acne']
Current Query: natural treatments
Output: {
"query": "natural treatments for acne"
}

Past Queries: ['what is science fiction', 'Classic sci-fi novels']
Current Query: must-read titles
Output: {
"query": "must-read science fiction books"
}

Past Queries: ['How to start a blog?', 'Blogging platforms comparison']
Current Query: tips for beginners
Output: {
"query": "blogging tips for beginners"
}
"""


QWEN2_JINJA_CHAT_TEMPLATE = """{% for message in messages %}{% if loop.first and messages[0]['role'] != 'system' %}{{ '<|im_start|>system
You are a helpful assistant.<|im_end|>
' }}{% endif %}{{'<|im_start|>' + message['role'] + '
' + message['content'] + '<|im_end|>' + '
'}}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant
' }}{% endif %}
"""


DEFAULT_JINJA_CHAT_TEMPLATE = (
    "{% for message in messages %}"
    "{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}"
    "{% endfor %}"
    "{% if add_generation_prompt %}"
    "{{ '<|im_start|>assistant\n' }}"
    "{% endif %}"
)

AB_TEST_NAME_INTENT_PREDICTION = "abIntentL0PredictionV2"
INTENT_PREDICTION_L0 = "ir_ip_l0_classifier_multilingual"

IP_SCORE_THRESHOLD = 0.1
L0_INFERENCE_FIELD = 0
MAX_APP_COUNT = 2

INTENT_LABEL_CLASS_NAMES = [
    "finance",
    "places",
    "images",
    "weather",
    "videos",
    "news",
]

L0_INTENT_LABELS_WITH_DESC = {
    "Product or Service": "Asking about products or services, including specifications and comparisons.",
    "Events": "Inquiring about events, schedules, or dates.",
    "Navigational queries": "Seeking help, specific websites, or navigational information.",
    "Weather": "Asking about the current weather or weather forecasts.",
    "Finance": "Asking about financial information, including stocks, bonds, or mutual funds.",
    "Image Search": "Requests for specific images or types of images.",
    "Video Search": "Requests for videos or information about creating videos.",
    "News": "Asking for the latest news or updates on current events.",
    "General Information Search": "Looking for factual information or answers to general questions.",
    "Generative tasks": "Requesting the AI to create or generate content.",
    "Code and Computation Assistance": "Seeking help with programming or computational tasks.",
    "Chat and Conversation": "Engaging in casual or social interaction with the AI.",
    "People": "Asking for information about individuals, their roles, or biographies.",
    "Places and Local Business": "Seeking information about local businesses or places to visit.",
    "Hobbies and Interests": "Looking for information or tips related to hobbies and personal interests.",
    "Visual Art, Architecture and Design": "Asking about art, architecture, or design.",
    "Gaming Search": "Inquiries and information requests related to video games, including gameplay, game mechanics, and game recommendations",
    "Task-Oriented Assistance": "Asking the AI to perform a specific task.",
    "Learning": "Conversations where the user wants to understand a concept or acquire skills by getting detailed explanation, reasoning, or synthesis.",
    "Adult Content Search": "Requests for pornographic content, including videos, images, and websites.",
    "Music and Lyrics Search": "Requests for information about songs, lyrics, musical compositions, and related content.",
    "Career development": "Seeking advice, resources, or information related to career growth, job opportunities, and professional development.",
}


GENERATIVE_INTENT_LABEL = "Generative tasks"


L0_INTENT_TO_APP_LIST = {
    "Product or Service": "other",
    "Events": "other",
    "Navigational queries": "other",
    "Weather": "weather",
    "Finance": "finance",
    "Image Search": "images",
    "Video Search": "videos",
    "News": "news",
    "General Information Search": "other",
    "Generative tasks": "other",
    "Code and Computation Assistance": "other",
    "Coding and Computation": "other",
    "Chat and Conversation": "other",
    "People": "other",
    "Places and Local Business": "places",
    "Hobbies and Interests": "other",
    "Visual Art, Architecture and Design": "other",
    "Gaming Search": "other",
    "Task-Oriented Assistance": "other",
    "Learning": "other",
    "Adult Content Search": "other",
    "Music and Lyrics Search": "other",
    "Career development": "other",
}

INTENTS_TO_SKIP = ["other"]

NON_SEARCH_INTENTS = ["Chat and Conversation", "Generative tasks"]

AB_TEST_CONTROL = "control"
AB_TEST_TREATMENT = "treatment"
AB_TEST_NEITHER = "neither"
JOIN_CHARACTER_SPACE = " "

INTENT_PREDICTION_L0_READ_TO = 1.0
INTENT_PREDICTION_L0_CONNECTION_TO = 1.0
INTENT_PREDICTION_L1_READ_TO = 1.0
INTENT_PREDICTION_L1_CONNECTION_TO = 1.0
