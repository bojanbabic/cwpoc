from abc import ABC, abstractmethod
from enum import Enum
from typing import Optional

import pandas as pd


class DatasetName(Enum):
    # https://huggingface.co/datasets/databricks/databricks-dolly-15k
    DBX_DOLLY = 0
    # https://huggingface.co/datasets/hotpot_qa
    HOTPOT_QA = 1
    # https://huggingface.co/datasets/natyou/freshqa_10_06
    FRESH_QA = 2
    # https://huggingface.co/datasets/truthful_qa
    TRUTHFUL_QA = 3


class EvalDatasetLoader(ABC):
    def __init__(self, sample_size: Optional[int] = None):
        self.df = self.load()
        if sample_size:
            self.df = self.df.sample(n=sample_size, random_state=0)

    @abstractmethod
    def load(self) -> pd.DataFrame:
        """Loads evaluation dataset from chosen source."""
        ...


class DBXEvalDatasetLoader(EvalDatasetLoader):
    def load(self) -> pd.DataFrame:
        df = load_huggingface_dataset("databricks/databricks-dolly-15k")[
            "train"
        ].to_pandas()
        return df[df["category"] == "open_qa"]


class HotpotQAEvalDatasetLoader(EvalDatasetLoader):
    def load(self) -> pd.DataFrame:
        return load_huggingface_dataset("hotpot_qa", "fullwiki")[
            "validation"
        ].to_pandas()


class FreshQAEvalDatasetLoader(EvalDatasetLoader):
    def load(self) -> pd.DataFrame:
        return load_huggingface_dataset("natyou/freshqa_10_06")["test"].to_pandas()


class TruthfulQAEvalDatasetLoader(EvalDatasetLoader):
    def load(self) -> pd.DataFrame:
        df = load_huggingface_dataset("truthful_qa", "generation")[
            "validation"
        ].to_pandas()
        # Filters questions where ground truth answers are "I have no comment". These don't provide much value in
        # in the context of RAG evals.
        return df[df["best_answer"] != "I have no comment"]


def load_huggingface_dataset(*args, **kwargs):
    # This library requires many dependencies and so we scope it under this function
    from datasets import load_dataset

    return load_dataset(*args, **kwargs)


def create_dataset_loader(
    dataset_name: DatasetName, sample_size=200
) -> EvalDatasetLoader:
    if dataset_name == DatasetName.DBX_DOLLY:
        return DBXEvalDatasetLoader(sample_size=sample_size)
    elif dataset_name == DatasetName.HOTPOT_QA:
        return HotpotQAEvalDatasetLoader(sample_size=sample_size)
    elif dataset_name == DatasetName.FRESH_QA:
        return FreshQAEvalDatasetLoader(sample_size=sample_size)
    elif dataset_name == DatasetName.TRUTHFUL_QA:
        return TruthfulQAEvalDatasetLoader(sample_size=sample_size)

    raise NotImplementedError(f"Dataset {dataset_name} not implemented yet!")
