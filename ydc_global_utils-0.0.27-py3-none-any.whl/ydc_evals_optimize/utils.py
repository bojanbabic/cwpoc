import concurrent
import os
import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Literal, TypeVar

import pandas as pd
from openai import OpenAI
from openai.types.chat import ChatCompletionMessageParam

client = OpenAI(
    api_key=os.environ["OPENAI_API_KEY"],
    organization=os.environ["OPENAI_ORGANIZATION_ID"],
)

T = TypeVar("T")


def query_openai_model(
    messages: list[ChatCompletionMessageParam],
    model: str = "gpt-3.5-turbo",
    max_output_tokens: int = 512,
    temperature: float = 0.0,
    timeout: int = 30,
    response_type: Literal["text", "json_object"] = "text",
) -> dict:
    response_format = {"type": response_type}
    response = client.chat.completions.create(
        model=model,
        temperature=temperature,
        messages=messages,
        max_tokens=max_output_tokens,
        timeout=timeout,
        response_format=response_format,  # type: ignore[call-overload]
    )
    return dict(response.choices[0].message)


def prompt_to_messages(prompt: str) -> list[ChatCompletionMessageParam]:
    formatted_messages = []
    for line in prompt.split("<||im_start||>"):
        if len(line.splitlines()) > 1:
            all_lines = line.splitlines()
            agent = all_lines[0]
            last_token_index = all_lines.index("<||im_end||>")
            message = "\n".join(all_lines[1:last_token_index]).strip()
            formatted_messages.append({"role": agent, "content": message})
    return formatted_messages  # type: ignore[return-value]


def replace_markdown_links_with_text(sentence: str, replacement: str) -> str:
    return re.sub(r"\[((?:\[)?([^]]+)(?:\])?)\]\(([^)]+)\)", replacement, sentence)


def remove_markdown_links(text):
    markdown_link = re.compile(r"\[(.*?)\]\((?:http(s)?|file):\/\/(.*?)\)")
    return markdown_link.sub("", text)


def construct_turbo_history(chat_history):
    history = "\n\n".join(
        [
            f"\n<||im_start||>user\n{turn.get('question', '')}\n<||im_end||>\n<||im_start||>assistant\n{remove_markdown_links(turn.get('answer', ''))}\n<||im_end||>\n"
            for turn in chat_history
        ]
    )
    return history


def deduplicate_list(
    items: List[T],
    # pylint: disable-next=unnecessary-lambda
    key: Callable[[T], str] = lambda x: str(x),
) -> List[T]:
    seen_keys = set()
    deduped_items = []
    for item in items:
        computed_key = key(item)
        if computed_key not in seen_keys:
            seen_keys.add(computed_key)
            deduped_items.append(item)
    return deduped_items


def pd_parallel_apply(
    df: pd.DataFrame,
    run_fn: Callable[[pd.Series], Dict[str, Any]],
    *args,
    max_workers: int = 8,
) -> pd.DataFrame:
    data = []
    with ThreadPoolExecutor(max_workers=max_workers) as tpe:
        future_to_row_map = {
            tpe.submit(run_fn, row, *args): (i, row)
            for i, (_, row) in enumerate(df.iterrows())
        }
        for future in concurrent.futures.as_completed(future_to_row_map):
            i, row = future_to_row_map[future]
            data_dict = future.result()
            data.append((i, data_dict))

            if i % 50 == 0 and i > 0:  # type: ignore
                print(f"Completed {len(data)}/{len(df)}", end="\r")

    # Needed because the concurrency changed up the order
    sorted_data = [d for i, d in sorted(data, key=lambda x: x[0])]
    pred_df = pd.DataFrame(sorted_data)

    # Reset pred_df's index
    # Drop overlapping columns in df first
    df = df.drop(columns=pred_df.columns, errors="ignore")

    combined_df = pd.concat([df, pred_df.set_index(df.index)], axis=1)
    return combined_df
