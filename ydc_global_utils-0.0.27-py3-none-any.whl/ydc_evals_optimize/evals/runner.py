import subprocess
from typing import Tuple

import numpy as np
import pandas as pd

from ydc_evals_optimize.evals.base import Evaluation
from ydc_evals_optimize.evals.loggers import (
    EvaluationLogger,
    MLflowEvaluationLogger,
)

AggregatedMetricsForEval = dict
AggregatedMetricsForEvals = list[AggregatedMetricsForEval]
EvalResults = list[pd.DataFrame]


class EvaluationRunner:
    def __init__(self, evaluations: list[Evaluation], loggers: list[EvaluationLogger]):
        self.evaluations = evaluations
        self.loggers = loggers

        num_mlflow_loggers = sum(
            isinstance(logger, MLflowEvaluationLogger) for logger in loggers
        )
        assert num_mlflow_loggers <= 1, "Only support 1 MLflowEvaluationLogger at once"

    def run(
        self, run_name: str, run_params: dict
    ) -> Tuple[AggregatedMetricsForEvals, EvalResults]:
        dataset_params = {
            f"dataset_{e.name}": e.get_dataset_size() for e in self.evaluations
        }
        git_params = get_git_params()
        self._setup_loggers(run_name)
        self._log_params({**run_params, **dataset_params, **git_params})

        all_eval_dfs = []
        all_eval_results = []
        for evaluation in self.evaluations:
            # We save intermediate steps in case it breaks
            pred_df = evaluation.inference()
            pred_df = pred_df.replace({np.nan: None})
            self._log_dataframe(pred_df, evaluation.name)

            eval_df = evaluation.evaluate(pred_df)
            eval_df = eval_df.replace({np.nan: None})
            self._log_dataframe(eval_df, evaluation.name)
            all_eval_dfs.append(eval_df)

            eval_results = evaluation.summarize_eval_results(eval_df)
            self._log_metrics(eval_results)
            all_eval_results.append(eval_results)

        self._teardown_loggers()
        return all_eval_results, all_eval_dfs

    def _setup_loggers(self, run_name: str) -> None:
        for logger in self.loggers:
            logger.setup_logger(run_name)

    def _teardown_loggers(self) -> None:
        for logger in self.loggers:
            logger.teardown_logger()

    def _log_params(self, params: dict) -> None:
        for logger in self.loggers:
            logger.log_params(params)

    def _log_dataframe(self, df: pd.DataFrame, name: str) -> None:
        for logger in self.loggers:
            logger.log_dataframe(df, name)

    def _log_metrics(self, results: dict) -> None:
        for logger in self.loggers:
            logger.log_metrics(results)


def gather_all_eval_results_into_single_dict(eval_results_list: list[dict]) -> dict:
    # TODO: Namespace the keys to prevent clashing
    all_eval_results = {}
    for eval_results in eval_results_list:
        all_eval_results.update(eval_results)
    return all_eval_results


def get_git_branch() -> str:
    try:
        return (
            subprocess.check_output(["git", "branch", "--show-current"])
            .decode("ascii")
            .strip()
        )
    except Exception:
        return ""


def get_git_revision_hash() -> str:
    try:
        return (
            subprocess.check_output(["git", "rev-parse", "HEAD"])
            .decode("ascii")
            .strip()
        )
    except Exception:
        return ""


def get_git_params() -> dict:
    return {
        "git_branch": get_git_branch(),
        "git_revision_hash": get_git_revision_hash(),
    }
