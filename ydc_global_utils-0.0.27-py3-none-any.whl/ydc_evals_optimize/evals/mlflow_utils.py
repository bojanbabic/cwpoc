from datetime import datetime
from typing import Optional, List

import mlflow
import pandas as pd


def mlflow_search_runs(
    experiment_names: Optional[List[str]] = None,
    filter_str: str = "",
    start: Optional[datetime] = None,
    end: Optional[datetime] = None,
) -> pd.DataFrame:
    mlflow.set_tracking_uri("databricks")

    # Search experiment runs within a time range
    if start and "attributes.start_time >" not in filter_str:
        start_ts = int(start.timestamp() * 1000)
        prefix = " and " if filter_str else ""
        filter_str += prefix + f"attributes.start_time > {start_ts}"

    if end and "attributes.start_time <" not in filter_str:
        end_ts = int(end.timestamp() * 1000)
        prefix = " and " if filter_str else ""
        filter_str += prefix + f"attributes.start_time < {end_ts}"

    return mlflow.search_runs(
        experiment_names=experiment_names, filter_string=filter_str
    )
