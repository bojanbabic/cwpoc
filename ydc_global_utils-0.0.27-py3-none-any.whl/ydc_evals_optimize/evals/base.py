import logging
import time
import traceback
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Tuple

import pandas as pd

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
)
from ydc_evals_optimize.metrics.utils import round_numeric_value
from ydc_evals_optimize.utils import pd_parallel_apply

logger = logging.getLogger(__package__)


class ModelVariant(ABC):
    def __init__(self, name: str, params: dict):
        self.name = name
        self.params = params

    @abstractmethod
    def inference_on_row(self, row: pd.Series) -> dict:
        ...


class Evaluation:
    """
    Evaluation runs inference in parallel on the DataFrame `df` using `inference_on_row`.
    It then computes metrics in parallel based on the defined `metrics` attribute.
    """

    def __init__(
        self,
        name: str,
        model_variant: ModelVariant,
        dataset_df: pd.DataFrame,
        metrics: list[BaseMetricComputor],
        num_workers: int,
    ):
        self.name = name
        self.model_variant = model_variant
        self.dataset_df = dataset_df
        self.metrics = metrics
        self.num_workers = num_workers

    def inference_on_row(self, row: pd.Series) -> dict:
        return self.model_variant.inference_on_row(row)

    def evaluate_metrics_on_row(self, row: pd.Series) -> dict:
        all_metric_results: dict = {}
        for metric in self.metrics:
            try:
                metric_input = metric.validate_metric_input(row.to_dict())
                result = metric.compute_metric(metric_input)
            except Exception:
                logger.error(
                    "Failed metric %(metric_name)s",
                    {"metric_name": metric.name},
                    exc_info=True,
                )
                result = {f"{metric.name}_error": traceback.format_exc()}
            all_metric_results.update(result)
        return all_metric_results

    def inference(self) -> pd.DataFrame:
        start = time.time()
        out_df = pd_parallel_apply(
            self.dataset_df, self.inference_on_row, max_workers=self.num_workers
        )
        print(f"Inference time: {(time.time() - start) / 60:.2f} mins")
        return out_df

    def evaluate(self, pred_df: pd.DataFrame) -> pd.DataFrame:
        start = time.time()
        out_df = pd_parallel_apply(
            pred_df, self.evaluate_metrics_on_row, max_workers=self.num_workers
        )
        print(f"Evaluation time: {(time.time() - start) / 60:.2f} mins")
        return out_df

    def summarize_eval_results(self, eval_df: pd.DataFrame) -> dict:
        n_dataset = len(eval_df)
        summary_str = f"Dataset size: {n_dataset}\n"
        summarized_results: dict = {}
        for metric in self.metrics:
            try:
                # ==== Evaluate on full dataset ====
                aggregated_metrics = metric.metrics_aggregation_strategy(eval_df)
                summarized_results.update(
                    {
                        name: value_or_error[0]
                        for name, value_or_error in aggregated_metrics.items()
                    }
                )
                for metric_name, (
                    metric_value,
                    num_errors,
                ) in aggregated_metrics.items():
                    prettified_metric_value = round_numeric_value(metric_value)
                    error_str = f" (⚠️ {num_errors} failed)" if num_errors else ""
                    summary_str += (
                        f"{metric_name:<40}: {prettified_metric_value}{error_str}\n"
                    )

                # ==== Evaluate on stratified groups ====
                prefix = "  "
                last_stratification_group = None
                n_within_group = None
                stratified_dfs = metric.stratify_dataframe(eval_df)
                stratification_group_to_sub_group_aggregated_metrics: dict[
                    str, list[Tuple[str, AggregatedMetricsAndErrors]]
                ] = defaultdict(list)
                for (
                    stratification_group,
                    stratification_sub_group,
                    stratified_df,
                ) in stratified_dfs:
                    if last_stratification_group != stratification_group:
                        # If stratification was not defined properly, we would not make the full dataset
                        if n_within_group is not None and n_within_group != n_dataset:
                            summary_str += (
                                f"{prefix}🚨 Warning: Stratification group {stratification_group}"
                                f" only has {n_within_group} / {n_dataset} examples\n"
                            )

                        last_stratification_group = stratification_group
                        n_within_group = 0
                        summary_str += (
                            f"{prefix}==== Group: {stratification_group} ====\n"
                        )

                    assert n_within_group is not None
                    n_within_sub_group = len(stratified_df)
                    n_within_group += n_within_sub_group
                    summary_str += f"{prefix}== (N = {n_within_sub_group}) Sub Group: {stratification_sub_group} ==\n"

                    aggregated_metrics_for_group = metric.metrics_aggregation_strategy(
                        stratified_df
                    )
                    for metric_name, (
                        metric_value,
                        num_errors,
                    ) in aggregated_metrics_for_group.items():
                        prettified_metric_value = round_numeric_value(metric_value)
                        error_str = f" (⚠️ {num_errors} failed)" if num_errors else ""
                        summary_str += f"{prefix}{metric_name:<38}: {prettified_metric_value}{error_str}\n"

                    stratification_group_to_sub_group_aggregated_metrics[
                        stratification_group
                    ].append((stratification_sub_group, aggregated_metrics_for_group))

                # ==== Getting metrics for each stratified group and provide macro average ====
                for (
                    stratification_group,
                    _aggregated_metrics_for_group_list,
                ) in stratification_group_to_sub_group_aggregated_metrics.items():
                    metric_values_across_sub_groups = defaultdict(list)
                    for (
                        stratification_sub_group,
                        _aggregated_metrics_for_sub_group,
                    ) in _aggregated_metrics_for_group_list:
                        for (
                            metric_name,
                            value_or_error,
                        ) in _aggregated_metrics_for_sub_group.items():
                            summarized_results[
                                f"{metric_name}_WHEN_{stratification_group}_IS_{stratification_sub_group}"
                            ] = value_or_error[0]
                            metric_values_across_sub_groups[metric_name].append(
                                value_or_error[0]
                            )

                    for (
                        metric_name,
                        metric_values,
                    ) in metric_values_across_sub_groups.items():
                        try:
                            macro_average = sum(metric_values) / len(metric_values)
                        except Exception:
                            macro_average = None
                        summarized_results[
                            f"{metric_name}_MACRO_{stratification_group}"
                        ] = macro_average

            except Exception:
                logger.error(
                    "Failed to summarize metric: %(metric_name)s",
                    {"metric_name": metric.name},
                    exc_info=True,
                )
                continue

        print(f"==== Summary ====\n{summary_str}")
        summarized_results["summary"] = summary_str
        return summarized_results

    def get_dataset_size(self) -> int:
        return len(self.dataset_df)
