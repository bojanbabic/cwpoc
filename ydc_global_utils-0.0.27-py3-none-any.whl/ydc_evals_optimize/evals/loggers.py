import os
from abc import ABC, abstractmethod
from pathlib import Path

import mlflow
import pandas as pd

from ydc_evals_optimize.metrics.utils import round_numeric_values


class EvaluationLogger(ABC):
    @abstractmethod
    def setup_logger(self, run_name: str):
        ...

    @abstractmethod
    def teardown_logger(self):
        ...

    @abstractmethod
    def log_params(self, params: dict):
        ...

    @abstractmethod
    def log_dataframe(self, df: pd.DataFrame, name: str):
        ...

    @abstractmethod
    def log_metrics(self, metrics: dict):
        ...


class MLflowEvaluationLogger(EvaluationLogger):
    def __init__(
        self,
        results_dir: str,
        experiment_name: str,
        tracking_uri: str = "databricks",
        should_save_dataframe_locally: bool = True,
        should_log_dataframe_to_cloud: bool = True,
        should_log_dataframe_as_table: bool = False,
    ):
        os.makedirs(results_dir, exist_ok=True)
        self.results_dir = results_dir
        self.tracking_uri = tracking_uri
        self.experiment_name = experiment_name
        self.should_save_dataframe_locally = should_save_dataframe_locally
        self.should_log_dataframe_to_cloud = should_log_dataframe_to_cloud
        self.should_log_dataframe_as_table = should_log_dataframe_as_table

    def setup_logger(self, run_name: str):
        mlflow.set_tracking_uri(self.tracking_uri)
        mlflow.set_experiment(self.experiment_name)
        mlflow.start_run(run_name=run_name)

    def teardown_logger(self):
        mlflow.end_run()

    def log_params(self, params: dict):
        mlflow.log_params(params)

    def log_dataframe(self, df: pd.DataFrame, name: str):
        dest_path = str(Path(self.results_dir) / f"{name}.csv")
        if self.should_save_dataframe_locally:
            df.to_csv(dest_path, index=False)
        if self.should_log_dataframe_to_cloud:
            mlflow.log_artifact(dest_path)
            if self.should_log_dataframe_as_table:
                mlflow.log_table(df, artifact_file=f"{name}.json")

    def log_metrics(self, metrics: dict):
        mlflow_filter_and_log_metrics(metrics)
        if "summary" in metrics:
            mlflow.log_text(metrics["summary"], "summary.txt")


class LocalFileEvaluationLogger(EvaluationLogger):
    def __init__(self, results_dir: str):
        os.makedirs(results_dir, exist_ok=True)
        self.results_dir = results_dir

        self.params_list: list[dict] = []
        self.metrics_list: list[dict] = []

    def setup_logger(self, run_name: str):
        pass

    def teardown_logger(self):
        pass

    def log_params(self, params: dict):
        self.params_list.append(params)
        pd.DataFrame(self.params_list).to_csv(self.params_csv_path, index=False)

    def log_dataframe(self, df: pd.DataFrame, name: str):
        dest_path = str(Path(self.results_dir) / f"{name}.csv")
        df.to_csv(dest_path, index=False)

    def log_metrics(self, metrics: dict):
        self.metrics_list.append(metrics)
        pd.DataFrame(self.metrics_list).to_csv(self.metrics_csv_path, index=False)

    def read_params(self) -> dict:
        return pd.read_csv(self.params_csv_path).iloc[0].to_dict()

    def read_metrics(self) -> dict:
        return pd.read_csv(self.metrics_csv_path).iloc[0].to_dict()

    def read_dataframes(
        self, exclude_params_and_metrics: bool = True
    ) -> list[tuple[Path, pd.DataFrame]]:
        dfs = []
        paths_to_exclude = (
            [self.params_csv_path, self.metrics_csv_path]
            if exclude_params_and_metrics
            else []
        )
        for csv_path in Path(self.results_dir).glob("**/*.csv"):
            if str(csv_path) not in paths_to_exclude:
                dfs.append((csv_path, pd.read_csv(csv_path)))
        return dfs

    @property
    def params_csv_path(self) -> str:
        return f"{self.results_dir}/params.csv"

    @property
    def metrics_csv_path(self) -> str:
        return f"{self.results_dir}/metrics.csv"


def remove_non_numeric_values(data: dict) -> dict[str, int | float]:
    return {k: v for k, v in data.items() if isinstance(v, int) or isinstance(v, float)}


def mlflow_filter_and_log_metrics(metrics: dict, should_round_values: bool = True):
    valid_metrics = remove_non_numeric_values(metrics)
    if should_round_values:
        valid_metrics = round_numeric_values(valid_metrics)
    mlflow.log_metrics(valid_metrics)
