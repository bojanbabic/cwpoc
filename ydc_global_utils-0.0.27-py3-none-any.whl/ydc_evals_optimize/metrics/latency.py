from typing import Optional

import numpy as np
import pandas as pd

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    StratificationStrategy,
)


class LatencyMetric(BaseMetricComputor[dict]):
    metric_input_type = dict

    def __init__(
        self,
        name: str = "latency",
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, None, stratify_by)

    def compute_metric(self, metric_input: dict, **kwargs) -> dict:
        return {self.name: metric_input[self.name]}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        latencies = df[self.name].dropna().tolist()
        num_errors = df[self.name].isna().sum()
        p50 = np.percentile(latencies, 50) if latencies else None
        p90 = np.percentile(latencies, 90) if latencies else None
        p95 = np.percentile(latencies, 95) if latencies else None
        p99 = np.percentile(latencies, 99) if latencies else None
        return {
            f"{self.name}_p50": (p50, num_errors),
            f"{self.name}_p90": (p90, num_errors),
            f"{self.name}_p95": (p95, num_errors),
            f"{self.name}_p99": (p99, num_errors),
        }
