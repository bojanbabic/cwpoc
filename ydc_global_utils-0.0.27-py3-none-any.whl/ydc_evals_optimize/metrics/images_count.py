from typing import Optional, Callable

import pandas as pd
from pydantic import BaseModel

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.metrics.utils import (
    get_number_of_normal_and_broken_image_links,
    is_likely_to_be_wiki_link,
)


class ImagesCountMetricInput(BaseModel):
    generated_response: str


class ImagesCountMetric(BaseMetricComputor[ImagesCountMetricInput]):
    metric_input_type = ImagesCountMetricInput

    def __init__(
        self,
        name: str = "images_count",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
        # Currently we only get images from Wikimedia
        is_valid_link_fn: Optional[Callable[[str], bool]] = is_likely_to_be_wiki_link,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.is_valid_link_fn = is_valid_link_fn

    def compute_metric(self, metric_input: ImagesCountMetricInput, **kwargs) -> dict:
        (
            num_images,
            num_broken_images,
            broken_image_urls,
        ) = get_number_of_normal_and_broken_image_links(
            metric_input.generated_response, self.is_valid_link_fn
        )
        return {
            self.name: num_images,
            f"{self.name}_broken": num_broken_images,
            f"{self.name}_broken_urls": broken_image_urls,
            "images_exist": int(num_images > 0),
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return {
            **mean_metrics_aggregation_strategy(df, self.name),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_broken"),
            **mean_metrics_aggregation_strategy(df, "images_exist"),
        }
