from abc import ABC, abstractmethod
from typing import Optional

import pandas as pd
from pydantic import BaseModel
from retry import retry

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.utils import (
    construct_turbo_history,
    prompt_to_messages,
    query_openai_model,
    replace_markdown_links_with_text,
)


class PairwisePreferencesMetricInput(BaseModel):
    question: str
    chat_history: list[dict]
    response1: str
    response2: str


class PairwisePreferencesMetric(BaseMetricComputor[PairwisePreferencesMetricInput]):
    metric_input_type = PairwisePreferencesMetricInput

    def __init__(
        self,
        preference_rater: "PairwisePreferenceRater",
        should_use_both_orderings: bool = False,
        name: str = "pairwise_preference",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.preference_rater = preference_rater
        self.should_use_both_orderings = should_use_both_orderings

    def compute_metric(
        self, metric_input: PairwisePreferencesMetricInput, **kwargs
    ) -> dict:
        response1 = replace_markdown_links_with_text(metric_input.response1, "")
        response2 = replace_markdown_links_with_text(metric_input.response2, "")
        out = self.preference_rater.rate(
            metric_input.question, metric_input.chat_history, response1, response2
        )
        scores = [out.score]
        reasons = [out.reason]
        if self.should_use_both_orderings:
            # Reverse the ordering
            out_reversed = self.preference_rater.rate(
                metric_input.question, metric_input.chat_history, response2, response1
            )
            # We need to do 1 - score because we have reversed the responses
            scores.append(
                (1 - out_reversed.score)
                if out_reversed.score is not None
                else out_reversed.score
            )
            reasons.append(
                ("(NOTE) A & B have been swapped\n" + out_reversed.reason)
                if out_reversed.reason is not None
                else out_reversed.reason
            )

        valid_scores = [score for score in scores if score is not None]
        if not valid_scores:
            raise RuntimeError(f"There are no valid scores. Reasons: {reasons}")

        avg_score = sum(valid_scores) / len(valid_scores)

        return {
            f"{self.name}_avg_score": avg_score,
            f"{self.name}_scores": scores,
            f"{self.name}_reasons": reasons,
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, f"{self.name}_avg_score")


class PreferenceOutput(BaseModel):
    score: Optional[float]
    reason: Optional[str]


class PairwisePreferenceRater(ABC):
    @abstractmethod
    def rate(
        self, question: str, chat_history: list[dict], response1: str, response2: str
    ) -> PreferenceOutput:
        ...


class CoTPairwisePreferenceRater(PairwisePreferenceRater):
    # TODO: Check human alignment
    MODEL_NAME = "gpt-4-1106-preview"
    MAX_OUTPUT_TOKENS = 512
    TIMEOUT = 45
    PROMPT_TEMPLATE = """<||im_start||>system
You are a helpful assistant.
<||im_end||>
{history}
<||im_start||>user
Current question:
{question}

Given the current question and past chat, which of the following responses is better in terms of relevancy, comprehensiveness and persuasiveness? Think about it step by step and then answer "A", "B" or "C". Do not write anything else after choosing A/B/C.
(A)
\"""
{response1}
\"""
(B)
\"""
{response2}
\"""
(C)
Both of the above are equally good.

RESPONSE FORMAT:
Reason: (Provide your reason for your decision)
Choice: (The best response, A/B/C)
<||im_end||>
<||im_start||>assistant
"""

    def __init__(self, prompt_template: str = PROMPT_TEMPLATE):
        self.prompt_template = prompt_template

    @retry(tries=3, delay=1, backoff=2)
    def rate(
        self, question: str, chat_history: list[dict], response1: str, response2: str
    ) -> PreferenceOutput:
        # Score of 1.0 if response1 > response2 and 0.0 vice versa. 0.5 if tie.
        llm_output = self._call_llm(question, chat_history, response1, response2)
        return self._parse_llm_output(llm_output)

    def _parse_llm_output(self, llm_output: str) -> PreferenceOutput:
        chunks = llm_output.split("Choice:")

        raw_reason = "".join(chunks[:-1])
        reason = (
            raw_reason[len("Reason:") :]
            if raw_reason.startswith("Reason:")
            else raw_reason
        )
        reason = reason.strip()

        choice = chunks[-1].strip()
        score = {
            "A": 1.0,
            "B": 0.0,
            "C": 0.5,
        }.get(choice)
        return PreferenceOutput(score=score, reason=reason)

    def _call_llm(
        self, question: str, chat_history: list[dict], response1: str, response2: str
    ) -> str:
        history_context = construct_turbo_history(chat_history)
        prompt = self.prompt_template.format(
            question=question,
            history=history_context,
            response1=response1,
            response2=response2,
        )
        messages = prompt_to_messages(prompt)
        response = query_openai_model(
            messages,
            model=self.MODEL_NAME,
            max_output_tokens=self.MAX_OUTPUT_TOKENS,
            timeout=self.TIMEOUT,
        )
        return response["content"]


if __name__ == "__main__":
    rater = CoTPairwisePreferenceRater()
    out = rater.rate("who are you?", [], "I am ABC", "I am XYZ")
    print(out)
