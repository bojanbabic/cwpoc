import logging
from typing import List, Optional

import pandas as pd
from pydantic import BaseModel
from retry import retry

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.metrics.utils import EvaluationPrompt
from ydc_evals_optimize.utils import query_openai_model

logger = logging.getLogger(__package__)


@retry(tries=3, delay=20, backoff=3)
def query_openai_model_decorated(messages):
    return query_openai_model(messages=messages, model="gpt-4o", temperature=0)


class ListWiseSearchRelevanceMetricInput(BaseModel):
    question: str
    search_results: List[str]


USER_PROMPT_TEMPLATE = """
Query: `{question}`

Relevance Instructions:
```
{context}
```

Please evaluate the relevance of each search result below. Output a comma-separated list of 1s and 0s, where 1 means relevant and 0 means not relevant. Do not output any other text.

Search Results:
```
{search_results}
```

For each result, output exactly '1' if it is relevant or '0' if it is not relevant. Separate scores with commas.

Relevance scores (comma-separated 1s and 0s):
"""


class ListWiseSearchRelevanceMetric(
    BaseMetricComputor[ListWiseSearchRelevanceMetricInput]
):
    """Evaluates the relevance of search results for a given query."""

    metric_input_type = ListWiseSearchRelevanceMetricInput

    def __init__(
        self,
        name: str = "search_relevance",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        relevance_instructions: Optional[str] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)

        self.relevance_instructions = (
            relevance_instructions
            if relevance_instructions
            else (
                "A result is relevant if it answers at least one of the core asks of the query"
            )
        )
        self.prompt = EvaluationPrompt(
            system="You will evaluate the relevance of search results to a given query. You will be given instructions in evaluating relevance.",
            user=USER_PROMPT_TEMPLATE,
        )

    def compute_metric(
        self, metric_input: ListWiseSearchRelevanceMetricInput, **kwargs
    ) -> dict:
        formatted_results = "\n".join(
            f"{i+1}. {result}" for i, result in enumerate(metric_input.search_results)
        )

        messages = self.prompt.format(
            question=metric_input.question,
            context=self.relevance_instructions,
            search_results=formatted_results,
        )
        response = query_openai_model_decorated(messages=messages)
        relevance_scores = self.process_response(response)

        return {
            f"{self.name}_scores": relevance_scores,
            f"{self.name}_mean": sum(relevance_scores) / len(relevance_scores),
        }

    def process_response(self, response: dict) -> List[int]:
        """Processes LLM response and extracts relevance scores."""
        answer = response["content"].strip()
        try:
            scores = [int(score.strip()) for score in answer.split(",")]
            return scores
        except ValueError:
            logger.error(
                "Error parsing relevance scores: %(answer)s",
                {"answer": answer},
                exc_info=True,
            )
            raise

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, f"{self.name}_mean")
