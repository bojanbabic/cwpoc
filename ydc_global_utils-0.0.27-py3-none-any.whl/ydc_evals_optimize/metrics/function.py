from typing import Any, Callable, Literal, Optional

import pandas as pd

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
    sum_metrics_aggregation_strategy,
)


class FunctionMetric(BaseMetricComputor[dict]):
    metric_input_type = dict

    def __init__(
        self,
        name: str,
        fn: Callable[[dict], Any],
        aggregation: Literal["mean", "sum"]
        | Callable[[pd.DataFrame], AggregatedMetricsAndErrors] = "mean",
        is_none_considered_failure: bool = False,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        # No point to set metric_input_mapping since remapping fields does nothing here
        super().__init__(name, None, stratify_by)
        self.is_none_considered_failure = is_none_considered_failure
        self.fn = fn
        self.aggregation = aggregation

    def compute_metric(self, metric_input: dict, **kwargs) -> dict:
        return {self.name: self.fn(metric_input)}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        if self.aggregation == "mean":
            return mean_metrics_aggregation_strategy(
                df,
                self.name,
                is_none_considered_failure=self.is_none_considered_failure,
            )
        elif self.aggregation == "sum":
            return sum_metrics_aggregation_strategy(
                df,
                self.name,
                is_none_considered_failure=self.is_none_considered_failure,
            )
        else:
            assert callable(self.aggregation)
            return self.aggregation(df)
