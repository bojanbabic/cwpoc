import logging
import re
from typing import Optional, Callable
from urllib.parse import urlparse

from pydantic import BaseModel


def round_numeric_value(val: float) -> float:
    try:
        if val <= 1e-3:
            return val
        elif 1e-3 < val <= 1.0:
            return round(val, 3)
        elif 1 < val <= 10.0:
            return round(val, 2)
        elif 10 < val <= 100.0:
            return round(val, 1)
        else:
            return int(val)
    except ValueError:
        # ValueError can be triggered if we get NaN
        return val


def round_numeric_values(data: dict[str, int | float]) -> dict[str, int | float]:
    return {k: round_numeric_value(v) for k, v in data.items()}


def get_number_of_citations(
    answer: str, unique_citation_ids: bool = True, unique_web_pages: bool = False
) -> int:
    markdown_link_regex = re.compile(
        r"\[\[(\d{1,3})\]\]\((?:http(s)?|file):\/\/([^\[]*?)\)"
    )
    markdown_link_matches = markdown_link_regex.findall(answer)

    if unique_web_pages:
        web_pages = []
        for match in markdown_link_matches:
            try:
                parsed = urlparse(f"http://{match[2]}")
                web_pages.append(f"{parsed.netloc}/{parsed.path}")
            except Exception:
                continue
        return len(set(web_pages))
    else:
        citation_ids = [match[0] for match in markdown_link_matches]
        if unique_citation_ids:
            return len(set(citation_ids))
        else:
            return len(citation_ids)


def get_number_of_broken_citations(answer: str) -> int:
    non_markdown_link_regex = re.compile(
        r"\[\[\d{1,3}\]\](?!\((?:http(s)?|file):\/\/([^\[]*?)\))"
    )
    return len(non_markdown_link_regex.findall(answer))


def get_number_of_normal_and_broken_image_links(
    answer: str, is_valid_link_fn: Optional[Callable[[str], bool]] = None
) -> tuple[int, int, list[str]]:
    # We match for a space (\s) at the end because there are some image links
    # that do not get closed, we want to recognize those as broken images too.
    partial_image_link_regex = re.compile(r"!\[(.*?)\]\((.*?)(\)|\s)")
    image_matches = partial_image_link_regex.findall(answer)

    num_normal_images = 0
    broken_image_urls = []
    for match in image_matches:
        image_url = match[1] or ""
        is_whitespace = bool(re.match(r"\s", match[2]))
        if is_whitespace:
            broken_image_urls.append(image_url + match[2])
            continue

        if is_valid_link_fn:
            if is_valid_link_fn(image_url):
                num_normal_images += 1
            else:
                broken_image_urls.append(image_url)
        else:
            if re.match(r"https?://", image_url):
                num_normal_images += 1
            else:
                broken_image_urls.append(image_url)

    if broken_image_urls:
        logging.error(
            f"Broken image urls", broken_image_urls=broken_image_urls, answer=answer
        )
    return num_normal_images, len(broken_image_urls), broken_image_urls


def is_likely_to_be_wiki_link(image_url: str) -> bool:
    return bool(re.match(r"https?://", image_url)) and "wiki" in image_url


def get_number_of_proper_and_broken_charts(
    answer: str,
    validate_and_get_chart_image_link_from_json: Callable[[str], Optional[str]],
) -> tuple[int, int]:
    code_block_regex = re.compile(r"```(.*)\n?(.*)\n?```")
    code_block_matches = code_block_regex.findall(answer)
    num_charts = 0
    num_broken_charts = 0
    for code_block_match in code_block_matches:
        code_block_type, content = code_block_match
        try:
            image_link = validate_and_get_chart_image_link_from_json(content)
            has_validation_error = False
        except Exception:
            image_link = None
            has_validation_error = True

        has_high_signal_for_chart_words = any(
            [
                word in content
                for word in ["chart_type", "chart_view", "provenance", "data_table"]
            ]
        )
        if code_block_type == "charts" or has_high_signal_for_chart_words:
            if image_link:
                num_charts += 1
            else:
                num_broken_charts += 1
        else:
            # The JSON is valid but the code block does not start with ```charts
            if not has_validation_error:
                num_broken_charts += 1
    return num_charts, num_broken_charts


class EvaluationPrompt(BaseModel):
    """Class for handling prompt templates and related utilities."""

    system: str
    user: str

    def format(
        self,
        question: Optional[str] = None,
        generated_response: Optional[str] = None,
        reference_answer: Optional[str] = None,
        search_results: Optional[str] = None,
        context: Optional[str] = None,
    ) -> list[dict]:
        """Creates a message suitable for sending to OpenAI.

        Args:
            question: User question
            generated_response: YouChat response to the user question
            reference_answer: Answer to the `question`

        Returns:
            A list with system and user prompts.
        """

        format_data = {}
        if question:
            format_data["question"] = question
        if generated_response:
            format_data["generated_response"] = generated_response
        if reference_answer:
            format_data["reference_answer"] = reference_answer
        if context:
            format_data["context"] = context
        if search_results:
            format_data["search_results"] = search_results

        return [
            {
                "role": "system",
                "content": self.system,
            },
            {
                "role": "user",
                "content": self.user.format(**format_data),
            },
        ]
