from typing import Optional

import pandas as pd
from pydantic import BaseModel

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.metrics.utils import (
    get_number_of_citations,
    get_number_of_broken_citations,
)


class CitationsCountMetricInput(BaseModel):
    generated_response: str


class CitationsCountMetric(BaseMetricComputor[CitationsCountMetricInput]):
    metric_input_type = CitationsCountMetricInput

    def __init__(
        self,
        name: str = "citations_count",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)

    def compute_metric(self, metric_input: CitationsCountMetricInput, **kwargs) -> dict:
        num_citations = get_number_of_citations(
            metric_input.generated_response, unique_citation_ids=True
        )
        num_citations_with_unique_web_pages = get_number_of_citations(
            metric_input.generated_response, unique_web_pages=True
        )
        num_broken_citations = get_number_of_broken_citations(
            metric_input.generated_response
        )
        return {
            self.name: num_citations,
            f"{self.name}_from_unique_web_pages": num_citations_with_unique_web_pages,
            f"{self.name}_broken": num_broken_citations,
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return {
            **mean_metrics_aggregation_strategy(df, self.name),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_from_unique_web_pages"
            ),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_broken"),
        }
