from typing import Literal, Optional

import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    StratificationStrategy,
)


class F1Metric(BaseMetricComputor[dict]):
    metric_input_type = dict

    def __init__(
        self,
        pred_col: str,
        correct_col: str,
        name: str = "f1",
        # Specify average = None to get F1 scores for all classes.
        # If you have a binary class, it is best to use "binary" to return F1 score of positive class.
        average: Optional[
            Literal["binary", "micro", "macro", "samples", "weighted"]
        ] = None,
        should_explode_cols: bool = False,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, None, stratify_by)
        self.pred_col = pred_col
        self.correct_col = correct_col
        self.average = average
        self.should_explode_cols = should_explode_cols

    # The F1 is computed on the aggregate level, so we don't have to compute more per row
    def compute_metric(self, metric_input: dict, **kwargs) -> dict:
        return {}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        if self.should_explode_cols:
            y_pred_with_nans = df[self.pred_col].explode().tolist()
            y_true_with_nans = df[self.correct_col].explode().tolist()
        else:
            y_pred_with_nans = df[self.pred_col].tolist()
            y_true_with_nans = df[self.correct_col].tolist()

        num_errors = 0
        y_true, y_pred = [], []
        for _true, _pred in zip(y_true_with_nans, y_pred_with_nans):
            if is_valid(_true) and is_valid(_pred):
                y_true.append(_true)
                y_pred.append(_pred)
            elif is_valid(_true) and not is_valid(_pred):
                num_errors += 1

        # https://scikit-learn.org/stable/modules/generated/sklearn.metrics.precision_recall_fscore_support.html
        labels = np.unique(y_true).tolist()
        precision, recall, f1, supp = precision_recall_fscore_support(
            y_true, y_pred, labels=labels, average=self.average
        )
        if isinstance(precision, np.ndarray):
            output = {}
            for cls_label, cls_precision, cls_recall, cls_f1, cls_supp in zip(
                labels, precision.tolist(), recall.tolist(), f1.tolist(), supp.tolist()
            ):
                output.update(
                    {
                        f"{self.name}_for_{cls_label}": (cls_f1, num_errors),
                        f"{self.name}_precision_for_{cls_label}": (
                            cls_precision,
                            num_errors,
                        ),
                        f"{self.name}_recall_for_{cls_label}": (cls_recall, num_errors),
                        f"{self.name}_support_for_{cls_label}": (cls_supp, num_errors),
                    }
                )
            output.update(
                {
                    f"{self.name}": (float(f1.mean()), num_errors),
                    f"{self.name}_precision": (float(precision.mean()), num_errors),
                    f"{self.name}_recall": (float(recall.mean()), num_errors),
                    f"{self.name}_support": (int(supp.sum()), num_errors),
                }
            )
            return output
        else:
            return {
                f"{self.name}": (f1, num_errors),
                f"{self.name}_precision": (precision, num_errors),
                f"{self.name}_recall": (recall, num_errors),
                f"{self.name}_support": (len(y_true), num_errors),
            }


def is_valid(val) -> bool:
    return (
        isinstance(val, str)
        or isinstance(val, int)
        or (val is not None and not np.isnan(val))
    )


if __name__ == "__main__":
    import json

    import pandas as pd

    CSV_PATH = "ydc_services/Search/YouChat/Evaluations/eval-data/clarification_question_judge_evals/2024-09-28T21-34-30/sonnet__sys_v0__use_thoughts__score_0_1__xml/clarification_question_judge.csv"
    metric = F1Metric(
        pred_col="pred_importance",
        correct_col="processed_clarification_question_importance",
        average="binary",
    )
    df = pd.read_csv(CSV_PATH)
    print(json.dumps(metric.metrics_aggregation_strategy(df), indent=2))
