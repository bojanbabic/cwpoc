from typing import Callable, Optional

import pytest

from ydc_evals_optimize.metrics.utils import (
    get_number_of_citations,
    get_number_of_broken_citations,
    get_number_of_proper_and_broken_charts,
    get_number_of_normal_and_broken_image_links,
    is_likely_to_be_wiki_link,
)
from ydc_services.Search.YouChat.MultiStepAI.chart_gen.schemas import DataTableChart


@pytest.mark.parametrize(
    "text, is_valid_link_fn, expected_num_image_links, expected_num_broken_image_links",
    [
        # ==== Without link checker function ====
        pytest.param("Hello ![](https://a.com) world", None, 1, 0, id="1"),
        pytest.param("Hello ![Some caption](https://a.com) world", None, 1, 0, id="2"),
        pytest.param("Hello ![](a.com) world", None, 0, 1, id="3"),
        pytest.param("Hello ![Some caption](a.com) world", None, 0, 1, id="4"),
        pytest.param("Hello ![](https://a.com) world ![](a.com)", None, 1, 1, id="5"),
        pytest.param(
            "Hello ![Some caption](https://a.com) world ![Some caption](a.com)",
            None,
            1,
            1,
            id="6",
        ),
        pytest.param(
            "Hello ![](https://a.com) world ![](a.com) ![](https://b.com)",
            None,
            2,
            1,
            id="7",
        ),
        pytest.param(
            "Hello ![](https://a.com world ![](a.com) ![](https://b.com)",
            None,
            1,
            2,
            id="unclosed_bracket",
        ),
        # ==== With wiki link checker function ====
        pytest.param(
            "Hello ![](https://a.com) world ![](a.com) ![](https://b.com)",
            is_likely_to_be_wiki_link,
            0,
            3,
            id="wiki_1",
        ),
        pytest.param(
            "Hello ![](https://wikipedia.com) world ![](wikipedia.com) ![](https://b.com)",
            is_likely_to_be_wiki_link,
            1,
            2,
            id="wiki_2",
        ),
        pytest.param(
            "Hello ![](https://wikipedia.com world ![](wikipedia.com) ![](https://b.com)",
            is_likely_to_be_wiki_link,
            0,
            3,
            id="wiki_unclosed_bracket",
        ),
    ],
)
def test_get_number_of_image_links(
    text: str,
    is_valid_link_fn: Optional[Callable[[str], bool]],
    expected_num_image_links: int,
    expected_num_broken_image_links: int,
):
    (
        num_image_links,
        num_broken_image_links,
        _,
    ) = get_number_of_normal_and_broken_image_links(text, is_valid_link_fn)
    assert (num_image_links, num_broken_image_links) == (
        expected_num_image_links,
        expected_num_broken_image_links,
    )


@pytest.mark.parametrize(
    "text, expected_num_citations, expected_num_broken_citations",
    [
        ("Hello ![](https://a.com) world", 0, 0),
        ("Hello [[1]](http://a.com) world", 1, 0),
        ("Hello [[1]](file://a.com) world", 1, 0),
        ("Hello [[1]](a.com) world", 0, 1),
        ("Hello [[1]](a.com world", 0, 1),
        ("Hello [[1]] world", 0, 1),
        ("Hello [[1]](http://a.com world [[2]](http://b.com)", 1, 1),
        ("Hello [[1]](http://a.com world [[2]](b.com)", 0, 2),
        ("Hello [[1]][[2]][[3]] world", 0, 3),
    ],
)
def test_get_number_of_citations(
    text: str, expected_num_citations: int, expected_num_broken_citations: int
):
    num_citations = get_number_of_citations(text)
    assert num_citations == expected_num_citations

    num_broken_citations = get_number_of_broken_citations(text)
    assert num_broken_citations == expected_num_broken_citations


@pytest.mark.parametrize(
    "text, expected_num_charts, expected_num_broken_charts",
    [
        # Success
        pytest.param(
            """# This is a report
```charts
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement","hue":null},"id":"a/e1e29e1c-27da-4085-9b8f-03755b39d080"}
```
""",
            1,
            0,
            id="normal",
        ),
        # No code block
        pytest.param(
            "Hello ![](https://a.com) world",
            0,
            0,
            id="no_code_block",
        ),
        # Empty JSON
        pytest.param(
            """# This is a report
```charts
{}
```
""",
            0,
            1,
            id="empty_json",
        ),
        # Image link is malformed
        pytest.param(
            """# This is a report
```charts
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement","hue":null},"id":"e1e29e1c-27da-4085-9b8f-03755b39d080"}
```
""",
            0,
            1,
            id="image_link_is_malformed",
        ),
        pytest.param(
            """# This is a report
```charts
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement","hue":null},"id":"z/e1e29e1c-27da-4085-9b8f-03755b39d080"}
```
""",
            0,
            1,
            id="image_link_is_malformed",
        ),
        # No image link
        pytest.param(
            """# This is a report
```charts
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement","hue":null},"id":null}
```
""",
            0,
            1,
            id="no_image_link",
        ),
        # Code block does not start with charts but fails validation
        pytest.param(
            """# This is a report
```
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement","hue":null},"id":"a/e1e29e1c-27da-4085-9b8f-03755b39d080"}
```
""",
            0,
            1,
            id="code_block_does_not_start_with_charts_but_passes_validation",
        ),
        # Code block does not start with charts but passes validation
        pytest.param(
            """# This is a report
```
{}
```
""",
            0,
            0,
            id="code_block_does_not_start_with_charts_but_fails_validation",
        ),
        # JSON is malformed
        pytest.param(
            """# This is a report
```charts
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement",hue:null},"id":"e1e29e1c-27da-4085-9b8f-03755b39d080"}
```
""",
            0,
            1,
            id="json_is_malformed",
        ),
        # Combined
        pytest.param(
            """# This is a report
```charts
{"columns":["Vitamin","Percentage of Population Not Meeting Requirement"],"data_table":[["Vitamin D",94.3],["Vitamin E",88.5],["Vitamin A",43.0],["Vitamin C",38.9]],"provenance":{"1":"https://lpi.oregonstate.edu/mic/micronutrient-inadequacies/overview"},"title":"Common Vitamin Deficiencies in US Population","description":"This chart shows the percentage of the US population not meeting daily requirements for various vitamins, highlighting common deficiencies.","chart_view":{"chart_type":"bar_chart","x":"Vitamin","y":"Percentage of Population Not Meeting Requirement","hue":null},"id":"a/e1e29e1c-27da-4085-9b8f-03755b39d080"}
```
```charts
{}
```
""",
            1,
            1,
            id="combined",
        ),
    ],
)
def test_get_number_of_charts(
    text: str, expected_num_charts: int, expected_num_broken_charts: int
):
    num_charts, num_broken_charts = get_number_of_proper_and_broken_charts(
        text,
        validate_and_get_chart_image_link_from_json=lambda x: (
            DataTableChart.model_validate_json(x).form_image_link()
        ),
    )
    assert num_charts == expected_num_charts
    assert num_broken_charts == expected_num_broken_charts
