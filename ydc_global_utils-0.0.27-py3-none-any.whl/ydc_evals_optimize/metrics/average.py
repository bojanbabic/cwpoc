from typing import Optional

import pandas as pd

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    StratificationStrategy,
    UserDefinedMetricFn,
    mean_metrics_aggregation_strategy,
)


class AverageMetric(BaseMetricComputor[dict]):
    metric_input_type = dict

    def __init__(
        self,
        name: str,
        is_none_considered_failure: bool = False,
        stratify_by: Optional[list[StratificationStrategy]] = None,
        input_column_name: Optional[str] = None,
        fn: Optional[UserDefinedMetricFn] = None,
    ):
        # No point to set metric_input_mapping since remapping fields does nothing here
        super().__init__(name, None, stratify_by)
        self.is_none_considered_failure = is_none_considered_failure
        self.input_column_name = input_column_name or name
        self.fn = fn
        assert not (
            bool(fn) and bool(input_column_name)
        ), "Do not provide both `fn` and `input_column_name`"

    def compute_metric(self, metric_input: dict, **kwargs) -> dict:
        if self.fn:
            return {self.name: self.fn(metric_input)}
        else:
            return {self.name: metric_input[self.input_column_name]}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(
            df, self.name, is_none_considered_failure=self.is_none_considered_failure
        )
