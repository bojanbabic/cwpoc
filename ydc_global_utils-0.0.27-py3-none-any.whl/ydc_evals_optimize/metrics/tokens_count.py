from typing import Optional

import pandas as pd
import tiktoken
from pydantic import BaseModel

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.utils import replace_markdown_links_with_text


class TokensCountMetricInput(BaseModel):
    generated_response: str


class TokensCountMetric(BaseMetricComputor[TokensCountMetricInput]):
    metric_input_type = TokensCountMetricInput

    def __init__(
        self,
        tokenizer: Optional[tiktoken.Encoding] = None,
        name: str = "tokens_count",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.tokenizer = tokenizer or tiktoken.get_encoding("cl100k_base")

    def compute_metric(self, metric_input: TokensCountMetricInput, **kwargs) -> dict:
        stripped_citations = replace_markdown_links_with_text(
            metric_input.generated_response, ""
        )
        num_tokens = len(self.tokenizer.encode(stripped_citations))
        return {self.name: num_tokens}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, self.name)
