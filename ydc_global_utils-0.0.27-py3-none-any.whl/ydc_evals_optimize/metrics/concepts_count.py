from typing import Optional

import pandas as pd
import tiktoken
from pydantic import BaseModel
from retry import retry

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.utils import (
    deduplicate_list,
    prompt_to_messages,
    query_openai_model,
    replace_markdown_links_with_text,
)


class ConceptsCountMetricInput(BaseModel):
    generated_response: str


class ConceptsCountMetric(BaseMetricComputor[ConceptsCountMetricInput]):
    metric_input_type = ConceptsCountMetricInput

    def __init__(
        self,
        concepts_extractor: "ConceptsExtractor",
        name: str = "concepts_count",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.concepts_extractor = concepts_extractor

    def compute_metric(self, metric_input: ConceptsCountMetricInput, **kwargs) -> dict:
        answer_without_citations = replace_markdown_links_with_text(
            metric_input.generated_response, ""
        )
        concepts = self.concepts_extractor.extract(answer_without_citations)
        return {"concepts": concepts, self.name: len(concepts)}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, self.name)


class ConceptsExtractor:
    MODEL_NAME = "gpt-3.5-turbo-1106"
    MAX_OUTPUT_TOKENS = 512
    TIMEOUT = 10
    PROMPT_TEMPLATE = """<||im_start||>system
You are a helpful assistant.
<||im_end||>
<||im_start||>user
\"""
{text}
\"""

Help me to extract all the keywords from the text above into an unordered list which starts with "-".
<||im_end||>
<||im_start||>assistant
"""

    def __init__(self, model_name: str = MODEL_NAME):
        self.model_name = model_name

    @retry(tries=3, delay=1, backoff=2)
    def extract(self, text: str) -> list[str]:
        llm_output = self._call_llm(text)
        return self._parse_llm_output_into_concepts(llm_output)

    @staticmethod
    def _parse_llm_output_into_concepts(llm_output: str) -> list[str]:
        concepts = [concept.strip(" -") for concept in llm_output.split("\n")]
        filtered_concepts = [concept for concept in concepts if concept]
        deduped_concepts = deduplicate_list(
            filtered_concepts, key=lambda concept: concept.lower()
        )
        return deduped_concepts

    def _call_llm(self, text: str) -> str:
        prompt = self.PROMPT_TEMPLATE.format(text=text)
        messages = prompt_to_messages(prompt)
        response = query_openai_model(
            messages,
            model=self.model_name,
            max_output_tokens=self.MAX_OUTPUT_TOKENS,
            timeout=self.TIMEOUT,
        )
        return response["content"]


if __name__ == "__main__":
    answer = """# Parameter Efficient Fine-tuning for Large Language Models (LLMs)
 

 ## Introduction to Parameter Efficient Fine-tuning (PEFT)
 

 Fine-tuning LLMs for specific tasks is essential but comes with challenges such as 'Catastrophic Forgetting,' where the model forgets previously learned tasks when adapting to new ones [[1]](https://ritikjain51.medium.com/llms-parameter-efficient-fine-tuning-d1772b054c36#:~:text=Fine%2Dtuning%20LLMs%20for%20specific%20tasks%20is%20not%20without%20hurdles). PEFT is a set of approaches that streamline the adaptation of pre-trained language models for various tasks without needing to fine-tune all the model’s parameters [[2]](https://ritikjain51.medium.com/llms-parameter-efficient-fine-tuning-d1772b054c36#:~:text=Parameter%20efficient%20fine%2Dtuning%20%28PEFT%29%20encompasses%20a%20range%20of%20approaches%20that%20enable%20the%20streamlined%20adaptation%20of%20pre%2Dtrained%20language%20models%20for%20diverse%20downstream%20tasks%2C%20all%20without%20the%20need%20to%20fine%2Dtune%20the%20entirety%20of%20the%20model%E2%80%99s%20parameters). This method focuses on fine-tuning a limited subset of additional model parameters [[3]](https://ritikjain51.medium.com/llms-parameter-efficient-fine-tuning-d1772b054c36#:~:text=Instead%2C%20PEFT%20focuses%20exclusively%20on%20fine%2Dtuning%20a%20limited%20subset%20of%20additional%20model%20parameters), which can achieve results comparable to full fine-tuning [[4]](https://ritikjain51.medium.com/llms-parameter-efficient-fine-tuning-d1772b054c36#:~:text=Cutting%2Dedge%20PEFT%20methods%20currently%20attain%20results%20on%20par%20with%20those%20achieved%20through%20complete%20fine%2Dtuning%2C%20marking%20a%20significant%20advancement%20in%E2%80%A6)[[5]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=PEFT%20approaches%20enable%20you%20to%20get%20performance%20comparable%20to%20full%20fine%2Dtuning%20while%20only%20having%20a%20small%20number%20of%20trainable%20parameters).
 

 ## Techniques in PEFT
 

 PEFT involves freezing the parameters of a pre-trained LLM, adding new parameters, and fine-tuning these new parameters on a smaller training dataset [[6]](https://www.hopsworks.ai/dictionary/parameter-efficient-fine-tuning-of-llms#:~:text=you%20freeze%20the%20parameters%20of%20a%20pre%2Dtrained%20LLM%2C%20add%20some%20new%20parameters%2C%20and%20fine%2Dtune%20the%20new%20parameters%20on%20a%20new%20%28small%29%20training%20dataset). Techniques under PEFT include:
 

 - **Adapters**: These are tunable layers added to the transformer blocks of an LLM [[7]](https://www.hopsworks.ai/dictionary/parameter-efficient-fine-tuning-of-llms#:~:text=Adapters%20add%20tunable%20layers%20to%20the%20various%20transformer%20blocks%20of%20an%20LLM.%20Prefix%20tuning%20adds%20trainable%20tensors%20to%20each%20transformer%20block)[[8]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=Adapters%20are%20special%20submodules%20added%20to%20pre%2Dtrained%20language%20models%2C%20modify%20hidden%20representations%20during%20fine%2Dtuning).
 - **Prefix Tuning**: This involves adding trainable tensors to each transformer block [[7]](https://www.hopsworks.ai/dictionary/parameter-efficient-fine-tuning-of-llms#:~:text=Adapters%20add%20tunable%20layers%20to%20the%20various%20transformer%20blocks%20of%20an%20LLM.%20Prefix%20tuning%20adds%20trainable%20tensors%20to%20each%20transformer%20block)[[9]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=Prefix%2Dtuning%20is%20a%20simpler%20way%20to%20train%20big%20language%20models%20for%20tasks%20like%20writing).
 - **QLoRA**: It enables fine-tuning on quantized weights, allowing large models to be trained on a single GPU [[10]](https://www.hopsworks.ai/dictionary/parameter-efficient-fine-tuning-of-llms#:~:text=An%20extension%2C%20known%20as%20QLoRA%2C%20enables%20fine%2Dtuning%20on%20quantized%20weights%2C%20such%20that%20even%20large%20models%20such%20as%20Llama%2D2%20can%20be%20trained%20on%20a%20single%20GPU).
 - **RoSA**: A newer method that constructs the L matrix by breaking down the head matrix of the model into a low-rank form, using fewer parameters than LoRA and achieving better performance [[11]](https://medium.com/@jelkhoury880/new-parameter-efficient-fine-tuning-method-rosa-394aa8458726#:~:text=RoSA%20constructs%20the%20L%20matrix%20by%20breaking%20down%20the%20head%20matrix%20of%20the%20model%20into%20a%20low%2Drank%20form).
 - **LoRA**: Adds extra weights to the model while freezing most of the pre-trained network’s parameters [[12]](https://www.linkedin.com/pulse/parameter-efficient-fine-tuning-large-language-models-pankaj-a#:~:text=LoRa%20focuses%20on%20adding%20extra%20weights%20to%20the%20model%20while%20freezing%20most%20of%20the%20pre%2Dtrained%20network%E2%80%99s%20parameters)[[13]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=LoRA%20%28Low%2DRank%20Adaptation%29%20is%20a%20fine%2Dtuning%20approach%20for%20large%20language%20models%2C%20akin%20to%20adapters).
 - **IA3**: A technique designed to improve upon LoRA [[14]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=IA3%2C%20or%20Infused%20Adapter%20by%20Inhibiting%20and%20Amplifying%20Inner%20Activations%2C%20is%20a%20parameter%2Defficient%20fine%2Dtuning%20technique%20designed%20to%20improve%20upon%20the%20LoRA%20technique).
 

 ## Advantages of PEFT
 

 PEFT offers several benefits:
 

 - **Resource Efficiency**: It allows for fine-tuning LLMs with fewer resources [[15]](https://www.hopsworks.ai/dictionary/parameter-efficient-fine-tuning-of-llms#:~:text=PEFT%20enables%20you%20to%20fine%2Dtune%20a%20LLM%20with%20less%20resources)[[16]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=PEFT%20involves%20fine%2Dtuning%20only%20a%20small%20number%20of%20extra%20model%20parameters%20while%20freezing%20most%20parameters%20of%20the%20pre%2Dtrained%20LLMs%2C%20thereby%20reducing%20computational%20and%20storage%20costs%20significantly).
 - **Generalization**: PEFT methods generalize better to out-of-domain scenarios [[17]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=PEFT%20approaches%20have%20been%20shown%20to%20perform%20better%20than%20full%20fine%2Dtuning%20in%20low%2Ddata%20regimes%20and%20generalize%20better%20to%20out%2Dof%2Ddomain%20scenarios)[[18]](https://markovate.com/blog/parameter-efficient-fine-tuning-peft-of-llms-a-practical-guide/#:~:text=PEFT%E2%80%99s%20prowess%20extends%20to%20low%2Ddata%20situations%2C%20where%20it%20has%20demonstrated%20an%20ability%20to%20outperform%20traditional%20full%20fine%2Dtuning%20and%20show%20better%20generalization%20in%20out%2Dof%2Ddomain%20applications).
 - **Low-Data Performance**: PEFT performs better than full fine-tuning in low-data regimes [[17]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=PEFT%20approaches%20have%20been%20shown%20to%20perform%20better%20than%20full%20fine%2Dtuning%20in%20low%2Ddata%20regimes%20and%20generalize%20better%20to%20out%2Dof%2Ddomain%20scenarios).
 - **Computational Savings**: Dramatically reduces computational and storage costs [[16]](https://www.theaidream.com/post/fine-tuning-large-language-models-llms-using-peft#:~:text=PEFT%20involves%20fine%2Dtuning%20only%20a%20small%20number%20of%20extra%20model%20parameters%20while%20freezing%20most%20parameters%20of%20the%20pre%2Dtrained%20LLMs%2C%20thereby%20reducing%20computational%20and%20storage%20costs%20significantly)[[19]](https://markovate.com/blog/parameter-efficient-fine-tuning-peft-of-llms-a-practical-guide/#:~:text=PEFT%20dramatically%20minimizes%20the%20computational%20demands%2C%20making%20it%20a%20more%20efficient%20route%20for%20model%20refinement).
 

 ## Practical Applications and Future of PEFT
 

 PEFT is being used to power language models like BERT and RoBERTa, especially in low-data situations [[20]](https://markovate.com/blog/parameter-efficient-fine-tuning-peft-of-llms-a-practical-guide/#:~:text=To%20power%20language%20models%20like%20BERT%20and%20RoBERTa%2C%20PEFT%E2%80%99s%20efficacy%20is%20being%20employed). It supports a variety of applications, from customer service to diagnosing software issues [[21]](https://shelf.io/blog/fine-tuning-llms-for-ai-accuracy-and-effectiveness/#:~:text=Fine%2Dtuned%20LLMs%20support%20more%20subtle%20identification%20of%20customer%20types%20and%20needs). The approach is also critical for AI deployment in enterprise environments, where it can enhance performance and efficiency [[22]](https://snorkel.ai/how-to-fine-tune-large-language-models-for-enterprise-use-cases/#:~:text=there%20is%20a%20clear%20need%20for%20fine%2Dtuning%20these%20models%20to%20enhance%20their%20performance%20in%20the%20enterprise%20environment).
 

 PEFT techniques are increasingly seen as practical solutions for fine-tuning LLMs in settings with limited computational resources [[23]](https://ar5iv.labs.arxiv.org/html/2308.10462#:~:text=PEFT%20techniques%20allow%20LLMs%20to%20better%20adapt%20to%20the%20task%2Dspecific%20dataset%20with%20low%20computational%20cost). With the integration of PEFT in libraries like Hugging Face, it is becoming more accessible for developers to implement these techniques [[24]](https://www.linkedin.com/pulse/parameter-efficient-fine-tuning-large-language-models-pankaj-a#:~:text=Hugging%20Face%20has%20released%20a%20library%20that%20integrates%20PEFT%20with%20the%20transformers%20and%20accelerate%20libraries)[[25]](https://blog.dataiku.com/parameter-efficient-llm-fine-tuning#:~:text=In%20this%20three%2Dpart%20series%2C%20we%E2%80%99ll%20unpack%20several%20technical%20topics%20that%20have%20made%20their%20way%20into%20the%20spotlight%20as%20a%20result%20of%20the%20increased%20usage%20and%20exploration%20of%20Large%20Language%20Models%20%28LLMs%29).
 

 ## Conclusion
 

 Parameter Efficient Fine-tuning (PEFT) represents a significant advancement in the field of natural language processing. By focusing on fine-tuning a small subset of parameters, PEFT enables the efficient adaptation of LLMs to specific tasks while maintaining the original capabilities of the models. The development of new methods like RoSA and the integration of PEFT into popular libraries underscore the growing importance of this approach in achieving high performance with reduced computational demands. As the technology world evolves rapidly, PEFT stands as a testament to the ongoing quest for innovation, adaptability, and efficiency in artificial intelligence."""
    tokenizer = tiktoken.get_encoding("cl100k_base")
    extractor = ConceptsExtractor()
    metric = ConceptsCountMetric(extractor)
    res = metric.compute_metric(ConceptsCountMetricInput(generated_response=answer))
    print(res)
