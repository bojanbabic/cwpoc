from abc import ABC, abstractmethod
from typing import Callable, Generic, Optional, Tuple, Type, TypeVar, Union

import pandas as pd

_MetricInputT = TypeVar("_MetricInputT")
# Maps from a field that is required by the MetricInput to the field on the Row data
MetricInputMapping = dict[str, str]
UserDefinedMetricFn = Callable[[dict], Optional[str | float | int]]
AggregatedMetricsAndErrors = dict[str, Tuple[float, int]]

StratificationColumn = str
StratificationGroupName = str
StratificationSubGroupName = str
StratificationFn = Callable[
    [pd.DataFrame], list[Tuple[StratificationSubGroupName, pd.DataFrame]]
]
StratificationStrategy = Union[
    StratificationColumn, Tuple[StratificationGroupName, StratificationFn]
]


class BaseMetricComputor(ABC, Generic[_MetricInputT]):
    # This class is used for input validation. If metric_input_mapping has been specified,
    # we will first remap the fields according to the mapping before validating.
    metric_input_type: Type[_MetricInputT]

    def __init__(
        self,
        name: str,
        metric_input_mapping: Optional[MetricInputMapping],
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        self.name = name
        # This mapping allows us to map from each metric input field to the raw data field
        self.metric_input_mapping = metric_input_mapping
        # This will be used to break down the dataset into different groups and calculate
        # the metrics on each group.
        self.stratify_by = stratify_by

    @abstractmethod
    def compute_metric(self, metric_input: _MetricInputT, **kwargs) -> dict:
        ...

    @abstractmethod
    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        ...

    def stratify_dataframe(
        self, df: pd.DataFrame
    ) -> list[Tuple[StratificationGroupName, StratificationSubGroupName, pd.DataFrame]]:
        if not self.stratify_by:
            return []

        output = []
        for stratification_strategy in self.stratify_by:
            if isinstance(stratification_strategy, StratificationColumn):
                stratify_col = stratification_strategy
                group_name = stratify_col
                unique_values_in_group = df[stratify_col].value_counts().index.tolist()
                for value in sorted(unique_values_in_group):
                    if value is None or str(value).strip() == "":
                        continue
                    sub_group_name = str(value)
                    stratified_df = df[df[stratify_col] == value]
                    output.append((group_name, sub_group_name, stratified_df))
            else:
                group_name, stratify_fn = stratification_strategy
                for sub_group_name, stratified_df in stratify_fn(df):
                    output.append((group_name, sub_group_name, stratified_df))
        return output

    def validate_metric_input(self, raw_data: dict) -> _MetricInputT:
        if self.metric_input_mapping:
            _mapped_data = {
                metric_input_field: raw_data[raw_data_field]
                for metric_input_field, raw_data_field in self.metric_input_mapping.items()
            }
            mapped_data = {**raw_data, **_mapped_data}
        else:
            mapped_data = raw_data
        return self.metric_input_type(**mapped_data)


def mean_metrics_aggregation_strategy(
    df: pd.DataFrame, name: str, is_none_considered_failure: bool = True
) -> AggregatedMetricsAndErrors:
    num_errors = df[name].isna().sum() if is_none_considered_failure else 0
    return {name: (float(df[name].mean()), num_errors)}


def sum_metrics_aggregation_strategy(
    df: pd.DataFrame, name: str, is_none_considered_failure: bool = True
) -> AggregatedMetricsAndErrors:
    num_errors = df[name].isna().sum() if is_none_considered_failure else 0
    # MLFlow seems to ignore the value if we do not run float(...)
    return {name: (float(df[name].sum()), num_errors)}
