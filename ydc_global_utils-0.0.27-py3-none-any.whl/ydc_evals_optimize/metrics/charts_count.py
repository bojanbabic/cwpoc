from typing import Optional, Callable

import pandas as pd
from pydantic import BaseModel

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.metrics.utils import get_number_of_proper_and_broken_charts


class ChartsCountMetricInput(BaseModel):
    generated_response: str


class ChartsCountMetric(BaseMetricComputor[ChartsCountMetricInput]):
    metric_input_type = ChartsCountMetricInput

    def __init__(
        self,
        validate_and_get_chart_image_link_from_json: Callable[[str], Optional[str]],
        name: str = "charts_count",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.validate_and_get_chart_image_link_from_json = (
            validate_and_get_chart_image_link_from_json
        )

    def compute_metric(self, metric_input: ChartsCountMetricInput, **kwargs) -> dict:
        num_charts, num_broken_charts = get_number_of_proper_and_broken_charts(
            metric_input.generated_response,
            validate_and_get_chart_image_link_from_json=self.validate_and_get_chart_image_link_from_json,
        )
        return {
            self.name: num_charts,
            f"{self.name}_broken": num_broken_charts,
            "charts_exist": int(num_charts > 0),
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return {
            **mean_metrics_aggregation_strategy(df, self.name),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_broken"),
            **mean_metrics_aggregation_strategy(df, "charts_exist"),
        }
