from typing import Optional

import pandas as pd
from pydantic import BaseModel
from retry import retry

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.metrics.utils import EvaluationPrompt
from ydc_evals_optimize.utils import query_openai_model

SYSTEM_PROMPT = """
Your task is to verify the groundedness of predictions in the supplied evidence.
Answer only with the single word YES or NO and nothing else.

You are given a question, the corresponding evidence passages and a prediction from a
model. Compare the "Prediction" and the "Evidence Passages" to determine whether all the
information of the prediction is present in the evidence passages or can be inferred
from the evidence passages. You must answer "NO" if there are any specific details in
the prediction that are not mentioned in the evidence passages or cannot be inferred
from the evidence passages. Otherwise, answer "YES" Please read the question and
evidence passages carefully before determining your response.

"""

USER_PROMPT = """
# Question: {question}
# Prediction: {generated_response}
# Evidence Passages:
{context}

# Answer:
"""

FAITHFULNESS_EVALUATOR_PROMPT = EvaluationPrompt(system=SYSTEM_PROMPT, user=USER_PROMPT)


@retry(tries=3, delay=20, backoff=3)
def query_openai_model_decorated(messages):
    return query_openai_model(messages=messages, temperature=0)


class FaithfulnessMetricInput(BaseModel):
    question: str
    generated_response: str
    context: str


class FaithfulnessMetric(BaseMetricComputor[FaithfulnessMetricInput]):
    """Evaluates how well the generated response uses the retrieved snippets."""

    metric_input_type = FaithfulnessMetricInput

    def __init__(
        self,
        name: str = "faithfulness",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        prompt: Optional[EvaluationPrompt] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.prompt = prompt if prompt else FAITHFULNESS_EVALUATOR_PROMPT

    def compute_metric(self, metric_input: FaithfulnessMetricInput, **kwargs) -> dict:
        messages = self.prompt.format(
            question=metric_input.question,
            generated_response=metric_input.generated_response,
            context=metric_input.context,
        )
        response = query_openai_model_decorated(messages=messages)

        is_correct = self.process_response(response)
        return {f"{self.name}_passed": is_correct}

    def process_response(self, response: dict) -> bool:
        """Processes LLM response and extracts answer."""

        answer = response["content"]
        is_correct = "yes" in answer.lower()
        return is_correct

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, f"{self.name}_passed")
