from typing import Optional

import pandas as pd
from pydantic import BaseModel
from torchmetrics.text import ROUGEScore

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)


class ReferenceAnswerRecallMetricInput(BaseModel):
    generated_response: str
    reference_answer: str


class ReferenceAnswerRecallMetric(BaseMetricComputor[ReferenceAnswerRecallMetricInput]):
    metric_input_type = ReferenceAnswerRecallMetricInput

    def __init__(
        self,
        name: str = "response_recall_wrt_reference_answer",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.metric = ROUGEScore(rouge_keys="rouge1")

    def compute_metric(
        self, metric_input: ReferenceAnswerRecallMetricInput, **kwargs
    ) -> dict:
        result = self.metric(
            metric_input.generated_response, metric_input.reference_answer
        )
        rouge1_recall = result["rouge1_recall"].item()
        return {self.name: rouge1_recall}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, self.name)


class SnippetPrecisionMetricInput(BaseModel):
    generated_response: str
    context: str


class SnippetPrecisionMetric(BaseMetricComputor[SnippetPrecisionMetricInput]):
    metric_input_type = SnippetPrecisionMetricInput

    def __init__(
        self,
        name: str = "response_precision_wrt_snippets",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.metric = ROUGEScore(rouge_keys="rouge1")

    def compute_metric(
        self, metric_input: SnippetPrecisionMetricInput, **kwargs
    ) -> dict:
        result = self.metric(metric_input.generated_response, metric_input.context)
        precision = result["rouge1_precision"].item()
        return {self.name: precision}

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return mean_metrics_aggregation_strategy(df, self.name)
