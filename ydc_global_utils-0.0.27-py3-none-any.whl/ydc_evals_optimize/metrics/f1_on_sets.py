from typing import Optional

import pandas as pd

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)


class F1OnSetsMetric(BaseMetricComputor[dict]):
    metric_input_type = dict

    def __init__(
        self,
        pred_col: str,
        correct_col: str,
        name: str = "f1_sets",
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, None, stratify_by)
        self.pred_col = pred_col
        self.correct_col = correct_col

    def compute_metric(self, metric_input: dict, **kwargs) -> dict:
        pred_urls = set(metric_input[self.pred_col])
        correct_urls = set(metric_input[self.correct_col])
        # True positives
        tp = len(pred_urls & correct_urls)

        # Precision
        precision = tp / (len(pred_urls) + 1e-8)

        # Recall
        recall = tp / (len(correct_urls) + 1e-8)

        # F1 score
        f1 = 2 * (precision * recall) / (precision + recall + 1e-8)

        return {
            f"{self.name}_precision": precision,
            f"{self.name}_recall": recall,
            f"{self.name}_f1": f1,
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return {
            **mean_metrics_aggregation_strategy(df, f"{self.name}_precision"),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_recall"),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_f1"),
        }
