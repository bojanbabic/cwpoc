import json
import re
from typing import Literal, Optional

import pandas as pd
from pydantic import BaseModel

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.utils import (
    query_openai_model,
)
from ydc_services.Search.YouChat.DeepResearch.report_engine.experimental.image_understander import (
    ImageUnderstander,
)


class InlineImageRelevanceMetricInput(BaseModel):
    question: str
    generated_response: str


class InlineImageRelevanceMetric(BaseMetricComputor[InlineImageRelevanceMetricInput]):
    """
    Evaluates if the images within the generated response is relevant to the section
    that they are placed in and that they are not lumped together in a single section.
    """

    metric_input_type = InlineImageRelevanceMetricInput

    def __init__(
        self,
        rater: "MultiStageInlineImageRelevanceRater",
        name: str = "inline_image_relevance",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.rater = rater

    def compute_metric(
        self, metric_input: InlineImageRelevanceMetricInput, **kwargs
    ) -> dict:
        rating_output = self.rater.rate(
            metric_input.question, metric_input.generated_response
        )
        num_good_images = len(
            [
                img
                for img in rating_output.rated_images
                if img.is_image_useful_and_placed_well
            ]
        )
        num_bad_images = len(
            [
                img
                for img in rating_output.rated_images
                if not img.is_image_useful_and_placed_well
            ]
        )
        precision = (
            (num_good_images / len(rating_output.rated_images))
            if rating_output.rated_images
            else None
        )
        return {
            f"{self.name}_precision": precision,
            f"{self.name}_num_good_images": num_good_images,
            f"{self.name}_num_bad_images": num_bad_images,
            f"{self.name}_chance_of_1_good_image": int(num_good_images > 0),
            f"{self.name}_chance_of_1_bad_image": int(num_bad_images > 0),
            f"{self.name}_explanation": rating_output.model_dump_json(indent=2),
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return {
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_precision", is_none_considered_failure=False
            ),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_num_good_images"),
            **mean_metrics_aggregation_strategy(df, f"{self.name}_num_bad_images"),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_chance_of_1_good_image"
            ),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_chance_of_1_bad_image"
            ),
        }


class _InlineImageRelevanceRating(BaseModel):
    thoughts: str
    is_image_useful_and_placed_well: int


class InlineImageRelevanceRaterOutput(BaseModel):
    rated_images: list[_InlineImageRelevanceRating]


class MultiStageInlineImageRelevanceRater:
    STAGE_1_LUMPING_SYSTEM_PROMPT = """You are an expert image placement evaluator that evaluates whether an image has been placed well within the generated response.

You will be given a generated response and an image URL to evaluate.

You should return in the following JSON format:
{"thoughts": "...", "is_image_placed_well": bool}

Explanation of fields:
- thoughts: You can use this section to write down your thoughts before providing an evaluation.
- is_image_placed_well: The image has been placed well. This means that the image is not lumped together with other images within a single section. Also, the image is not placed after the conclusion section. See more examples below of bad and good image placement.


Example responses where images are placed POORLY:
1. Images are lumped together instead of being placed in the appropriate sections
```
# Section 1
...

# Section 2
...

# Conclusion
...

![](IMAGE_URL_1)
![](IMAGE_URL_2)
![](IMAGE_URL_3)
```

2. A separate image section has been created for the image.
```
# Section 1
...

# Section 2
...

# Image
![](IMAGE_URL_1)

# Conclusion
...
```

3. Image has been placed after the conclusion header.
```
# Section 1
...

# Section 2
...

# Conclusion
...
![](IMAGE_URL_1)
```


Example responses where images are placed WELL:
```
# Section 1
## Section 1.1
...
![](IMAGE_URL_1)

## Section 1.2
...

# Section 2
## Section 2.1
...

## Section 2.2
...
![](IMAGE_URL_2)
![](IMAGE_URL_3)

# Conclusion
...
```

Remember, if ANY of the conditions for `is_image_placed_well` are not obeyed, you have to set `is_image_placed_well = False`.
"""
    STAGE_2_USEFULNESS_SYSTEM_PROMPT = """You are an expert image relevance evaluator that evaluates whether an image is useful for a user's question and appropriately placed within the generated response.

You will be given a user question, a generated response for the question and an image URL (together with its contents) to evaluate.

You should return in the following JSON format:
{{"thoughts": "...", "{usefulness_field_name}": 0-1}}

Explanation of fields:
- thoughts: You can use this section to write down your thoughts before providing an evaluation.
- {usefulness_field_name}: You should only rate an image as 1 if it satisfies ALL OF THE conditions below.
    1. The image is relevant to the user's question.
    2. The image is appropriately placed in the generated response such that the text within the section is directly relevant.
    3. The image contributes to the discussion within the section by adding new information or making existing information easy to understand.

Remember, if ANY of the conditions for `{usefulness_field_name}` are not obeyed, you have to set `{usefulness_field_name} = 0`. 
"""

    def __init__(
        self,
        model: str = "gpt-4o-2024-05-13",
        stage_0_image_understander: Optional[ImageUnderstander] = None,
        stage_1_lumping_prompt: str = STAGE_1_LUMPING_SYSTEM_PROMPT,
        stage_2_usefulness_prompt: str = STAGE_2_USEFULNESS_SYSTEM_PROMPT,
        stage_2_usefulness_field_name: str = "is_image_useful",
        stage_2_incontext_examples: Optional[list[dict]] = None,
        images_context_detail: Literal["auto", "low", "high"] = "auto",
    ):
        self.model = model
        self.stage_0_image_understander = stage_0_image_understander
        self.stage_1_lumping_prompt = stage_1_lumping_prompt
        self.stage_2_usefulness_prompt = stage_2_usefulness_prompt
        self.stage_2_usefulness_field_name = stage_2_usefulness_field_name
        self.stage_2_incontext_examples = stage_2_incontext_examples or []
        self.images_context_detail = images_context_detail

    def rate(
        self, question: str, generated_response: str
    ) -> InlineImageRelevanceRaterOutput:
        matched_image_urls = re.findall(r"!\[.*?\]\((.*?)\)", generated_response)
        rated_images = [
            self.rate_single_image_url(question, generated_response, image_url)
            for image_url in matched_image_urls
        ]
        return InlineImageRelevanceRaterOutput(rated_images=rated_images)

    def rate_single_image_url(
        self, question: str, generated_response: str, image_url: str
    ) -> _InlineImageRelevanceRating:
        if self.stage_0_image_understander:
            stage_0_out = self.stage_0_image_understander.understand_url(image_url)
            thoughts_obj = {"output": stage_0_out.model_dump(), "stage": 0}
            if stage_0_out.is_small_or_too_blurry_binarized:
                thoughts_obj["reason"] = "is_small_or_too_blurry_binarized"
                return _InlineImageRelevanceRating(
                    thoughts=json.dumps(thoughts_obj, indent=2),
                    is_image_useful_and_placed_well=0,
                )
            if not stage_0_out.is_diagram_or_table_or_infographic_binarized:
                thoughts_obj[
                    "reason"
                ] = "not is_diagram_or_table_or_infographic_binarized"
                return _InlineImageRelevanceRating(
                    thoughts=json.dumps(thoughts_obj, indent=2),
                    is_image_useful_and_placed_well=0,
                )

        stage_1_out = self._rate_single_image_url_for_lumping(
            generated_response, image_url
        )
        if not stage_1_out["is_image_placed_well"]:
            thoughts_obj = {"output": stage_1_out, "stage": 1}
            return _InlineImageRelevanceRating(
                thoughts=json.dumps(thoughts_obj, indent=2),
                is_image_useful_and_placed_well=0,
            )

        stage_2_out = self._rate_single_image_url_for_usefulness(
            question, generated_response, image_url
        )
        thoughts_obj = {"output": stage_2_out, "stage": 2}
        return _InlineImageRelevanceRating(
            thoughts=json.dumps(thoughts_obj, indent=2),
            is_image_useful_and_placed_well=stage_2_out[
                self.stage_2_usefulness_field_name
            ],
        )

    def _rate_single_image_url_for_lumping(
        self, generated_response: str, image_url: str
    ) -> dict:
        messages: list[dict] = [
            {"role": "system", "content": self.stage_1_lumping_prompt},
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            f"Generated response:\n{generated_response}\n\n"
                            f"Image to evaluate:\n{image_url}\n"
                        ),
                    }
                ],
            },
        ]
        response = query_openai_model(
            messages=messages,  # type: ignore[arg-type]
            model=self.model,
            temperature=0,
            response_type="json_object",
        )
        return json.loads(response["content"])

    def _rate_single_image_url_for_usefulness(
        self, question: str, generated_response: str, image_url: str
    ) -> dict:
        messages: list[dict] = [
            {
                "role": "system",
                "content": self.stage_2_usefulness_prompt.format(
                    usefulness_field_name=self.stage_2_usefulness_field_name
                ),
            },
            {
                "role": "user",
                "content": [
                    *self.stage_2_incontext_examples,
                    {
                        "type": "text",
                        "text": (
                            f"Question:\n{question}\n\n"
                            f"Generated response:\n{generated_response}\n\n"
                            f"Image to evaluate:\n{image_url}\n"
                        ),
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": image_url,
                            "detail": self.images_context_detail,
                        },
                    },
                ],
            },
        ]
        response = query_openai_model(
            messages=messages,  # type: ignore[arg-type]
            model=self.model,
            temperature=0,
            response_type="json_object",
        )
        return json.loads(response["content"])
