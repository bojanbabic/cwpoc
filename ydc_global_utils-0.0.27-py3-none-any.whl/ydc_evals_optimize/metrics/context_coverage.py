from typing import Optional

import numpy as np
import pandas as pd
from pydantic import BaseModel

from ydc_evals_optimize.metrics.base import (
    AggregatedMetricsAndErrors,
    BaseMetricComputor,
    MetricInputMapping,
    StratificationStrategy,
    mean_metrics_aggregation_strategy,
)
from ydc_evals_optimize.utils import query_openai_model


class ContextCoverageMetricInput(BaseModel):
    contexts_by_source: list[list[str]]
    generated_response: str


class ContextCoverageMetric(BaseMetricComputor[ContextCoverageMetricInput]):
    """
    Evaluates the coverage of the contexts from different sources in the generated
    response. Also measures inequality of coverage.
    """

    metric_input_type = ContextCoverageMetricInput

    def __init__(
        self,
        rater: "ContextCoverageRater",
        name: str = "context_coverage",
        metric_input_mapping: Optional[MetricInputMapping] = None,
        stratify_by: Optional[list[StratificationStrategy]] = None,
    ):
        super().__init__(name, metric_input_mapping, stratify_by)
        self.rater = rater

    def compute_metric(
        self, metric_input: ContextCoverageMetricInput, **kwargs
    ) -> dict:
        # Note: serialized and hence not very fast
        num_sources = len(metric_input.contexts_by_source)
        num_contexts = sum([len(ctx) for ctx in metric_input.contexts_by_source])
        num_sources_with_at_least_1_context_covered = 0
        num_contexts_covered_data = []
        fraction_of_contexts_covered_data = []

        for contexts in metric_input.contexts_by_source:
            rating_output = self.rater.rate(contexts, metric_input.generated_response)
            ratings = [int(rating.is_covered) for rating in rating_output.ratings]
            num_sources_with_at_least_1_context_covered += any(ratings)
            num_contexts_covered_data.append(sum(ratings))
            fraction_of_contexts_covered_data.append(
                round(sum(ratings) / len(ratings), 2) if ratings else 0.0
            )

        fraction_of_sources_with_at_least_1_context_covered = (
            (num_sources_with_at_least_1_context_covered / num_sources)
            if num_sources > 0
            else 0.0
        )
        fraction_of_contexts_covered = (
            (sum(num_contexts_covered_data) / num_contexts) if num_contexts > 0 else 0.0
        )
        sorted_num_contexts = sorted(num_contexts_covered_data, reverse=True)
        diff_between_top_2_num_contexts_covered = (
            sorted_num_contexts[0] - sorted_num_contexts[1]
            if len(sorted_num_contexts) >= 2
            else None
        )
        return {
            f"{self.name}_fraction_of_sources_with_at_least_1_context_covered": fraction_of_sources_with_at_least_1_context_covered,
            f"{self.name}_fraction_of_contexts_covered": fraction_of_contexts_covered,
            # ==== Inequality of coverage ====
            f"{self.name}_std_dev_of_num_contexts_covered": np.std(
                num_contexts_covered_data
            ),
            # This allows us to know if there is 1 source that has a heavy bias
            f"{self.name}_diff_between_top_2_num_contexts_covered": diff_between_top_2_num_contexts_covered,
            # This allows us to measure inequality between sources in terms of num contexts covered
            f"{self.name}_gini_for_num_contexts_covered": gini_coefficient(
                num_contexts_covered_data
            ),
            # ==== Actual values ====
            f"{self.name}_num_contexts_covered_data": num_contexts_covered_data,
            f"{self.name}_fraction_of_contexts_covered_data": fraction_of_contexts_covered_data,
        }

    def metrics_aggregation_strategy(
        self, df: pd.DataFrame
    ) -> AggregatedMetricsAndErrors:
        return {
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_fraction_of_sources_with_at_least_1_context_covered"
            ),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_fraction_of_contexts_covered"
            ),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_std_dev_of_num_contexts_covered"
            ),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_diff_between_top_2_num_contexts_covered"
            ),
            **mean_metrics_aggregation_strategy(
                df, f"{self.name}_gini_for_num_contexts_covered"
            ),
        }


def gini_coefficient(x: list[float] | list[int]) -> float:
    """
    Compute Gini coefficient of array of values

    (Warning: This is a concise implementation, but it is O(n**2) in time and memory,
    where n = len(x).  *Don't* pass in huge samples)
    https://stackoverflow.com/a/39513799
    """
    # Mean absolute difference
    mad = np.abs(np.subtract.outer(x, x)).mean()
    # Relative mean absolute difference
    rmad = mad / np.mean(x)
    # Gini coefficient
    g = 0.5 * rmad
    return g


class _ContextCoverageRating(BaseModel):
    context: str
    is_covered: bool


class ContextCoverageRaterOutput(BaseModel):
    ratings: list[_ContextCoverageRating]


class ContextCoverageRater:
    INPUT_TEMPLATE = """Information points:
<information>
{contexts}
</information>

Answer:
<answer>
{generated_response}
</answer>

Information points coverage:
{correct}"""

    PARTIAL_IN_CONTEXT_EXAMPLE = INPUT_TEMPLATE.format(
        contexts="\n".join(["1. ...", "2. ...", "3. ..."]),
        generated_response="...",
        correct="\n".join(["1. 0", "2. 1", "3. 0"]),
    )

    SYSTEM_PROMPT = f"""You are an expert evaluation system that checks if information points have been covered within an answer.
You will be presented with a numbered list of information points and will go through each of them to determine if they have been covered in the answer already.
Respond with "1" if they have been covered and "0" otherwise. 

Here is an example:
```
{PARTIAL_IN_CONTEXT_EXAMPLE}
```"""

    def __init__(
        self,
        model_name: str = "gpt-4o-mini-2024-07-18",
        temperature: float = 0.0,
        max_output_tokens: int = 512,
    ):
        self.model_name = model_name
        self.temperature = temperature
        self.max_output_tokens = max_output_tokens

    def rate(
        self, contexts_by_source: list[str], generated_response: str
    ) -> ContextCoverageRaterOutput:
        if not contexts_by_source:
            return ContextCoverageRaterOutput(ratings=[])

        id_to_context_map = {
            i + 1: context for i, context in enumerate(contexts_by_source)
        }
        contexts_str = "\n".join(
            [f"{idx}. {context}" for idx, context in id_to_context_map.items()]
        )
        raw_output = query_openai_model(
            messages=[
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": self.INPUT_TEMPLATE.format(
                        contexts=contexts_str,
                        generated_response=generated_response,
                        correct="",
                    ),
                },
            ],
            model=self.model_name,
            temperature=self.temperature,
            max_output_tokens=self.max_output_tokens,
        )
        return self._parse_response(id_to_context_map, raw_output)

    @classmethod
    def _parse_response(
        cls, id_to_context_map: dict[int, str], raw_output: dict
    ) -> ContextCoverageRaterOutput:
        raw_content = raw_output["content"]
        ratings = []
        for line in raw_content.strip().split("\n"):
            try:
                idx, is_covered = [int(item.strip()) for item in line.split(".")]
            except ValueError:
                # There is a chance that a non-int prefix is printed in the response
                continue
            context = id_to_context_map[idx]
            ratings.append(
                _ContextCoverageRating(context=context, is_covered=bool(is_covered))
            )
        return ContextCoverageRaterOutput(ratings=ratings)
