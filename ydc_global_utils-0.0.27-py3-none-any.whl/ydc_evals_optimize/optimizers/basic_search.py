from copy import copy
from typing import Callable, Sequence

from ydc_evals_optimize.evals.base import ModelVariant
from ydc_evals_optimize.evals.runner import (
    AggregatedMetricsForEvals,
    EvaluationRunner,
)
from ydc_evals_optimize.optimizers.base import Optimizer, ScoredModelVariant


class BasicSearchOptimizer(Optimizer):
    def __init__(
        self,
        model_variants: Sequence[ModelVariant],
        evaluation_runner_factory: Callable[[ModelVariant], EvaluationRunner],
        objective_function: Callable[[AggregatedMetricsForEvals], float],
    ):
        super().__init__(evaluation_runner_factory, objective_function)
        self.candidate_variants = copy(model_variants)
        self.model_variant_and_score_pairs: list[ScoredModelVariant] = []

    def propose_next_variants(self, n: int) -> Sequence[ModelVariant]:
        proposed_variants = self.candidate_variants[:n]
        self.candidate_variants = self.candidate_variants[n:]
        return proposed_variants

    def save_objective_score_of_variant(
        self, scored_model_variant: ScoredModelVariant
    ) -> None:
        self.model_variant_and_score_pairs.append(scored_model_variant)

    def get_model_variants(
        self, sort_by_score: bool = True
    ) -> list[ScoredModelVariant]:
        variants = [
            mv_and_score
            for mv_and_score in self.model_variant_and_score_pairs
            if mv_and_score[1] is not None
        ]
        if sort_by_score:
            return sorted(variants, key=lambda mv_and_score: -mv_and_score[1])
        return variants

    def reset(self):
        self.model_variant_and_score_pairs = []
