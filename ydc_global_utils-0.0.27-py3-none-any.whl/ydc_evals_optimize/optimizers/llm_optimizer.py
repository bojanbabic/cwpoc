import json
from copy import copy
from itertools import chain
from typing import Any, Callable, Optional, Sequence, TypeAlias

from pydantic import BaseModel, Field, create_model
from retry import retry

from ydc_evals_optimize.evals.base import ModelVariant
from ydc_evals_optimize.evals.runner import (
    AggregatedMetricsForEvals,
    EvalResults,
    EvaluationRunner,
)
from ydc_evals_optimize.optimizers import BasicSearchOptimizer
from ydc_evals_optimize.optimizers.base import Optimizer, ScoredModelVariant
from ydc_services.global_utils.llm.clients.base import LLM
from ydc_services.global_utils.llm.clients.claude3_chat import Claude3Chat
from ydc_services.Search.YouChat.parse_utils import (
    extract_code_blocks,
)

LlmOptimizableParams: TypeAlias = dict[str, Any]


class LlmOptimizer(BasicSearchOptimizer, Optimizer):
    # Original inspiration: https://github.com/openai/build-hours/blob/main/7-reasoning/flightCancellationPolicy/evalsAndPromptImprovements.ipynb
    OPTIMIZER_PROMPT_TEMPLATE = """<||im_start||>system
You are an agent that is responsible for improving the quality of JSON parameters that are provided to a LLM agent.

I am going to give you the JSON parameters for the LLM agent that contains detailed instructions.

Carefully analyze the JSON parameters provided as well as the results of the eval. Get a firm understanding of the failures of a given set of JSON parameters.

Return updated JSON parameters that will perform better against the dataset.
<||im_end||>
<||im_start||>user
Here is the optimization history:
{optimization_history}
<||im_end||>
<||im_start||>assistant"""

    PARAMS_TEMPLATE = """Inputs:
{parameters}
Eval score:
{objective_score}{eval_dfs_context}"""

    def __init__(
        self,
        seed_params: list[LlmOptimizableParams],
        create_model_variant_from_params: Callable[
            [LlmOptimizableParams], ModelVariant
        ],
        evaluation_runner_factory: Callable[[ModelVariant], EvaluationRunner],
        objective_function: Callable[[AggregatedMetricsForEvals], float],
        serialize_params: Callable[
            [LlmOptimizableParams], str
        ] = lambda params: json.dumps(params, indent=2),
        deserialize_params: Callable[
            [str], LlmOptimizableParams
        ] = lambda resp: json.loads(extract_code_blocks(resp)[0][0]),
        optimizer_serialize_eval_dfs_fn: Optional[Callable[[EvalResults], str]] = None,
        optimizer_llm_client: Optional[LLM] = None,
        optimizer_prompt_template: str = OPTIMIZER_PROMPT_TEMPLATE,
        optimizer_max_history: int = 5,
    ):
        super().__init__([], evaluation_runner_factory, objective_function)

        self.seed_params = copy(seed_params)
        self.fields_to_optimize = list(set(chain(*[p.keys() for p in seed_params])))
        fields: dict = {name: (str, Field()) for name in self.fields_to_optimize}
        self.params_model = create_model("Parameters", __base__=BaseModel, **fields)
        self.create_model_variant_from_params = create_model_variant_from_params
        self.serialize_params = serialize_params
        self.deserialize_params = deserialize_params

        self.optimizer_serialize_eval_dfs_fn = optimizer_serialize_eval_dfs_fn
        self.optimizer_llm_client = optimizer_llm_client or Claude3Chat(
            model_name="claude-3-5-sonnet-20241022",
            request_timeout=60,
            max_output_tokens=2048,
            stream=False,
            temperature=0,
            client_type="shared",
        )
        self.optimizer_prompt_template = optimizer_prompt_template
        self.optimizer_max_history = optimizer_max_history

    def propose_next_variants(self, n: int) -> Sequence[ModelVariant]:
        # If we do not yet have any model variants from runs, use the seed params to create
        model_variants = self.get_model_variants(sort_by_score=False)
        if not model_variants:
            return [
                self.create_model_variant_from_params(params)
                for params in self.seed_params
            ]

        return [self._llm_suggest(model_variants)]

    def get_log_params(self) -> dict:
        log_params = {
            "optimizer_type": self.__class__.__name__,
            "fields_to_optimize": self.fields_to_optimize,
        }
        log_params.update(
            {
                k: vars(v) if isinstance(v, LLM) else v
                for k, v in vars(self).items()
                if k.startswith("optimizer_")
            }
        )
        return log_params

    @retry(tries=3)
    def _llm_suggest(
        self, scored_model_variants: list[ScoredModelVariant]
    ) -> ModelVariant:
        best_model_variant = max(scored_model_variants, key=lambda smv: smv[1])
        # Take the remaining model variants from the back in order to show the latest changes
        selected_model_variants = scored_model_variants[-self.optimizer_max_history :]
        if best_model_variant not in selected_model_variants:
            selected_model_variants = [best_model_variant, *selected_model_variants]

        last_variant_id = len(scored_model_variants) - 1
        prompt = self.optimizer_prompt_template.format(
            optimization_history="\n\n".join(
                [
                    f"({i + 1})"
                    + (" (🏆 Best so far)" if smv == best_model_variant else "")
                    + f" {self._serialize_scored_model_variant(smv, should_add_eval_dfs=i == last_variant_id)}"
                    for i, smv in enumerate(selected_model_variants)
                ]
            )
        )
        response = self.optimizer_llm_client.get_response_text(prompt)
        params = self.deserialize_params(response)
        model_variant = self.create_model_variant_from_params(params)
        return model_variant

    def _serialize_scored_model_variant(
        self, scored_model_variant: ScoredModelVariant, should_add_eval_dfs: bool
    ) -> str:
        model_variant, objective_score, _, eval_dfs = scored_model_variant
        filtered_params = {
            k: v
            for k, v in model_variant.params.items()
            if k in self.fields_to_optimize
        }
        eval_dfs_context = (
            self.optimizer_serialize_eval_dfs_fn(eval_dfs)
            if should_add_eval_dfs and self.optimizer_serialize_eval_dfs_fn
            else ""
        )
        if eval_dfs_context:
            eval_dfs_context = (
                f"\nHere are the results based on the parameters:\n{eval_dfs_context}"
            )

        return self.PARAMS_TEMPLATE.format(
            parameters=self.serialize_params(filtered_params),
            objective_score=objective_score,
            eval_dfs_context=eval_dfs_context,
        )
