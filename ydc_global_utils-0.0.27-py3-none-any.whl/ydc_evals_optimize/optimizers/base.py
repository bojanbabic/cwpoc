import gc
import logging
from abc import ABC, abstractmethod
from typing import Callable, Optional, Sequence, Tuple

import pandas as pd

from ydc_evals_optimize.evals.base import ModelVariant
from ydc_evals_optimize.evals.runner import (
    AggregatedMetricsForEvals,
    EvalResults,
    EvaluationRunner,
    gather_all_eval_results_into_single_dict,
)

logger = logging.getLogger(__package__)
ObjectiveScore = float
ScoredModelVariant = Tuple[
    ModelVariant, ObjectiveScore, AggregatedMetricsForEvals, EvalResults
]


class Optimizer(ABC):
    def __init__(
        self,
        evaluation_runner_factory: Callable[[ModelVariant], EvaluationRunner],
        objective_function: Callable[[AggregatedMetricsForEvals], float],
    ):
        self.evaluation_runner_factory = evaluation_runner_factory  # type: ignore
        self.objective_function = objective_function

    @abstractmethod
    def propose_next_variants(self, n: int) -> Sequence[ModelVariant]:
        ...

    @abstractmethod
    def save_objective_score_of_variant(
        self, scored_model_variant: ScoredModelVariant
    ) -> None:
        ...

    @abstractmethod
    def get_model_variants(
        self, sort_by_score: bool = True
    ) -> list[ScoredModelVariant]:
        ...

    def optimize(
        self,
        n_runs: Optional[int] = None,
        n_batch_size: int = 1,
        save_csv_path: Optional[str] = None,
        log_params: Optional[dict] = None,
    ) -> list[ScoredModelVariant]:
        run_count = 0
        while candidate_variants := self.propose_next_variants(n_batch_size):
            for candidate_variant in candidate_variants:
                runner = self.evaluation_runner_factory(candidate_variant)
                eval_results, eval_dfs = runner.run(
                    candidate_variant.name,
                    {**(log_params or {}), **candidate_variant.params},
                )
                run_count += 1
                try:
                    objective_score = self.objective_function(eval_results)
                except Exception as e:
                    logger.error("Error while computing objective function", exc_info=e)
                    continue

                scored_model_variant: ScoredModelVariant = (
                    candidate_variant,
                    objective_score,
                    eval_results,
                    eval_dfs,
                )
                self.save_objective_score_of_variant(scored_model_variant)
                # Pandas seems to hold onto files and causes too many files opened OS errors after some time
                gc.collect()

            if n_runs is not None and run_count >= n_runs:
                break

        best_scored_variants = self.get_model_variants()
        if save_csv_path:
            # Combine results across different model variants and save to CSV
            eval_results_across_model_variants = []
            for mv, _, eval_results_for_model_variant, _ in best_scored_variants:
                eval_results_across_model_variants.append(
                    {
                        "name": mv.name,
                        **gather_all_eval_results_into_single_dict(
                            eval_results_for_model_variant
                        ),
                    }
                )
            overall_df = pd.DataFrame(eval_results_across_model_variants)
            overall_df.to_csv(save_csv_path, index=False)

        return best_scored_variants


def combine_eval_dfs(
    scored_model_variants: list[ScoredModelVariant],
    shared_cols: list[str],
    cols: list[str],
) -> pd.DataFrame:
    combined_dfs = []
    for i, (mv, _1, _2, eval_dfs) in enumerate(scored_model_variants):
        # Assume we only have 1 Evaluation and just take that
        eval_df = eval_dfs[0]
        eval_df_subset = eval_df[shared_cols + cols] if i == 0 else eval_df[cols]
        eval_df_processed = eval_df_subset.rename(
            columns={col: f"{mv.name}__{col}" for col in cols}
        )
        combined_dfs.append(eval_df_processed)
    return pd.concat(combined_dfs, axis=1)
